<?php
/**
 * General Helper Functions
 */

require_once __DIR__ . '/../config/constants.php';

/**
 * Encrypt data using AES-256-GCM
 * @param string $plaintext
 * @return string
 */
function encrypt_data(string $plaintext): string {
    if (!function_exists('openssl_encrypt')) {
        throw new Exception('OpenSSL extension not available');
    }
    
    $key = hex2bin(ENCRYPTION_KEY);
    if (strlen($key) !== 32) {
        throw new Exception('Invalid encryption key length');
    }
    
    $iv = openssl_random_pseudo_bytes(12);
    $tag = '';
    
    $ciphertext = openssl_encrypt(
        $plaintext,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );
    
    if ($ciphertext === false) {
        throw new Exception('Encryption failed');
    }
    
    return base64_encode($iv . $ciphertext . $tag);
}

/**
 * Decrypt data using AES-256-GCM
 * @param string $encrypted
 * @return string|null
 */
function decrypt_data(string $encrypted): ?string {
    if (!function_exists('openssl_decrypt')) {
        throw new Exception('OpenSSL extension not available');
    }
    
    try {
        $key = hex2bin(ENCRYPTION_KEY);
        if (strlen($key) !== 32) {
            throw new Exception('Invalid encryption key length');
        }
        
        $data = base64_decode($encrypted, true);
        if ($data === false) {
            throw new Exception('Invalid base64 data');
        }
        
        if (strlen($data) < 28) {
            throw new Exception('Invalid encrypted data length');
        }
        
        $iv = substr($data, 0, 12);
        $tag = substr($data, -16);
        $ciphertext = substr($data, 12, -16);
        
        $plaintext = openssl_decrypt(
            $ciphertext,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        
        if ($plaintext === false) {
            throw new Exception('Decryption failed');
        }
        
        return $plaintext;
    } catch (Throwable $e) {
        error_log('Decryption error: ' . $e->getMessage());
        return null;
    }
}

/**
 * Hash file using SHA-256
 * @param string $filepath
 * @return string
 */
function hash_file_sha256(string $filepath): string {
    return hash_file('sha256', $filepath);
}

/**
 * Sanitize filename
 * @param string $filename
 * @return string
 */
function sanitize_filename(string $filename): string {
    $filename = basename($filename);
    $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
    return $filename;
}

/**
 * Create directory if not exists
 * @param string $dir
 * @return void
 */
function safe_mkdir(string $dir): void {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

/**
 * Generate random token
 * @param int $bytes
 * @return string
 */
function random_token(int $bytes = 32): string {
    return bin2hex(random_bytes($bytes));
}

/**
 * Format date for display
 * @param string|null $dateStr
 * @return string
 */
function format_date(?string $dateStr): string {
    if (!$dateStr) return '-';
    
    $date = DateTime::createFromFormat('Y-m-d', $dateStr);
    if ($date) {
        return $date->format('d/m/Y');
    }
    
    return $dateStr;
}

/**
 * Format datetime for display
 * @param string|null $dateStr
 * @return string
 */
function format_datetime(?string $dateStr): string {
    if (!$dateStr) return '-';
    
    try {
        $date = new DateTime($dateStr);
        return $date->format('d/m/Y H:i');
    } catch (Throwable $e) {
        return $dateStr;
    }
}

/**
 * Escape HTML entities
 * @param string|null $text
 * @return string
 */
function e(?string $text): string {
    return htmlspecialchars($text ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Get status CSS class
 * @param string $status
 * @return string
 */
function get_status_class(string $status): string {
    return match ($status) {
        'ΝΕΟ' => 'pending',
        'ΚΑΤΑΧΩΡΗΜΕΝΟ' => 'registered',
        'ΕΚΚΡΕΜΟΤΗΤΑ' => 'pending',
        'ΑΚΥΡΟ' => 'cancelled',
        'ΕΝΕΡΓΟ' => 'active',
        default => 'registered',
    };
}

/**
 * Log encryption activity
 * @param PDO $db
 * @param string $action
 * @param int|null $customerId
 * @param int|null $userId
 * @return void
 */
function log_encryption_activity(PDO $db, string $action, ?int $customerId = null, ?int $userId = null): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    try {
        $stmt = $db->prepare("
            INSERT INTO encryption_log (userid, customerid, action, ipaddress) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $customerId, $action, $ip]);
    } catch (Throwable $e) {
        error_log('Failed to log encryption activity: ' . $e->getMessage());
    }
}

/**
 * Validate AFM (Greek Tax Number)
 * @param string $afm
 * @return bool
 */
function validate_afm(string $afm): bool {
    // Remove any non-digit characters
    $afm = preg_replace('/[^0-9]/', '', $afm);
    
    // Must be exactly 9 digits
    if (strlen($afm) !== 9) {
        return false;
    }
    
    // Check if all zeros
    if ($afm === '000000000') {
        return false;
    }
    
    // Validate checksum
    $sum = 0;
    for ($i = 0; $i < 8; $i++) {
        $sum += (int)$afm[$i] * pow(2, 8 - $i);
    }
    
    $checksum = $sum % 11;
    if ($checksum === 10) {
        $checksum = 0;
    }
    
    return $checksum === (int)$afm[8];
}

/**
 * Get request parameter
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function request(string $key, mixed $default = null): mixed {
    return $_REQUEST[$key] ?? $default;
}

/**
 * Get POST parameter
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function post(string $key, mixed $default = null): mixed {
    return $_POST[$key] ?? $default;
}

/**
 * Get GET parameter
 * @param string $key
 * @param mixed $default
 * @return mixed
 */
function get(string $key, mixed $default = null): mixed {
    return $_GET[$key] ?? $default;
}

/**
 * Redirect to URL
 * @param string $url
 * @return void
 */
function redirect(string $url): void {
    header("Location: $url");
    exit;
}

/**
 * JSON response
 * @param array $data
 * @param int $statusCode
 * @return void
 */
function json_response(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * JSON success response
 * @param array $data
 * @param string $message
 * @return void
 */
function json_success(array $data = [], string $message = 'OK'): void {
    json_response(['success' => true, 'message' => $message, ...$data]);
}

/**
 * JSON error response
 * @param string $message
 * @param int $code
 * @param array $extra
 * @return void
 */
function json_error(string $message, int $code = 400, array $extra = []): void {
    json_response(array_merge(['success' => false, 'message' => $message], $extra), $code);
}
