<?php
/**
 * Validation Helper Functions
 */

/**
 * Validate required field
 * @param mixed $value
 * @return bool
 */
function validate_required($value): bool {
    if (is_null($value)) return false;
    if (is_string($value)) return trim($value) !== '';
    return true;
}

/**
 * Validate email
 * @param string $email
 * @return bool
 */
function validate_email(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number
 * @param string $phone
 * @return bool
 */
function validate_phone(string $phone): bool {
    // Remove spaces and common separators
    $phone = preg_replace('/[\s\-\(\)\.]/', '', $phone);
    // Check if it contains only digits and optional + prefix
    return preg_match('/^\+?[0-9]{10,15}$/', $phone) === 1;
}

/**
 * Validate username
 * @param string $username
 * @return array [valid, message]
 */
function validate_username(string $username): array {
    if (strlen($username) < 3) {
        return ['valid' => false, 'message' => 'Το username πρέπει να έχει τουλάχιστον 3 χαρακτήρες'];
    }
    
    if (strlen($username) > 60) {
        return ['valid' => false, 'message' => 'Το username δεν μπορεί να υπερβαίνει τους 60 χαρακτήρες'];
    }
    
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        return ['valid' => false, 'message' => 'Το username μπορεί να περιέχει μόνο γράμματα, αριθμούς και κάτω παύλες'];
    }
    
    return ['valid' => true, 'message' => ''];
}

/**
 * Validate password
 * @param string $password
 * @return array [valid, message]
 */
function validate_password(string $password): array {
    if (strlen($password) < 6) {
        return ['valid' => false, 'message' => 'Ο κωδικός πρέπει να έχει τουλάχιστον 6 χαρακτήρες'];
    }
    
    return ['valid' => true, 'message' => ''];
}

/**
 * Validate date
 * @param string $date
 * @param string $format
 * @return bool
 */
function validate_date(string $date, string $format = 'Y-m-d'): bool {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

/**
 * Validate length
 * @param string $value
 * @param int $min
 * @param int $max
 * @return bool
 */
function validate_length(string $value, int $min = 0, int $max = PHP_INT_MAX): bool {
    $len = strlen($value);
    return $len >= $min && $len <= $max;
}

/**
 * Validate numeric
 * @param mixed $value
 * @return bool
 */
function validate_numeric($value): bool {
    return is_numeric($value);
}

/**
 * Validate integer
 * @param mixed $value
 * @return bool
 */
function validate_int($value): bool {
    return filter_var($value, FILTER_VALIDATE_INT) !== false;
}

/**
 * Validate in array
 * @param mixed $value
 * @param array $allowed
 * @return bool
 */
function validate_in_array($value, array $allowed): bool {
    return in_array($value, $allowed, true);
}

/**
 * Validate file upload
 * @param array $file
 * @param array $allowedTypes
 * @param int $maxSize
 * @return array [valid, message]
 */
function validate_file_upload(array $file, array $allowedTypes = [], int $maxSize = 52428800): array {
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['valid' => false, 'message' => 'No file uploaded'];
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['valid' => false, 'message' => 'Upload error: ' . $file['error']];
    }
    
    if ($file['size'] > $maxSize) {
        return ['valid' => false, 'message' => 'File too large'];
    }
    
    if (!empty($allowedTypes)) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        
        if (!in_array($mime, $allowedTypes, true)) {
            return ['valid' => false, 'message' => 'Invalid file type'];
        }
    }
    
    return ['valid' => true, 'message' => ''];
}

/**
 * Run validation rules
 * @param array $data
 * @param array $rules
 * @return array [valid, errors]
 */
function validate(array $data, array $rules): array {
    $errors = [];
    
    foreach ($rules as $field => $fieldRules) {
        $value = $data[$field] ?? null;
        
        foreach ($fieldRules as $rule => $param) {
            $valid = true;
            
            switch ($rule) {
                case 'required':
                    if ($param && !validate_required($value)) {
                        $valid = false;
                        $errors[$field][] = "Το πεδίο είναι υποχρεωτικό";
                    }
                    break;
                    
                case 'email':
                    if ($value && !validate_email($value)) {
                        $valid = false;
                        $errors[$field][] = "Μη έγκυρο email";
                    }
                    break;
                    
                case 'phone':
                    if ($value && !validate_phone($value)) {
                        $valid = false;
                        $errors[$field][] = "Μη έγκυρος αριθμός τηλεφώνου";
                    }
                    break;
                    
                case 'afm':
                    if ($value && !validate_afm($value)) {
                        $valid = false;
                        $errors[$field][] = "Μη έγκυρο ΑΦΜ";
                    }
                    break;
                    
                case 'date':
                    if ($value && !validate_date($value)) {
                        $valid = false;
                        $errors[$field][] = "Μη έγκυρη ημερομηνία";
                    }
                    break;
                    
                case 'min':
                    if (is_string($value) && strlen($value) < $param) {
                        $valid = false;
                        $errors[$field][] = "Τουλάχιστον {$param} χαρακτήρες";
                    }
                    break;
                    
                case 'max':
                    if (is_string($value) && strlen($value) > $param) {
                        $valid = false;
                        $errors[$field][] = "Μέγιστο {$param} χαρακτήρες";
                    }
                    break;
                    
                case 'in':
                    if ($value && !validate_in_array($value, $param)) {
                        $valid = false;
                        $errors[$field][] = "Μη έγκυρη τιμή";
                    }
                    break;
            }
        }
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors
    ];
}
