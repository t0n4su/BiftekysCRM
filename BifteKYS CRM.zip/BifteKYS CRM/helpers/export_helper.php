<?php
/**
 * Export Helper Functions - Updated for XLSX & PHP 8.4 Support
 */

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;

/**
 * Export to CSV (with PHP 8.4 fixes)
 */
function export_to_csv(array $data, array $headers, string $filename): void {
    if (ob_get_length()) {
        ob_clean();
    }
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    fputs($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // UTF-8 BOM
    
    // Προσθήκη έξτρα παραμέτρων ('"', '\\') για αποφυγή PHP 8.4 Deprecated Warning
    fputcsv($output, array_values($headers), ';', '"', '\\');
    
    foreach ($data as $row) {
        $csvRow = [];
        foreach (array_keys($headers) as $key) {
            $csvRow[] = $row[$key] ?? '';
        }
        fputcsv($output, $csvRow, ';', '"', '\\');
    }
    fclose($output);
    exit;
}

/**
 * Real Export to XLSX using PhpSpreadsheet
 */
function export_to_xlsx(array $data, array $headers, string $filename): void {
    if (ob_get_length()) {
        ob_clean();
    }
    
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    
    // Εισαγωγή Headers
    $col = 'A';
    foreach ($headers as $headerTitle) {
        $sheet->setCellValue($col . '1', $headerTitle);
        $sheet->getStyle($col . '1')->getFont()->setBold(true);
        $sheet->getColumnDimension($col)->setAutoSize(true);
        $col++;
    }
    
    // Εισαγωγή Δεδομένων
    $rowNum = 2;
    foreach ($data as $row) {
        $col = 'A';
        foreach (array_keys($headers) as $key) {
            $sheet->setCellValue($col . $rowNum, $row[$key] ?? '');
            $col++;
        }
        $rowNum++;
    }
    
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}

/**
 * Robust CSV Parser (Smart delimiter detection + BOM removal)
 */
function parse_csv(string $filepath, bool $hasHeader = true): array {
    $data = [];
    if (($handle = fopen($filepath, 'r')) !== false) {
        
        $firstLine = fgets($handle);
        if ($firstLine === false) return [];
        
        $delimiter = strpos($firstLine, ';') !== false ? ';' : ',';
        rewind($handle);
        
        $headers = null;
        $rowNum = 0;
        
        while (($row = fgetcsv($handle, 0, $delimiter, '"', '\\')) !== false) {
            $rowNum++;
            
            if ($rowNum === 1 && !empty($row[0])) {
                $row[0] = preg_replace('/^[\xEF\xBB\xBF]+/', '', $row[0]);
            }
            
            if ($hasHeader && $rowNum === 1) { 
                $headers = array_map('trim', $row); 
                continue; 
            }
            
            if ($headers) {
                if (count($headers) === count($row)) {
                    $data[] = array_combine($headers, $row);
                } else {
                    $row = array_pad($row, count($headers), '');
                    $row = array_slice($row, 0, count($headers));
                    $data[] = array_combine($headers, $row);
                }
            } else {
                $data[] = $row;
            }
        }
        fclose($handle);
    }
    return $data;
}

/**
 * Real XLSX Parser using PhpSpreadsheet
 */
function parse_xlsx(string $filepath, bool $hasHeader = true): array {
    $data = [];
    $reader = new XlsxReader();
    $reader->setReadDataOnly(true);
    
    $spreadsheet = $reader->load($filepath);
    $worksheet = $spreadsheet->getActiveSheet();
    $rows = $worksheet->toArray();
    
    if (empty($rows)) {
        return [];
    }
    
    $headers = null;
    foreach ($rows as $index => $row) {
        if ($hasHeader && $index === 0) {
            $headers = array_map(function($val) { return trim((string)$val); }, (array)$row);
            continue;
        }
        
        if ($headers) {
            // Συμπλήρωση των κενών ή αποκοπή περιττών στηλών για να ταιριάζει με τα headers
            $row = array_pad((array)$row, count($headers), '');
            $row = array_slice($row, 0, count($headers));
            $data[] = array_combine($headers, $row);
        } else {
            $data[] = $row;
        }
    }
    return $data;
}

function generate_csv_template(array $headers, string $filename): void {
    export_to_csv([], $headers, $filename);
}

function validate_import_row(array $row, array $rules): array {
    $errors = [];
    foreach ($rules as $field => $rule) {
        $value = $row[$field] ?? null;
        if ($rule['required'] && (empty($value) || trim((string)$value) === '')) {
            $errors[] = "Το πεδίο '{$field}' είναι υποχρεωτικό";
        }
    }
    return ['valid' => empty($errors), 'errors' => $errors];
}