<?php
/**
 * Authentication Class
 * Handles login, logout, role checking, and CSRF protection
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';

class Auth {
    private ?PDO $db;
    private ?array $currentUser = null;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->loadCurrentUser();
    }
    
    /**
     * Check if user is logged in
     * @return bool
     */
    public function isLoggedIn(): bool {
        return $this->currentUser !== null;
    }
    
    /**
     * Get current user
     * @return array|null
     */
    public function getCurrentUser(): ?array {
        return $this->currentUser;
    }
    
    /**
     * Get current user ID
     * @return int|null
     */
    public function getCurrentUserId(): ?int {
        return $this->currentUser ? (int)$this->currentUser['id'] : null;
    }
    
    /**
     * Check if current user has role
     * @param string|array $roles
     * @return bool
     */
    public function hasRole($roles): bool {
        if (!$this->currentUser) return false;
        
        $userRole = $this->currentUser['role'];
        
        if (is_string($roles)) {
            return $userRole === $roles;
        }
        
        return in_array($userRole, $roles, true);
    }
    
    /**
     * Check if user is superadmin
     * @return bool
     */
    public function isSuperAdmin(): bool {
        return $this->hasRole(ROLE_SUPERADMIN);
    }
    
    /**
     * Check if user is admin or superadmin
     * @return bool
     */
    public function isAdminOrSuper(): bool {
        return $this->hasRole([ROLE_ADMIN, ROLE_SUPERADMIN]);
    }
    
    /**
     * Authenticate user with credentials
     * @param string $username
     * @param string $password
     * @return array|null
     */
    public function authenticate(string $username, string $password): ?array {
        $stmt = $this->db->prepare("
            SELECT id, username, code, role, displayname, isactive, password_hash
            FROM users
            WHERE username = ? OR code = ?
            LIMIT 1
        ");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if (!$user) return null;
        
        // Check if user is active
        if (!(int)$user['isactive']) {
            return null;
        }
        
        // Verify password - support both bcrypt and plain text migration
        $valid = false;
        if (!empty($user['password_hash'])) {
            $valid = password_verify($password, $user['password_hash']);
        } else {
            // Legacy: plain text comparison, will be migrated on success
            $valid = ($user['code'] === $password);
        }
        
        if (!$valid) return null;
        
        // Migrate plain text password to bcrypt if needed
        if (empty($user['password_hash']) && $user['code'] === $password) {
            $this->migratePassword($user['id'], $password);
        }
        
        return [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'code' => $user['code'],
            'role' => $user['role'],
            'display_name' => $user['displayname'] ?: $user['username'] ?: $user['code'],
            'is_active' => (bool)$user['isactive']
        ];
    }
    
    /**
     * Login user and create session
     * @param array $user
     */
    public function login(array $user): void {
        initSession();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['login_time'] = time();
        
        // Generate API token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        $stmt = $this->db->prepare("
            UPDATE users 
            SET apitoken = ?, tokenexpiresat = ? 
            WHERE id = ?
        ");
        $stmt->execute([$token, $expires, $user['id']]);
        
        $_SESSION['api_token'] = $token;
        $this->currentUser = $user;
    }
    
    /**
     * Logout user
     */
    public function logout(): void {
        if ($this->currentUser) {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET apitoken = NULL, tokenexpiresat = NULL 
                WHERE id = ?
            ");
            $stmt->execute([$this->currentUser['id']]);
        }
        
        destroySession();
        $this->currentUser = null;
    }
    
    /**
     * Load current user from session
     */
    private function loadCurrentUser(): void {
        initSession();
        
        if (!isset($_SESSION['user_id'])) {
            // Try bearer token
            $token = $this->getBearerToken();
            if ($token) {
                $this->loadUserByToken($token);
            }
            return;
        }
        
        $userId = (int)$_SESSION['user_id'];
        
        $stmt = $this->db->prepare("
            SELECT id, username, code, role, displayname, isactive
            FROM users
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if ($user && (int)$user['isactive']) {
            $this->currentUser = [
                'id' => (int)$user['id'],
                'username' => $user['username'],
                'code' => $user['code'],
                'role' => $user['role'],
                'display_name' => $user['displayname'] ?: $user['username'] ?: $user['code'],
                'is_active' => (bool)$user['isactive']
            ];
        }
    }
    
    /**
     * Load user by API token
     * @param string $token
     */
    private function loadUserByToken(string $token): void {
        $stmt = $this->db->prepare("
            SELECT id, username, code, role, displayname, isactive, tokenexpiresat
            FROM users
            WHERE apitoken = ?
            LIMIT 1
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user || !(int)$user['isactive']) return;
        
        // Check token expiration
        if ($user['tokenexpiresat']) {
            $exp = strtotime($user['tokenexpiresat']);
            if ($exp !== false && $exp < time()) return;
        }
        
        $this->currentUser = [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'code' => $user['code'],
            'role' => $user['role'],
            'display_name' => $user['displayname'] ?: $user['username'] ?: $user['code'],
            'is_active' => (bool)$user['isactive']
        ];
    }
    
    /**
     * Get bearer token from request
     * @return string|null
     */
    private function getBearerToken(): ?string {
        $headers = getallheaders();
        $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
        
        if (stripos($auth, 'Bearer ') === 0) {
            return trim(substr($auth, 7));
        }
        
        return $_GET['token'] ?? null;
    }
    
    /**
     * Migrate plain text password to bcrypt
     * @param int $userId
     * @param string $password
     */
    private function migratePassword(int $userId, string $password): void {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $stmt->execute([$hash, $userId]);
    }
    
    /**
     * Check if user needs to set username
     * @return bool
     */
    public function needsUsernameSetup(): bool {
        if (!$this->currentUser) return false;
        
        $stmt = $this->db->prepare("
            SELECT username FROM users WHERE id = ? LIMIT 1
        ");
        $stmt->execute([$this->currentUser['id']]);
        $result = $stmt->fetch();
        
        return empty($result['username']);
    }
    
    /**
     * Set username for user
     * @param int $userId
     * @param string $username
     * @return array [success, message]
     */
    public function setUsername(int $userId, string $username): array {
        // Validate username
        if (strlen($username) < 3) {
            return ['success' => false, 'message' => 'Το username πρέπει να έχει τουλάχιστον 3 χαρακτήρες'];
        }
        
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            return ['success' => false, 'message' => 'Το username μπορεί να περιέχει μόνο γράμματα, αριθμούς και κάτω παύλες'];
        }
        
        // Check uniqueness
        $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'Αυτό το username χρησιμοποιείται ήδη'];
        }
        
        // Update username
        $stmt = $this->db->prepare("UPDATE users SET username = ? WHERE id = ?");
        $stmt->execute([$username, $userId]);
        
        return ['success' => true, 'message' => 'Το username αποθηκεύτηκε επιτυχώς'];
    }
}
