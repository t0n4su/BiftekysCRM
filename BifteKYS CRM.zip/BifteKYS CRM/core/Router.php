<?php
/**
 * Simple Router Class
 * Routes requests based on $_GET['page'] parameter
 */

class Router {
    private array $routes = [];
    private string $basePath;
    
    public function __construct(string $basePath = '') {
        $this->basePath = $basePath;
    }
    
    public function register(string $page, string $controller, string $action, array $middleware = []): void {
        $this->routes[$page] = [
            'controller' => $controller,
            'action' => $action,
            'middleware' => $middleware
        ];
    }
    
    public function dispatch(): void {
        $page = $_GET['page'] ?? 'home';
        $actionFromUrl = $_GET['action'] ?? null; // Πιάνουμε το action από το URL

        if (!isset($this->routes[$page])) {
            $this->handle404();
            return;
        }
        
        $route = $this->routes[$page];
        
        foreach ($route['middleware'] as $middleware) {
            if (!$this->runMiddleware($middleware)) {
                return;
            }
        }
        
        $controllerClass = $route['controller'];
        // Αν υπάρχει action στο URL (π.χ. export), το καλούμε. Αλλιώς, το default action της σελίδας.
        $action = $actionFromUrl ?: $route['action'];
        
        if (!class_exists($controllerClass)) {
            $this->handle500("Controller class not found: $controllerClass");
            return;
        }
        
        $controller = new $controllerClass();
        
        if (!method_exists($controller, $action)) {
            $this->handle500("Action not found: $action");
            return;
        }
        
        $controller->$action();
    }
    
    private function runMiddleware(string $middleware): bool {
        $auth = new Auth();
        switch ($middleware) {
            case 'auth':
                if (!$auth->isLoggedIn()) {
                    header('Location: ?page=login');
                    return false;
                }
                return true;
            case 'guest':
                if ($auth->isLoggedIn()) {
                    header('Location: ?page=dashboard');
                    return false;
                }
                return true;
            case 'admin':
                return $this->requireRole(['admin', 'superadmin'], $auth);
            case 'superadmin':
                return $this->requireRole(['superadmin'], $auth);
            
            default:
                return true;

        }
    }
    
    private function requireRole(array $roles, Auth $auth): bool {
        $user = $auth->getCurrentUser();
        if (!$user || !in_array($user['role'], $roles, true)) {
            http_response_code(403);
            echo 'Forbidden';
            return false;
        }
        return true;
    }
    
    private function handle404(): void {
        http_response_code(404);
        if (file_exists(__DIR__ . '/../views/errors/404.php')) {
            include __DIR__ . '/../views/errors/404.php';
        } else {
            echo "404 - Not Found";
        }
    }
    
    private function handle500(string $message): void {
        http_response_code(500);
        error_log($message);
        echo 'Internal Server Error';
    }
}