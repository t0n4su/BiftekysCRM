<?php
/**
 * Database Singleton Wrapper (PDO)
 * Provides convenient database access methods
 */

require_once __DIR__ . '/../config/database.php';

class Database {
    private static ?PDO $instance = null;
    
    /**
     * Get PDO instance
     * @return PDO
     */
    public static function getInstance(): PDO {
        if (self::$instance === null) {
            self::$instance = getDBConnection();
        }
        return self::$instance;
    }
    
    /**
     * Execute a query with parameters
     * @param string $sql
     * @param array $params
     * @return PDOStatement
     */
    public static function query(string $sql, array $params = []): PDOStatement {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
    
    /**
     * Fetch all rows
     * @param string $sql
     * @param array $params
     * @return array
     */
    public static function fetchAll(string $sql, array $params = []): array {
        return self::query($sql, $params)->fetchAll();
    }
    
    /**
     * Fetch single row
     * @param string $sql
     * @param array $params
     * @return array|null
     */
    public static function fetchOne(string $sql, array $params = []): ?array {
        $result = self::query($sql, $params)->fetch();
        return $result ?: null;
    }
    
    /**
     * Fetch single column
     * @param string $sql
     * @param array $params
     * @return mixed
     */
    public static function fetchColumn(string $sql, array $params = []) {
        return self::query($sql, $params)->fetchColumn();
    }
    
    /**
     * Insert and get last ID
     * @param string $table
     * @param array $data
     * @return int
     */
    public static function insert(string $table, array $data): int {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
        self::query($sql, array_values($data));
        
        return (int)self::getInstance()->lastInsertId();
    }
    
    /**
     * Update records
     * @param string $table
     * @param array $data
     * @param string $where
     * @param array $whereParams
     * @return int
     */
    public static function update(string $table, array $data, string $where, array $whereParams = []): int {
        $sets = [];
        foreach (array_keys($data) as $column) {
            $sets[] = "{$column} = ?";
        }
        
        $sql = "UPDATE {$table} SET " . implode(', ', $sets) . " WHERE {$where}";
        $stmt = self::query($sql, array_merge(array_values($data), $whereParams));
        
        return $stmt->rowCount();
    }
    
    /**
     * Delete records
     * @param string $table
     * @param string $where
     * @param array $params
     * @return int
     */
    public static function delete(string $table, string $where, array $params = []): int {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $stmt = self::query($sql, $params);
        return $stmt->rowCount();
    }
    
    /**
     * Begin transaction
     */
    public static function beginTransaction(): void {
        self::getInstance()->beginTransaction();
    }
    
    /**
     * Commit transaction
     */
    public static function commit(): void {
        self::getInstance()->commit();
    }
    
    /**
     * Rollback transaction
     */
    public static function rollback(): void {
        self::getInstance()->rollBack();
    }
    
    /**
     * Quote identifier
     * @param string $identifier
     * @return string
     */
    public static function quoteIdentifier(string $identifier): string {
        return '`' . str_replace('`', '``', $identifier) . '`';
    }
}
