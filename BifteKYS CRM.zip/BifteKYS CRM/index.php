<?php
/**
 * CleverPartnersCRM - Main Entry Point
 * MVC-inspired architecture with routing
 */

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Set timezone
date_default_timezone_set('Europe/Athens');

// Start session
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config/session.php';
initSession();

// Include core files
require_once __DIR__ . '/core/Router.php';
require_once __DIR__ . '/core/Auth.php';
require_once __DIR__ . '/helpers/functions.php';


// ... ο υπόλοιπος κώδικας του index.php παραμένει ως έχει ...

// Include controllers
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/ApplicationController.php';
require_once __DIR__ . '/controllers/UserController.php';
require_once __DIR__ . '/controllers/ReportController.php';
require_once __DIR__ . '/controllers/FieldController.php';

// Initialize router
$router = new Router();

// Μετά την υπάρχουσα εγγραφή των applications
$router->register('applications', 'ApplicationController', 'list', ['auth']);
// Προσθέστε αυτή τη γραμμή:
$router->register('applications-export', 'ApplicationController', 'export', ['auth']);
// Auth routes
$router->register('login', 'AuthController', 'login', ['guest']);
$router->register('logout', 'AuthController', 'logout', ['auth']);
$router->register('set-username', 'AuthController', 'setUsername', ['auth']);

// Dashboard
$router->register('dashboard', 'ApplicationController', 'dashboard', ['auth']);
$router->register('home', 'ApplicationController', 'dashboard', ['auth']);

// Application routes
$router->register('applications', 'ApplicationController', 'list', ['auth']);

// User routes
$router->register('users', 'UserController', 'tree', ['auth']);

// Report routes
$router->register('reports', 'ReportController', 'index', ['auth']);

// Field routes (superadmin only)
$router->register('fields', 'FieldController', 'manager', ['auth']);
$router->register('profile', 'UserController', 'profile', ['auth']);
if (isset($_GET['action']) && $_GET['action'] == 'download') {
    die("ΜΠΗΚΕ ΣΤΟ CONTROLLER!");
}
// Handle API requests
$apiPath = $_GET['api'] ?? '';
if ($apiPath) {
    handleApiRequest($apiPath);
    exit;
}

// Handle legacy action parameter for backward compatibility
$page = $_GET['page'] ?? 'dashboard';
$action = $_GET['action'] ?? '';

// Route to appropriate controller based on page and action
switch ($page) {
    case 'applications':
        $controller = new ApplicationController();
        switch ($action) {
            case 'profile':
                include 'views/profile.php'; // Ή κάποιος Controller
                break;            
            case 'create':
                $controller->create();
                break;
            case 'edit':
                $controller->edit();
                break;
            case 'stats':
                $controller->stats();
                break;
            case 'drafts':
                $controller->drafts();
                break;
            case 'edit-draft':
                $controller->editDraft();
                break;
            case 'import':
                $controller->import();
                break;
            case 'export':
                $controller->export();
                break;    
            case 'download-template':
                $controller->downloadTemplate();
                break;
            case 'download':
                $controller->download();
                break;
            case 'delete_attachment':
                $controller->delete_attachment();
                break;    
            default:
                $controller->list();
        }
        break;
        
    case 'users':
        $controller = new UserController();
        switch ($action) {
            case 'tree':
                $controller->tree();
                break;
            case 'manage':
            default:
                $controller->manage(); // Πλέον η προεπιλογή είναι η Διαχείριση
        }
        break;
        
    case 'reports':
        $controller = new ReportController();
        switch ($action) {
            case 'export':
                $controller->export();
                break;
            default:
                $controller->index();
        }
        break;
        
    case 'fields':
        $controller = new FieldController();
        $controller->manager();
        break;

    // ΠΡΟΣΘΕΣΕ ΑΥΤΟ ΕΔΩ:
    case 'profile':
        $controller = new UserController();
        $controller->profile();
        break;
        
    case 'login':
        $controller = new AuthController();
        $controller->login();
        break;
        
    case 'logout':
        $controller = new AuthController();
        $controller->logout();
        break;
        
    case 'set-username':
        $controller = new AuthController();
        $controller->setUsername();
        break;
        
    default:
        // Default to dashboard
        $controller = new ApplicationController();
        $controller->dashboard(); // Η ΔΙΟΡΘΩΣΗ ΕΙΝΑΙ ΕΔΩ
}

/**
 * Handle API requests
 * @param string $path
 */
function handleApiRequest(string $path): void {
    header('Content-Type: application/json; charset=utf-8');
    
    $parts = explode('/', trim($path, '/'));
    $resource = $parts[0] ?? '';
    $action = $parts[1] ?? '';
    
    switch ($resource) {
        case 'auth':
            $controller = new AuthController();
            switch ($action) {
                case 'login':
                    $controller->apiLogin();
                    break;
                case 'logout':
                    $controller->apiLogout();
                    break;
                case 'set-username':
                    $controller->apiSetUsername();
                    break;
                default:
                    json_error('Unknown auth action', 404);
            }
            break;
            
        case 'applications':
            $controller = new ApplicationController();
            switch ($action) {
                case 'list':
                    $controller->apiList();
                    break;
                case 'get':
                    $controller->apiGet();
                    break;
                case 'create':
                    // Handle via POST
                    break;
                case 'update':
                    // Handle via POST
                    break;
                case 'delete':
                    $controller->delete();
                    break;
                case 'update-status':
                    $controller->updateStatus();
                    break;
                case 'update-notes':
                    $controller->updateNotes();
                    break;
                case 'save-draft':
                    handleDraftSave();
                    break;
                case 'submit-draft':
                    handleDraftSubmit();
                    break;
                case 'delete-draft':
                    handleDraftDelete();
                    break;
                default:
                    json_error('Unknown application action', 404);
            }
            break;
            
        case 'users':
            $controller = new UserController();
            switch ($action) {
                case 'list':
                    $controller->apiList();
                    break;
                case 'tree':
                    $controller->apiTree();
                    break;
                case 'create':
                    $controller->apiCreate();
                    break;
                case 'update':
                    $controller->apiUpdate();
                    break;
                default:
                    json_error('Unknown user action', 404);
            }
            break;
            
        case 'reports':
            $controller = new ReportController();
            switch ($action) {
                case 'data':
                    $controller->apiData();
                    break;
                case 'stats':
                    $controller->apiStats();
                    break;
                default:
                    json_error('Unknown report action', 404);
            }
            break;
            
        case 'fields':
            $controller = new FieldController();
            switch ($action) {
                case 'list':
                    $controller->apiList();
                    break;
                case 'create':
                    $controller->apiCreate();
                    break;
                case 'update':
                    $controller->apiUpdate();
                    break;
                case 'toggle':
                    $controller->apiToggle();
                    break;
                case 'delete':
                    $controller->apiDelete();
                    break;
                case 'save':
                    $controller->apiSave();
                    break;
                default:
                    json_error('Unknown field action', 404);
            }
            break;
            
        case 'customers':
            handleCustomerApi($action);
            break;
            
        default:
            json_error('Unknown API resource', 404);
    }
}

/**
 * Handle draft submission
 */
function handleDraftSubmit(): void {
    require_once __DIR__ . '/core/Auth.php';
    require_once __DIR__ . '/core/Database.php';
    require_once __DIR__ . '/models/Application.php';
    require_once __DIR__ . '/helpers/functions.php';
    
    $auth = new Auth();
    if (!$auth->isLoggedIn()) {
        json_error('Unauthorized', 401);
    }
    
    $draftId = (int)($_POST['id'] ?? 0);
    $user = $auth->getCurrentUser();
    
    // Get draft
    $draft = Database::fetchOne(
        "SELECT * FROM application_drafts WHERE id = ? AND user_id = ?",
        [$draftId, $user['id']]
    );
    
    if (!$draft) {
        json_error('Draft not found', 404);
    }
    
    $data = json_decode($draft['data'], true);
    
    // Create application
    $appModel = new Application();
    try {
        $appId = $appModel->create(array_merge($data, [
            'user_id' => $user['id'],
            'partner_code' => $user['code'],
        ]));
        
        // Delete draft
        Database::delete('application_drafts', 'id = ?', [$draftId]);
        
        json_success(['application_id' => $appId], 'Η αίτηση υποβλήθηκε επιτυχώς');
    } catch (Throwable $e) {
        json_error('Failed to submit: ' . $e->getMessage(), 500);
    }
}

/**
 * Handle draft deletion
 */
function handleDraftDelete(): void {
    require_once __DIR__ . '/core/Auth.php';
    require_once __DIR__ . '/core/Database.php';
    require_once __DIR__ . '/helpers/functions.php';
    
    $auth = new Auth();
    if (!$auth->isLoggedIn()) {
        json_error('Unauthorized', 401);
    }
    
    $draftId = (int)($_POST['id'] ?? 0);
    $user = $auth->getCurrentUser();
    
    $result = Database::delete(
        'application_drafts',
        'id = ? AND user_id = ?',
        [$draftId, $user['id']]
    );
    
    if ($result > 0) {
        json_success([], 'Το draft διαγράφηκε');
    } else {
        json_error('Draft not found', 404);
    }
}

function handleDraftSave(): void {
    require_once __DIR__ . '/core/Auth.php';
    require_once __DIR__ . '/core/Database.php';
    require_once __DIR__ . '/helpers/functions.php';
    
    $auth = new Auth();
    if (!$auth->isLoggedIn()) {
        json_error('Unauthorized', 401);
    }
    
    $user = $auth->getCurrentUser();
    
    // Η Javascript στέλνει JSON στο body
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        json_error('Invalid data', 400);
    }
    
    // Ελέγχουμε αν υπάρχει ήδη ID από το URL (π.χ. αν κάνουμε συνέχεια επεξεργασίας)
    $draftId = 0;
    if (!empty($data['_draft_meta']['url'])) {
        $urlParts = parse_url($data['_draft_meta']['url']);
        if (isset($urlParts['query'])) {
            parse_str($urlParts['query'], $query);
            if (isset($query['id']) && ($query['action'] ?? '') === 'edit-draft') {
                $draftId = (int)$query['id'];
            }
        }
    }
    
    try {
        if ($draftId) {
            // Update
            Database::query("UPDATE application_drafts SET data = ?, updated_at = NOW() WHERE id = ? AND user_id = ?", [json_encode($data), $draftId, $user['id']]);
        } else {
            // Insert
            Database::query("INSERT INTO application_drafts (user_id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())", [$user['id'], json_encode($data)]);
        }
        json_success(['message' => 'Draft saved']);
    } catch (Throwable $e) {
        json_error('Save failed: ' . $e->getMessage(), 500);
    }
}
/**
 * Handle customer API
 * @param string $action
 */
function handleCustomerApi(string $action): void {
    require_once __DIR__ . '/models/Customer.php';
    
    $auth = new Auth();
    if (!$auth->isLoggedIn()) {
        json_error('Unauthorized', 401);
    }
    
    $customerModel = new Customer();
    
    switch ($action) {
        case 'search-afm':
            $afm = $_GET['afm'] ?? '';
            if (!$afm || !preg_match('/^[0-9]{9}$/', $afm)) {
                json_error('Invalid AFM', 400);
            }
            
            $customer = $customerModel->getByAfm($afm);
            $count = $customerModel->getApplicationCount($afm);
            
            json_success([
                'found' => $customer !== null,
                'customer' => $customer,
                'application_count' => $count,
            ]);
            break;
            
        default:
            json_error('Unknown customer action', 404);
    }
}
