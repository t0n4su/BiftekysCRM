<?php
/**
 * API: Save custom field
 * AJAX endpoint for field builder
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../helpers/functions.php';

header('Content-Type: application/json; charset=utf-8');

$auth = new Auth();

// Check authentication and superadmin
if (!$auth->isLoggedIn()) {
    json_error('Unauthorized', 401);
}

if (!$auth->isSuperAdmin()) {
    json_error('Forbidden - SuperAdmin only', 403);
}

// Check CSRF
$headers = getallheaders();
$csrfToken = $headers['X-CSRF-Token'] ?? '';
if (!validateCsrfToken($csrfToken)) {
    json_error('Invalid CSRF token', 403);
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    json_error('Invalid data', 400);
}

// Validate required fields
if (empty($data['field_label'])) {
    json_error('Field label is required', 400);
}

if (empty($data['field_name'])) {
    json_error('Field name is required', 400);
}

// Validate field name format
if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $data['field_name'])) {
    json_error('Invalid field name format. Must start with letter, contain only letters, numbers, and underscores.', 400);
}

// Check reserved words
$reserved = ['id', 'select', 'insert', 'update', 'delete', 'from', 'where', 'order', 'group', 'having', 'limit'];
if (in_array(strtolower($data['field_name']), $reserved, true)) {
    json_error('Field name is a reserved SQL keyword', 400);
}

// Validate field type
$validTypes = ['text', 'number', 'email', 'date', 'textarea', 'dropdown', 'checkbox', 'radio', 'file'];
if (!in_array($data['field_type'], $validTypes, true)) {
    json_error('Invalid field type', 400);
}

try {
    $db = Database::getInstance();
    
    // Ensure custom_fields table exists
    $db->exec("
        CREATE TABLE IF NOT EXISTS custom_fields (
            id INT AUTO_INCREMENT PRIMARY KEY,
            field_label VARCHAR(255) NOT NULL,
            field_name VARCHAR(100) NOT NULL UNIQUE,
            field_type VARCHAR(50) NOT NULL,
            options_json TEXT,
            is_required TINYINT(1) DEFAULT 0,
            display_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_active_order (is_active, display_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    $fieldId = $data['id'] ?? null;
    
    if ($fieldId) {
        // Update existing field - only metadata, not column name
        $existing = Database::fetchOne(
            "SELECT field_name FROM custom_fields WHERE id = ?",
            [$fieldId]
        );
        
        if (!$existing) {
            json_error('Field not found', 404);
        }
        
        Database::update('custom_fields', [
            'field_label' => $data['field_label'],
            'field_type' => $data['field_type'],
            'options_json' => !empty($data['options']) ? json_encode($data['options']) : null,
            'is_required' => !empty($data['is_required']) ? 1 : 0,
            'display_order' => (int)($data['display_order'] ?? 0),
            'is_active' => isset($data['is_active']) ? ($data['is_active'] ? 1 : 0) : 1,
        ], 'id = ?', [$fieldId]);
        
        json_success(['field_id' => $fieldId], 'Field updated successfully');
        
    } else {
        // Check if field name already exists
        $existing = Database::fetchOne(
            "SELECT id FROM custom_fields WHERE field_name = ?",
            [$data['field_name']]
        );
        
        if ($existing) {
            json_error('Field name already exists', 400);
        }
        
        // Add column to applications table
        $columnName = Database::quoteIdentifier($data['field_name']);
        
        try {
            $db->exec("ALTER TABLE applications ADD COLUMN {$columnName} TEXT NULL");
        } catch (Throwable $e) {
            // Column might already exist, continue
            error_log('Column add warning: ' . $e->getMessage());
        }
        
        // Insert field metadata
        $fieldId = Database::insert('custom_fields', [
            'field_label' => $data['field_label'],
            'field_name' => $data['field_name'],
            'field_type' => $data['field_type'],
            'options_json' => !empty($data['options']) ? json_encode($data['options']) : null,
            'is_required' => !empty($data['is_required']) ? 1 : 0,
            'display_order' => (int)($data['display_order'] ?? 0),
            'is_active' => 1,
        ]);
        
        json_success(['field_id' => $fieldId], 'Field created successfully');
    }
    
} catch (Throwable $e) {
    error_log('Field save error: ' . $e->getMessage());
    json_error('Failed to save field: ' . $e->getMessage(), 500);
}
