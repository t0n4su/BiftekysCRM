<?php
/**
 * API: Search customer by AFM
 * AJAX endpoint for AFM search
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../helpers/functions.php';

header('Content-Type: application/json; charset=utf-8');

$auth = new Auth();

// Check authentication
if (!$auth->isLoggedIn()) {
    json_error('Unauthorized', 401);
}

// Get AFM from request
$afm = $_GET['afm'] ?? '';

// Validate AFM
if (!$afm || !preg_match('/^[0-9]{9}$/', $afm)) {
    json_error('Invalid AFM format. Must be 9 digits.', 400);
}

// Validate AFM checksum
if (!validate_afm($afm)) {
    json_error('Invalid AFM checksum.', 400);
}

// Search for customer
$customerModel = new Customer();
$customer = $customerModel->getByAfm($afm);

if ($customer) {
    // Get application count
    $appCount = $customerModel->getApplicationCount($afm);
    
    json_success([
        'found' => true,
        'customer' => $customer,
        'application_count' => $appCount,
    ]);
} else {
    json_success([
        'found' => false,
        'message' => 'Δεν βρέθηκε πελάτης με αυτό το ΑΦΜ.',
    ]);
}
