<?php
/**
 * API: Save application draft
 * AJAX endpoint for autosave functionality (1 draft per application)
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../helpers/functions.php';

header('Content-Type: application/json; charset=utf-8');

$auth = new Auth();

// Check authentication
if (!$auth->isLoggedIn()) {
    json_error('Unauthorized', 401);
}

// Check CSRF
$headers = getallheaders();
$csrfToken = $headers['X-CSRF-Token'] ?? '';
if (!validateCsrfToken($csrfToken)) {
    json_error('Invalid CSRF token', 403);
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    json_error('Invalid data', 400);
}

$user = $auth->getCurrentUser();

// Εύρεση του Application ID (Αν υπάρχει, π.χ. σε Επεξεργασία. Αν είναι δημιουργία, θα είναι null)
$appId = null;
if (!empty($data['id'])) {
    $appId = (int)$data['id'];
} elseif (!empty($data['application_id'])) {
    $appId = (int)$data['application_id'];
}

// Save draft to database
try {
    $db = Database::getInstance();
    
    // Check if drafts table exists, create if not
    $db->exec("
        CREATE TABLE IF NOT EXISTS application_drafts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            application_id INT NULL, 
            data JSON NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id),
            INDEX idx_app_id (application_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    
    // Προσπάθεια προσθήκης της στήλης application_id αν ο πίνακας υπήρχε ήδη με την παλιά δομή
    try {
        $db->exec("ALTER TABLE application_drafts ADD COLUMN application_id INT NULL AFTER user_id");
        $db->exec("CREATE INDEX idx_app_id ON application_drafts(application_id)");
    } catch (Throwable $e) {
        // Αν σκάσει σημαίνει ότι η στήλη υπάρχει ήδη, το αγνοούμε!
    }
    
    // Ψάχνουμε να βρούμε αν υπάρχει ΗΔΗ draft για αυτήν την αίτηση και αυτόν τον χρήστη
    if ($appId > 0) {
        // Για υπάρχουσα αίτηση (Επεξεργασία)
        $existing = Database::fetchOne(
            "SELECT id FROM application_drafts WHERE user_id = ? AND application_id = ?",
            [$user['id'], $appId]
        );
    } else {
        // Για νέα αίτηση (Δημιουργία)
        $existing = Database::fetchOne(
            "SELECT id FROM application_drafts WHERE user_id = ? AND application_id IS NULL",
            [$user['id']]
        );
    }
    
    if ($existing) {
        // Update existing draft
        Database::update('application_drafts', [
            'data' => json_encode($data),
        ], 'id = ?', [$existing['id']]);
        
        $draftId = $existing['id'];
    } else {
        // Create new draft
        $draftId = Database::insert('application_drafts', [
            'user_id' => $user['id'],
            'application_id' => $appId > 0 ? $appId : null,
            'data' => json_encode($data),
        ]);
    }
    
    json_success([
        'draft_id' => $draftId,
        'saved_at' => date('Y-m-d H:i:s'),
    ], 'Draft αποθηκεύτηκε επιτυχώς');
    
} catch (Throwable $e) {
    error_log('Draft save error: ' . $e->getMessage());
    json_error('Failed to save draft: ' . $e->getMessage(), 500);
}