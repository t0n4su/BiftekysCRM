<?php
/**
 * API: Get statistics data
 * AJAX endpoint for charts and statistics
 */

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Application.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/functions.php';

header('Content-Type: application/json; charset=utf-8');

$auth = new Auth();

// Check authentication
if (!$auth->isLoggedIn()) {
    json_error('Unauthorized', 401);
}

$user = $auth->getCurrentUser();
$userIds = [$user['id']];

// Admin/superadmin can see all
if ($auth->isAdminOrSuper()) {
    $userIds = [];
} else {
    // Get downline IDs
    $userModel = new User();
    $userIds = $userModel->getDownlineIds($user['id']);
}

$appModel = new Application();

// Get stats type
$type = $_GET['type'] ?? 'all';

$response = [];

switch ($type) {
    case 'summary':
        $response['stats'] = $appModel->getStats($userIds);
        break;
        
    case 'daily':
        $days = (int)($_GET['days'] ?? 30);
        $response['daily'] = $appModel->getDailyStats($days, $userIds);
        break;
        
    case 'monthly':
        $months = (int)($_GET['months'] ?? 12);
        $response['monthly'] = $appModel->getMonthlyStats($months, $userIds);
        break;
        
    case 'partners':
        $limit = (int)($_GET['limit'] ?? 10);
        $response['partners'] = $appModel->getPartnerStats($limit, $userIds);
        break;
        
    case 'all':
    default:
        $response['stats'] = $appModel->getStats($userIds);
        $response['daily'] = $appModel->getDailyStats(30, $userIds);
        $response['monthly'] = $appModel->getMonthlyStats(12, $userIds);
        $response['partners'] = $appModel->getPartnerStats(10, $userIds);
        break;
}

json_success($response);
