<?php
/**
 * Global Constants and Configuration
 */

// Application Constants
define('APP_NAME', 'BiftekysCRM');
define('APP_VERSION', '2.0.0');
define('APP_URL', ''); // Set your base URL

// Session Configuration
define('SESSION_NAME', 'biftekyscrm_session');
define('SESSION_LIFETIME', 86400 * 30); // 30 days

// User Roles
define('ROLE_SUPERADMIN', 'superadmin');
define('ROLE_ADMIN', 'admin');
define('ROLE_PARTNER', 'partner');

// Application Statuses
$APPLICATION_STATUSES = [
    'ΝΕΟ' => ['label' => 'ΝΕΟ', 'class' => 'pending'],
    'ΚΑΤΑΧΩΡΗΜΕΝΟ' => ['label' => 'ΚΑΤΑΧΩΡΗΜΕΝΟ', 'class' => 'registered'],
    'ΕΚΚΡΕΜΟΤΗΤΑ' => ['label' => 'ΕΚΚΡΕΜΟΤΗΤΑ', 'class' => 'pending'],
    'ΑΚΥΡΟ' => ['label' => 'ΑΚΥΡΟ', 'class' => 'cancelled'],
    'ΕΝΕΡΓΟ' => ['label' => 'ΕΝΕΡΓΟ', 'class' => 'active'],
];

// Request Types
$REQUEST_TYPES = [
    'ΣΤΑΘΕΡΟ' => 'ΣΤΑΘΕΡΟ',
    'ΚΙΝΗΤΟ' => 'ΚΙΝΗΤΟ',
];

// Landline Programs
$LANDLINE_PROGRAMS = [
    'DP GR+300 - ADSL 24' => 'DP GR+300 - ADSL 24',
    'DP GR+360 - VDSL50' => 'DP GR+360 - VDSL50',
    'DP GR+360 - FTTC100' => 'DP GR+360 - FTTC100',
    'DP GR+360 - FTTH100' => 'DP GR+360 - FTTH100',
    'DP GR+360 - FTTH200' => 'DP GR+360 - FTTH200',
    'DP GR UNL- FTTH300' => 'DP GR UNL- FTTH300',
    'ONENET LTE' => 'ONENET LTE',
    'ONENET 5G/4G+' => 'ONENET 5G/4G+',
    'ONENET OFFICE ADSL' => 'ONENET OFFICE ADSL',
    'ONENET OFFICE VDSL 50' => 'ONENET OFFICE VDSL 50',
    'ONENET OFFICE FTTC 100' => 'ONENET OFFICE FTTC 100',
    'ONENET OFFICE FTTH 100' => 'ONENET OFFICE FTTH 100',
    'ONENET OFFICE FTTH 200' => 'ONENET OFFICE FTTH 200',
    'ONENET OFFICE FTTH 300' => 'ONENET OFFICE FTTH 300',
    'ONENET OFFICE FTTH 500' => 'ONENET OFFICE FTTH 500',
    'ONENET OFFICE FTTH 1000' => 'ONENET OFFICE FTTH 1000',
];

// Mobile Programs
$MOBILE_PROGRAMS = [
    'RETAIL RED 5GB' => 'RETAIL RED 5GB',
    'RETAIL RED 10GB' => 'RETAIL RED 10GB',
    'RETAIL RED 20GB' => 'RETAIL RED 20GB',
    'RETAIL RED UNLIMITED' => 'RETAIL RED UNLIMITED',
    'BUSINESS 10GB' => 'BUSINESS 10GB',
    'BUSINESS 30GB' => 'BUSINESS 30GB',
    'BUSINESS UNLIMITED' => 'BUSINESS UNLIMITED',
];

// Upload Configuration
define('UPLOAD_DIR', __DIR__ . '/../uploads');
define('UPLOAD_MAX_FILESIZE', 50 * 1024 * 1024); // 50MB per file
define('UPLOAD_MAX_TOTAL', 200 * 1024 * 1024); // 200MB total
define('UPLOAD_ALLOWED_TYPES', json_encode([
    'application/pdf', 'image/jpeg', 'image/png', 'image/webp',
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain', 'application/zip', 'application/x-rar-compressed',
]));

// Pagination
define('DEFAULT_PAGE_SIZE', 50);
define('MAX_PAGE_SIZE', 5000);

// Encryption
define('ENCRYPTION_KEY', '22503aaf8211a9267b7d638818e9b420a6d4571bd9e18d141ff7d8c4d684892b');

// Fields to encrypt
$ENCRYPTED_FIELDS = [
    'first_name', 'last_name', 'father_name',
    'afm', 'adt', 'dou', 'date_of_birth',
    'company', 'company_afm',
    'landline_phone', 'mobile_phone',
    'application_number', 'price',
    'install_address', 'billing_address', 'email'
];
