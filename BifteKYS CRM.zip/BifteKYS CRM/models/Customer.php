<?php
/**
 * Customer Model
 * Handles customer data operations (separate from applications)
 * Used for AFM search and customer management
 */

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/User.php';
require_once __DIR__ . '/Application.php';

class Customer {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Υπολογίζει αυτόματα τα IDs του δέντρου
     */
    private function getMyTreeIds(): array {
        try {
            $auth = new Auth();
            $user = $auth->getCurrentUser();
            
            if (!$user || !isset($user['id'])) return [-1]; 
            if (($user['role'] ?? '') === 'admin') return []; 
            
            $userModel = new User();
            $treeIds = [];
            
            if (method_exists($userModel, 'getDownlineIds')) {
                $treeIds = $userModel->getDownlineIds($user['id']);
            } elseif (method_exists($userModel, 'getTreeIds')) {
                $treeIds = $userModel->getTreeIds($user['id']);
            }
            
            $treeIds[] = $user['id']; 
            return array_unique(array_map('intval', $treeIds));
            
        } catch (Throwable $e) {
            return [-1];
        }
    }

    /**
     * [ΝΕΟ] Ελέγχει την πρόσβαση στον πελάτη βάσει των Αιτήσεών του
     */
    private function userHasAccessToCustomer(string $afm): bool {
        $allowed_user_ids = $this->getMyTreeIds();
        
        // Αν είναι Admin έχει πρόσβαση παντού
        if (empty($allowed_user_ids)) return true;
        if (in_array(-1, $allowed_user_ids)) return false;

        // Φέρνουμε όλες τις αιτήσεις αυτού του ΑΦΜ
        $appModel = new Application();
        $applications = [];
        
        if (method_exists($appModel, 'searchByAfm')) {
            $applications = $appModel->searchByAfm($afm);
        }

        // Αν ο πελάτης δεν έχει ΚΑΜΙΑ αίτηση, δεν ανήκει πουθενά, άρα κλειδώνεται
        if (empty($applications)) return false;

        foreach ($applications as $app) {
            // Δοκιμάζουμε να βρούμε τον χρήστη της αίτησης
            $appUser = $app['user_id'] ?? $app['created_by'] ?? $app['agent_id'] ?? $app['seller_id'] ?? null;
            
            // Αν το Array της αίτησης δεν είχε το ID του χρήστη, το τραβάμε απευθείας από τη βάση
            if ($appUser === null && isset($app['id'])) {
                try {
                    $stmt = $this->db->prepare("SELECT * FROM applications WHERE id = :id LIMIT 1");
                    $stmt->execute(['id' => $app['id']]);
                    $dbApp = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($dbApp) {
                        $appUser = $dbApp['user_id'] ?? $dbApp['created_by'] ?? $dbApp['agent_id'] ?? $dbApp['seller_id'] ?? null;
                    }
                } catch(Throwable $ex) {}
            }

            // Ελέγχουμε αν ο χρήστης της αίτησης ανήκει στο δέντρο μας
            if ($appUser !== null && in_array((int)$appUser, $allowed_user_ids)) {
                return true; // Βρέθηκε έστω 1 αίτηση στο δέντρο μας, άρα έχουμε πρόσβαση!
            }
        }

        return false; // Καμία αίτηση του πελάτη δεν ανήκει στο δέντρο μας
    }
    
    /**
     * Get customer by AFM
     */
    public function getByAfm(string $afm, array $ignored_param = []): ?array {
        // Επαναφορά στο αρχικό SQL που δεν "σκάει"
        $sql = "
            SELECT DISTINCT 
                firstname, lastname, fathername, afm, adt, dou,
                dateofbirth, company, companyafm,
                landline_phone, mobile_phone, email,
                install_address, billing_address
            FROM customers
            WHERE afm IS NOT NULL
            LIMIT 5000
        ";
        
        $results = Database::fetchAll($sql);
        
        foreach ($results as $row) {
            if (!empty($row['afm'])) {
                try {
                    $decryptedAfm = decrypt_data($row['afm']);
                    if ($decryptedAfm === $afm) {
                        
                        // [ ΕΛΕΓΧΟΣ ΑΣΦΑΛΕΙΑΣ ]
                        if ($this->userHasAccessToCustomer($afm)) {
                            return $this->normalizeCustomer($row);
                        } else {
                            return null; // Υπάρχει ο πελάτης, αλλά δεν έχουμε δικαίωμα πρόσβασης (Ρίχνει πόρτα)
                        }
                    }
                } catch (Throwable $e) {
                    continue;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Search customers by AFM (partial match)
     */
    public function searchByAfm(string $afm, array $ignored_param = []): array {
        $sql = "
            SELECT DISTINCT 
                firstname, lastname, fathername, afm, adt, dou,
                dateofbirth, company, companyafm,
                landline_phone, mobile_phone, email,
                install_address, billing_address
            FROM customers
            WHERE afm IS NOT NULL
            LIMIT 1000
        ";
        
        $results = Database::fetchAll($sql);
        $customers = [];
        
        foreach ($results as $row) {
            if (!empty($row['afm'])) {
                try {
                    $decryptedAfm = decrypt_data($row['afm']);
                    if (strpos($decryptedAfm, $afm) === 0) {
                        
                        // [ ΕΛΕΓΧΟΣ ΑΣΦΑΛΕΙΑΣ ]
                        if ($this->userHasAccessToCustomer($decryptedAfm)) {
                            $customers[] = $this->normalizeCustomer($row);
                        }
                    }
                } catch (Throwable $e) {
                    continue;
                }
            }
        }
        
        return $customers;
    }
    
    /**
     * Get customer application count
     */
    public function getApplicationCount(string $afm, array $ignored_param = []): int {
        $sql = "SELECT afm FROM customers WHERE afm IS NOT NULL";
        $results = Database::fetchAll($sql);
        
        $count = 0;
        foreach ($results as $row) {
            if (!empty($row['afm'])) {
                try {
                    $decryptedAfm = decrypt_data($row['afm']);
                    if ($decryptedAfm === $afm) {
                        $count++;
                    }
                } catch (Throwable $e) {
                    continue;
                }
            }
        }
        
        return $count;
    }
    
    /**
     * Get applications by customer AFM
     */
    public function getApplicationsByAfm(string $afm): array {
        $appModel = new Application();
        return $appModel->searchByAfm($afm);
    }
    
    /**
     * Normalize customer data
     */
    private function normalizeCustomer(array $data): array {
        $encryptedFields = [
            'first_name' => $data['firstname'] ?? null,
            'last_name' => $data['lastname'] ?? null,
            'father_name' => $data['fathername'] ?? null,
            'afm' => $data['afm'] ?? null,
            'adt' => $data['adt'] ?? null,
            'dou' => $data['dou'] ?? null,
            'date_of_birth' => $data['dateofbirth'] ?? null,
            'company' => $data['company'] ?? null,
            'company_afm' => $data['companyafm'] ?? null,
            'landline_phone' => $data['landline_phone'] ?? null,
            'mobile_phone' => $data['mobile_phone'] ?? null,
            'email' => $data['email'] ?? null,
            'install_address' => $data['install_address'] ?? null,
            'billing_address' => $data['billing_address'] ?? null,
        ];
        
        $result = [];
        
        foreach ($encryptedFields as $key => $value) {
            if (!empty($value)) {
                try {
                    $result[$key] = decrypt_data($value);
                } catch (Throwable $e) {
                    $result[$key] = null;
                }
            } else {
                $result[$key] = null;
            }
        }
        
        return $result;
    }
    
    /**
     * Check if AFM exists
     */
    public function afmExists(string $afm): bool {
        return $this->getByAfm($afm) !== null;
    }
    
    /**
     * Get unique customers count
     */
    public function getUniqueCount(): int {
        $sql = "SELECT COUNT(DISTINCT afm) as count FROM customers WHERE afm IS NOT NULL";
        return (int)Database::fetchColumn($sql);
    }
}