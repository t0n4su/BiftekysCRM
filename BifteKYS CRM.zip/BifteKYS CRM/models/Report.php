<?php
/**
 * Report Model
 * Handles aggregate queries for reports
 */

require_once __DIR__ . '/../core/Database.php';

class Report {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get application count by date range
     * @param string $dateFrom
     * @param string $dateTo
     * @param array $userIds
     * @return int
     */
    public function getCountByDateRange(string $dateFrom, string $dateTo, array $userIds = []): int {
        $where = 'DATE(createdat) BETWEEN ? AND ?';
        $params = [$dateFrom, $dateTo];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        return (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where}",
            $params
        );
    }
    
    /**
     * Get applications by status
     * @param string $dateFrom
     * @param string $dateTo
     * @param array $userIds
     * @return array
     */
    public function getByStatus(string $dateFrom, string $dateTo, array $userIds = []): array {
        $where = 'DATE(createdat) BETWEEN ? AND ?';
        $params = [$dateFrom, $dateTo];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        $sql = "
            SELECT status, COUNT(*) as count
            FROM customers
            WHERE {$where}
            GROUP BY status
        ";
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get applications by owner
     * @param string $dateFrom
     * @param string $dateTo
     * @param int $limit
     * @param array $userIds
     * @return array
     */
    public function getByOwner(string $dateFrom, string $dateTo, int $limit = 10, array $userIds = []): array {
        $where = 'DATE(c.createdat) BETWEEN ? AND ?';
        $params = [$dateFrom, $dateTo];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND c.userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        $sql = "
            SELECT 
                c.userid,
                COALESCE(NULLIF(u.displayname, ''), u.code, u.username) as owner_name,
                COUNT(*) as count
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE {$where}
            GROUP BY c.userid
            ORDER BY count DESC
            LIMIT ?
        ";
        $params[] = $limit;
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get daily trend
     * @param int $days
     * @param array $userIds
     * @return array
     */
    public function getDailyTrend(int $days = 30, array $userIds = []): array {
        $where = 'createdat >= DATE_SUB(NOW(), INTERVAL ? DAY)';
        $params = [$days];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        $sql = "
            SELECT 
                DATE(createdat) as date,
                COUNT(*) as count
            FROM customers
            WHERE {$where}
            GROUP BY DATE(createdat)
            ORDER BY date ASC
        ";
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get monthly trend
     * @param int $months
     * @param array $userIds
     * @return array
     */
    public function getMonthlyTrend(int $months = 12, array $userIds = []): array {
        $where = 'createdat >= DATE_SUB(NOW(), INTERVAL ? MONTH)';
        $params = [$months];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        $sql = "
            SELECT 
                DATE_FORMAT(createdat, '%Y-%m') as month,
                COUNT(*) as count
            FROM customers
            WHERE {$where}
            GROUP BY DATE_FORMAT(createdat, '%Y-%m')
            ORDER BY month ASC
        ";
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get average activation time
     * @param string $dateFrom
     * @param string $dateTo
     * @param array $userIds
     * @return float|null
     */
    public function getAverageActivationTime(string $dateFrom, string $dateTo, array $userIds = []): ?float {
        $where = "DATE(createdat) BETWEEN ? AND ? AND activatedat IS NOT NULL";
        $params = [$dateFrom, $dateTo];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = array_merge($params, $userIds);
        }
        
        $sql = "
            SELECT AVG(TIMESTAMPDIFF(HOUR, createdat, activatedat)) as avg_hours
            FROM customers
            WHERE {$where}
        ";
        
        $result = Database::fetchColumn($sql, $params);
        return $result !== null ? (float)$result : null;
    }
    
    /**
     * Get this month vs last month comparison
     * @param array $userIds
     * @return array
     */
    public function getMonthComparison(array $userIds = []): array {
        $where = '';
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = " AND userid IN ($placeholders)";
            $params = $userIds;
        }
        
        // This month
        $thisMonthSql = "
            SELECT COUNT(*) FROM customers
            WHERE YEAR(createdat) = YEAR(NOW()) AND MONTH(createdat) = MONTH(NOW())
            {$where}
        ";
        $thisMonth = (int)Database::fetchColumn($thisMonthSql, $params);
        
        // Last month
        $lastMonthSql = "
            SELECT COUNT(*) FROM customers
            WHERE YEAR(createdat) = YEAR(NOW() - INTERVAL 1 MONTH)
            AND MONTH(createdat) = MONTH(NOW() - INTERVAL 1 MONTH)
            {$where}
        ";
        $lastMonth = (int)Database::fetchColumn($lastMonthSql, $params);
        
        return [
            'this_month' => $thisMonth,
            'last_month' => $lastMonth,
            'change' => $lastMonth > 0 ? round((($thisMonth - $lastMonth) / $lastMonth) * 100, 2) : 0,
        ];
    }
    
    /**
     * Get summary statistics
     * @param array $userIds
     * @return array
     */
    public function getSummary(array $userIds = []): array {
        $where = '1=1';
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "userid IN ($placeholders)";
            $params = $userIds;
        }
        
        // Total
        $total = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where}",
            $params
        );
        
        // Today
        $today = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where} AND DATE(createdat) = CURDATE()",
            $params
        );
        
        // This week
        $thisWeek = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where} AND YEARWEEK(createdat) = YEARWEEK(NOW())",
            $params
        );
        
        // Active count
        $activeWhere = $where . " AND status = 'ΕΝΕΡΓΟ'";
        $active = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$activeWhere}",
            $params
        );
        
        return [
            'total' => $total,
            'today' => $today,
            'this_week' => $thisWeek,
            'active' => $active,
        ];
    }
}
