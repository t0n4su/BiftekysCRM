<?php
/**
 * User Model
 * Handles all user-related database operations
 */

require_once __DIR__ . '/../core/Database.php';

class User {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get user by ID
     * @param int $id
     * @return array|null
     */
    public function getById(int $id): ?array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            WHERE id = ? 
            LIMIT 1
        ";
        $user = Database::fetchOne($sql, [$id]);
        
        if ($user) {
            return $this->normalizeUser($user);
        }
        return null;
    }
    
    /**
     * Get user by username
     * @param string $username
     * @return array|null
     */
    public function getByUsername(string $username): ?array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            WHERE username = ? 
            LIMIT 1
        ";
        $user = Database::fetchOne($sql, [$username]);
        
        if ($user) {
            return $this->normalizeUser($user);
        }
        return null;
    }
    
    /**
     * Get user by code
     * @param string $code
     * @return array|null
     */
    public function getByCode(string $code): ?array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            WHERE code = ? 
            LIMIT 1
        ";
        $user = Database::fetchOne($sql, [$code]);
        
        if ($user) {
            return $this->normalizeUser($user);
        }
        return null;
    }
    
    /**
     * Get all users
     * @param int $limit
     * @return array
     */
    public function getAll(int $limit = 5000): array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            ORDER BY id DESC 
            LIMIT ?
        ";
        $users = Database::fetchAll($sql, [$limit]);
        
        return array_map([$this, 'normalizeUser'], $users);
    }
    
    /**
     * Get users by parent ID (children)
     * @param int $parentId
     * @return array
     */
    public function getByParentId(int $parentId): array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            WHERE parentuserid = ?
            ORDER BY code ASC
        ";
        $users = Database::fetchAll($sql, [$parentId]);
        
        return array_map([$this, 'normalizeUser'], $users);
    }
    
    /**
     * Get downline IDs (self + all descendants)
     * @param int $rootId
     * @return array
     */
    public function getDownlineIds(int $rootId): array {
        $seen = [$rootId => true];
        $frontier = [$rootId];
        
        while (!empty($frontier)) {
            $in = implode(',', array_map('intval', $frontier));
            $frontier = [];
            
            $sql = "SELECT id FROM users WHERE parentuserid IN ($in)";
            $result = $this->db->query($sql);
            
            while ($row = $result->fetch()) {
                $id = (int)$row['id'];
                if (!isset($seen[$id])) {
                    $seen[$id] = true;
                    $frontier[] = $id;
                }
            }
        }
        
        return array_map('intval', array_keys($seen));
    }
    
    /**
     * Get users in downline
     * @param int $rootId
     * @return array
     */
    public function getDownline(int $rootId): array {
        $ids = $this->getDownlineIds($rootId);
        
        if (empty($ids)) return [];
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, createdat
            FROM users 
            WHERE id IN ($placeholders)
            ORDER BY id DESC
        ";
        $users = Database::fetchAll($sql, $ids);
        
        return array_map([$this, 'normalizeUser'], $users);
    }
    
    /**
     * Create new user
     * @param array $data
     * @return int
     */
    public function create(array $data): int {
        $insertData = [
            'code' => $data['code'],
            'role' => $data['role'] ?? 'partner',
            'displayname' => $data['displayname'] ?? null,
            'isactive' => $data['isactive'] ?? 1,
            'parentuserid' => $data['parentuserid'] ?? null,
        ];
        
        if (!empty($data['username'])) {
            $insertData['username'] = $data['username'];
        }
        
        if (!empty($data['password'])) {
            $insertData['password_hash'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }
        
        return Database::insert('users', $insertData);
    }
    
    /**
     * Update user
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update(int $id, array $data): bool {
        $allowedFields = ['username', 'code', 'role', 'displayname', 'isactive', 'parentuserid', 'password_hash'];
        $updateData = [];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $updateData[$key] = $value;
            }
        }
        
        if (empty($updateData)) return false;
        
        $rows = Database::update('users', $updateData, 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Set user active status
     * @param int $id
     * @param bool $active
     * @return bool
     */
    public function setActive(int $id, bool $active): bool {
        $rows = Database::update('users', ['isactive' => $active ? 1 : 0], 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Check if username exists
     * @param string $username
     * @param int|null $excludeId
     * @return bool
     */
    public function usernameExists(string $username, ?int $excludeId = null): bool {
        $sql = "SELECT id FROM users WHERE username = ?";
        $params = [$username];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $sql .= " LIMIT 1";
        return Database::fetchOne($sql, $params) !== null;
    }
    
    /**
     * Check if code exists
     * @param string $code
     * @param int|null $excludeId
     * @return bool
     */
    public function codeExists(string $code, ?int $excludeId = null): bool {
        $sql = "SELECT id FROM users WHERE code = ?";
        $params = [$code];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $sql .= " LIMIT 1";
        return Database::fetchOne($sql, $params) !== null;
    }
    
    /**
     * Build user tree
     * @return array
     */
    public function buildTree(): array {
        $users = $this->getAll();
        return $this->buildTreeFromUsers($users);
    }
    /**
     * Build tree starting from a specific user
     */
    public function buildTreeForUser(int $rootId): array {
        $users = $this->getDownline($rootId);
        
        // Include the root user themselves
        $rootUser = $this->getById($rootId);
        if ($rootUser) {
            $users[] = $rootUser;
        }
        
        return $this->buildTreeFromUsers($users);
    }
    /**
     * Build tree from user list
     * @param array $users
     * @return array
     */
    private function buildTreeFromUsers(array $users): array {
        $byId = [];
        foreach ($users as $user) {
            $byId[$user['id']] = array_merge($user, ['children' => []]);
        }
        
        $roots = [];
        foreach ($byId as $id => $user) {
            if ($user['parent_user_id'] && isset($byId[$user['parent_user_id']])) {
                $byId[$user['parent_user_id']]['children'][] = &$byId[$id];
            } else {
                $roots[] = &$byId[$id];
            }
        }
        
        // Sort by code
        usort($roots, fn($a, $b) => strcasecmp($a['code'], $b['code']));
        foreach ($byId as &$user) {
            usort($user['children'], fn($a, $b) => strcasecmp($a['code'], $b['code']));
        }
        
        return $roots;
    }
    
    /**
     * Normalize user data
     * @param array $user
     * @return array
     */
    private function normalizeUser(array $user): array {
        return [
            'id' => (int)$user['id'],
            'username' => $user['username'] ?? null,
            'code' => $user['code'],
            'role' => $user['role'],
            'display_name' => $user['displayname'] ?: ($user['username'] ?: $user['code']),
            'is_active' => (bool)$user['isactive'],
            'parent_user_id' => $user['parentuserid'] ? (int)$user['parentuserid'] : null,
            'created_at' => $user['createdat'],
        ];
    }
    
    /**
     * Set API token
     * @param int $userId
     * @param string|null $token
     * @param string|null $expiresAt
     * @return bool
     */
    public function setApiToken(int $userId, ?string $token, ?string $expiresAt = null): bool {
        $rows = Database::update('users', [
            'apitoken' => $token,
            'tokenexpiresat' => $expiresAt
        ], 'id = ?', [$userId]);
        
        return $rows > 0;
    }
    
    /**
     * Get user by API token
     * @param string $token
     * @return array|null
     */
    public function getByApiToken(string $token): ?array {
        $sql = "
            SELECT 
                id, username, code, role, displayname, 
                isactive, parentuserid, tokenexpiresat
            FROM users 
            WHERE apitoken = ? 
            LIMIT 1
        ";
        $user = Database::fetchOne($sql, [$token]);
        
        if (!$user) return null;
        
        // Check token expiration
        if ($user['tokenexpiresat']) {
            $exp = strtotime($user['tokenexpiresat']);
            if ($exp !== false && $exp < time()) {
                return null;
            }
        }
        
        return $this->normalizeUser($user);
    }
    
/**
     * Verify password
     * @param int $userId
     * @param string $password
     * @return bool
     */
/**
     * Έξυπνος έλεγχος Κωδικού (Υποστηρίζει τη μετάβαση από 'code' σε 'password')
     */
/**
     * Επαληθεύει τον κωδικό (όταν ζητηθεί εκτός login)
     */
    public function verifyPassword(int $userId, string $password): bool {
        $sql = "SELECT password_hash FROM users WHERE id = ? LIMIT 1";
        $user = Database::fetchOne($sql, [$userId]);
        
        if (!$user || empty($user['password_hash'])) {
            return false;
        }
        return password_verify($password, $user['password_hash']);
    }

    /**
     * Αλλαγή/Ενημέρωση κωδικού πρόσβασης χρήστη (Προφίλ)
     */
    public function setPassword(int $userId, string $newPassword): bool {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        // Αποθηκεύει τον νέο κωδικό στη σωστή στήλη (password_hash)
        $rows = Database::update('users', ['password_hash' => $hashedPassword], 'id = ?', [$userId]);
        return $rows > 0;
    }
} // <--- ΤΕΛΟΣ ΑΡΧΕΙΟΥ-- Τέλος αρχείου
    

