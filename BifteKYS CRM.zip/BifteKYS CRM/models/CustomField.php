<?php
/**
 * Custom Field Model
 * Handles custom fields metadata operations
 */

require_once __DIR__ . '/../core/Database.php';

class CustomField {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get all active fields
     * @return array
     */
    public function getActive(): array {
        try {
            $fields = Database::fetchAll(
                "SELECT * FROM custom_fields WHERE is_active = 1 ORDER BY display_order, id"
            );
            
            return array_map(function($field) {
                return $this->normalizeField($field);
            }, $fields);
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * Get all fields
     * @return array
     */
    public function getAll(): array {
        try {
            $fields = Database::fetchAll(
                "SELECT * FROM custom_fields ORDER BY display_order, id"
            );
            
            return array_map(function($field) {
                return $this->normalizeField($field);
            }, $fields);
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * Get field by ID
     * @param int $id
     * @return array|null
     */
    public function getById(int $id): ?array {
        $field = Database::fetchOne(
            "SELECT * FROM custom_fields WHERE id = ?",
            [$id]
        );
        
        if ($field) {
            return $this->normalizeField($field);
        }
        return null;
    }
    
    /**
     * Get field by name
     * @param string $name
     * @return array|null
     */
    public function getByName(string $name): ?array {
        $field = Database::fetchOne(
            "SELECT * FROM custom_fields WHERE field_name = ?",
            [$name]
        );
        
        if ($field) {
            return $this->normalizeField($field);
        }
        return null;
    }
    
    /**
     * Create field
     * @param array $data
     * @return int
     */
    public function create(array $data): int {
        return Database::insert('custom_fields', [
            'field_label' => $data['field_label'],
            'field_name' => $data['field_name'],
            'field_type' => $data['field_type'],
            'options_json' => !empty($data['options']) ? json_encode($data['options']) : null,
            'is_required' => $data['is_required'] ? 1 : 0,
            'display_order' => $data['display_order'] ?? 0,
            'is_active' => $data['is_active'] ?? 1,
        ]);
    }
    
    /**
     * Update field
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update(int $id, array $data): bool {
        $allowedFields = ['field_label', 'field_type', 'options_json', 'is_required', 'display_order', 'is_active'];
        $updateData = [];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                if ($key === 'options_json' && is_array($value)) {
                    $updateData[$key] = json_encode($value);
                } else {
                    $updateData[$key] = $value;
                }
            }
        }
        
        if (empty($updateData)) return false;
        
        $rows = Database::update('custom_fields', $updateData, 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Set active status
     * @param int $id
     * @param bool $active
     * @return bool
     */
    public function setActive(int $id, bool $active): bool {
        $rows = Database::update('custom_fields', ['is_active' => $active ? 1 : 0], 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Check if field name exists
     * @param string $name
     * @param int|null $excludeId
     * @return bool
     */
    public function nameExists(string $name, ?int $excludeId = null): bool {
        $sql = "SELECT id FROM custom_fields WHERE field_name = ?";
        $params = [$name];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $sql .= " LIMIT 1";
        return Database::fetchOne($sql, $params) !== null;
    }
    
    /**
     * Add column to applications table
     * @param string $columnName
     * @return bool
     */
    public function addColumn(string $columnName): bool {
        try {
            $quoted = Database::quoteIdentifier($columnName);
            $this->db->exec("ALTER TABLE applications ADD COLUMN {$quoted} TEXT NULL");
            return true;
        } catch (Throwable $e) {
            error_log('Failed to add column: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Normalize field data
     * @param array $field
     * @return array
     */
    private function normalizeField(array $field): array {
        return [
            'id' => (int)$field['id'],
            'field_label' => $field['field_label'],
            'field_name' => $field['field_name'],
            'field_type' => $field['field_type'],
            'options' => !empty($field['options_json']) ? json_decode($field['options_json'], true) : [],
            'is_required' => (bool)$field['is_required'],
            'display_order' => (int)$field['display_order'],
            'is_active' => (bool)$field['is_active'],
            'created_at' => $field['created_at'] ?? null,
        ];
    }
    
    /**
     * Render HTML input for field
     * @param array $field
     * @param mixed $value
     * @return string
     */
    public function renderInput(array $field, $value = null): string {
        $name = htmlspecialchars($field['field_name']);
        $label = htmlspecialchars($field['field_label']);
        $required = $field['is_required'] ? ' required' : '';
        $value = htmlspecialchars($value ?? '');
        
        switch ($field['field_type']) {
            case 'textarea':
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <textarea name="{$name}" id="{$name}" class="form-control"{$required}>{$value}</textarea>
                    </div>
                HTML;
                
            case 'dropdown':
                $options = '';
                foreach ($field['options'] as $opt) {
                    $selected = ($value === $opt) ? ' selected' : '';
                    $options .= '<option value="' . htmlspecialchars($opt) . '"' . $selected . '>' . htmlspecialchars($opt) . '</option>';
                }
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <select name="{$name}" id="{$name}" class="form-control"{$required}>
                            <option value="">-- Επιλέξτε --</option>
                            {$options}
                        </select>
                    </div>
                HTML;
                
            case 'checkbox':
                $checked = $value ? ' checked' : '';
                return <<<HTML
                    <div class="form-group form-check">
                        <input type="checkbox" name="{$name}" id="{$name}" value="1" class="form-check-input"{$checked}{$required}>
                        <label for="{$name}" class="form-check-label">{$label}</label>
                    </div>
                HTML;
                
            case 'radio':
                $html = '<div class="form-group"><label>' . $label . '</label>';
                foreach ($field['options'] as $opt) {
                    $checked = ($value === $opt) ? ' checked' : '';
                    $html .= '<div class="form-check">
                        <input type="radio" name="' . $name . '" value="' . htmlspecialchars($opt) . '" class="form-check-input"' . $checked . $required . '>
                        <label class="form-check-label">' . htmlspecialchars($opt) . '</label>
                    </div>';
                }
                $html .= '</div>';
                return $html;
                
            case 'date':
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <input type="date" name="{$name}" id="{$name}" class="form-control" value="{$value}"{$required}>
                    </div>
                HTML;
                
            case 'number':
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <input type="number" name="{$name}" id="{$name}" class="form-control" value="{$value}"{$required}>
                    </div>
                HTML;
                
            case 'email':
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <input type="email" name="{$name}" id="{$name}" class="form-control" value="{$value}"{$required}>
                    </div>
                HTML;
                
            case 'file':
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <input type="file" name="{$name}" id="{$name}" class="form-control"{$required}>
                    </div>
                HTML;
                
            case 'text':
            default:
                return <<<HTML
                    <div class="form-group">
                        <label for="{$name}">{$label}</label>
                        <input type="text" name="{$name}" id="{$name}" class="form-control" value="{$value}"{$required}>
                    </div>
                HTML;
        }
    }
}
