<?php
/**
 * Application Model
 * Handles all application/customer-related database operations
 */

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../helpers/functions.php';

class Application {
    private PDO $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Get application by ID
     * @param int $id
     * @return array|null
     */
    public function getById(int $id): ?array {
        $sql = "
            SELECT 
                c.*,
                COALESCE(NULLIF(u.displayname, ''), u.code) AS partner_name
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE c.id = ?
            LIMIT 1
        ";
        $app = Database::fetchOne($sql, [$id]);
        
        if ($app) {
            return $this->normalizeApplication($app, true);
        }
        return null;
    }
    
    /**
     * Get all applications
     * @param array $filters
     * @param int $limit
     * @return array
     */
    public function getAll(array $filters = [], int $limit = 5000): array {
        $where = ['1=1'];
        $params = [];
        
        // User filter
        if (!empty($filters['user_ids'])) {
            $placeholders = implode(',', array_fill(0, count($filters['user_ids']), '?'));
            $where[] = "c.userid IN ($placeholders)";
            $params = array_merge($params, $filters['user_ids']);
        }
        
        // Status filter
        if (!empty($filters['status'])) {
            $where[] = "c.status = ?";
            $params[] = $filters['status'];
        }
        
        // Date range filter
        if (!empty($filters['date_from'])) {
            $where[] = "DATE(c.createdat) >= ?";
            $params[] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where[] = "DATE(c.createdat) <= ?";
            $params[] = $filters['date_to'];
        }
        
        // Search filter
        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $where[] = "(
                c.firstname LIKE ? OR 
                c.lastname LIKE ? OR 
                c.afm LIKE ? OR 
                c.mobile_phone LIKE ? OR
                c.landline_phone LIKE ?
            )";
            $params = array_merge($params, [$search, $search, $search, $search, $search]);
        }
        
        $whereClause = implode(' AND ', $where);
        
        $sql = "
            SELECT 
                c.*,
                COALESCE(NULLIF(u.displayname, ''), u.code) AS partner_name
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE {$whereClause}
            ORDER BY c.id DESC
            LIMIT ?
        ";
        $params[] = $limit;
        
        $apps = Database::fetchAll($sql, $params);
        
        return array_map(fn($app) => $this->normalizeApplication($app, true), $apps);
    }
    
    /**
     * Get applications by user ID
     * @param int $userId
     * @return array
     */
    public function getByUserId(int $userId): array {
        $sql = "
            SELECT 
                c.*,
                COALESCE(NULLIF(u.displayname, ''), u.code) AS partner_name
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE c.userid = ?
            ORDER BY c.id DESC
        ";
        $apps = Database::fetchAll($sql, [$userId]);
        
        return array_map(fn($app) => $this->normalizeApplication($app, true), $apps);
    }
    
    /**
     * Create new application
     * @param array $data
     * @return int
     */
    public function create(array $data): int {
        $insertData = [
            'userid' => $data['user_id'],
            'partnercode' => $data['partner_code'],
            'status' => $data['status'] ?? 'ΝΕΟ',
            'createdat' => date('Y-m-d H:i:s'),
            'updatedat' => date('Y-m-d H:i:s'),
        ];
        
        // Encrypt sensitive fields
        $encryptedFields = [
            'firstname' => $data['first_name'] ?? null,
            'lastname' => $data['last_name'] ?? null,
            'fathername' => $data['father_name'] ?? null,
            'afm' => $data['afm'] ?? null,
            'adt' => $data['adt'] ?? null,
            'dou' => $data['dou'] ?? null,
            'dateofbirth' => $data['date_of_birth'] ?? null,
            'company' => $data['company'] ?? null,
            'companyafm' => $data['company_afm'] ?? null,
            'landline_phone' => $data['landline_phone'] ?? null,
            'mobile_phone' => $data['mobile_phone'] ?? null,
            'application_number' => $data['application_number'] ?? null,
            'price' => $data['price'] ?? null,
            'install_address' => $data['install_address'] ?? null,
            'billing_address' => $data['billing_address'] ?? null,
            'email' => $data['email'] ?? null,
        ];
        
        foreach ($encryptedFields as $key => $value) {
            if ($value !== null && $value !== '') {
                $insertData[$key] = encrypt_data($value);
            } else {
                $insertData[$key] = null;
            }
        }
        
        // Non-encrypted fields
        $plainFields = [
            'request_type' => $data['request_type'] ?? null,
            'landline_program' => $data['landline_program'] ?? null,
            'mobile_program' => $data['mobile_program'] ?? null,
            'contactdate' => $data['contact_date'] ?? date('Y-m-d'),
            'notes' => $data['notes'] ?? null,
        ];
        
        foreach ($plainFields as $key => $value) {
            $insertData[$key] = $value;
        }
        
        return Database::insert('customers', $insertData);
    }
    
    /**
     * Update application
     * @param int $id
     * @param array $data
     * @return bool
     */
    // --- ΠΡΟΣΘΗΚΗ ΣΤΟ Application.php ---

    public function addFile(int $appId, string $originalName, string $storedName, string $mimeType, int $fileSize): void {
        Database::query(
            "INSERT INTO application_files (application_id, original_name, stored_name, mime_type, file_size) VALUES (?, ?, ?, ?, ?)",
            [$appId, $originalName, $storedName, $mimeType, $fileSize]
        );
    }

    public function getFile(int $fileId): ?array {
        return Database::fetchOne("SELECT * FROM application_files WHERE id = ?", [$fileId]);
    }

    public function getApplicationFiles(int $appId): array {
        return Database::fetchAll("SELECT * FROM application_files WHERE application_id = ?", [$appId]);
    }

    public function deleteFile(int $fileId): void {
        Database::query("DELETE FROM application_files WHERE id = ?", [$fileId]);
    }
    public function update(int $id, array $data): bool {
        $updateData = [];
        
        // Map field names
        $fieldMap = [
            'first_name' => 'firstname',
            'last_name' => 'lastname',
            'father_name' => 'fathername',
            'date_of_birth' => 'dateofbirth',
            'company_afm' => 'companyafm',
            'request_type' => 'request_type',
            'landline_phone' => 'landline_phone',
            'mobile_phone' => 'mobile_phone',
            'application_number' => 'application_number',
            'install_address' => 'install_address',
            'billing_address' => 'billing_address',
            'landline_program' => 'landline_program',
            'mobile_program' => 'mobile_program',
            'contact_date' => 'contactdate',
            'status' => 'status',
            'notes' => 'notes',
        ];
        
        // Fields that need encryption
        $encryptedDbFields = ['firstname', 'lastname', 'fathername', 'afm', 'adt', 'dou', 
                              'dateofbirth', 'company', 'companyafm', 'landline_phone', 
                              'mobile_phone', 'application_number', 'price', 
                              'install_address', 'billing_address', 'email'];
        
        foreach ($data as $key => $value) {
            if (isset($fieldMap[$key])) {
                $dbField = $fieldMap[$key];
                if (in_array($dbField, $encryptedDbFields) && $value !== null && $value !== '') {
                    $updateData[$dbField] = encrypt_data($value);
                } else {
                    $updateData[$dbField] = $value;
                }
            }
        }
        
        // Always update updatedat
        $updateData['updatedat'] = date('Y-m-d H:i:s');
        
        if (empty($updateData)) return false;
        
        $rows = Database::update('customers', $updateData, 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Update status
     * @param int $id
     * @param string $status
     * @return bool
     */
    public function updateStatus(int $id, string $status): bool {
        $data = [
            'status' => $status,
            'status_updated_at' => date('Y-m-d H:i:s'),
            'updatedat' => date('Y-m-d H:i:s')
        ];
        
        if ($status === 'ΕΝΕΡΓΟ') {
            $data['activatedat'] = date('Y-m-d H:i:s');
        }
        
        $rows = Database::update('customers', $data, 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Update notes
     * @param int $id
     * @param string|null $notes
     * @return bool
     */
    public function updateNotes(int $id, ?string $notes): bool {
        $rows = Database::update('customers', [
            'notes' => $notes,
            'updatedat' => date('Y-m-d H:i:s')
        ], 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Delete application
     * @param int $id
     * @return bool
     */
    public function delete(int $id): bool {
        $rows = Database::delete('customers', 'id = ?', [$id]);
        return $rows > 0;
    }
    
    /**
     * Get statistics
     * @param array $userIds
     * @return array
     */
    public function getStats(array $userIds = []): array {
        $where = '1=1';
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "userid IN ($placeholders)";
            $params = $userIds;
        }
        
        // Total count
        $total = (int)Database::fetchColumn("SELECT COUNT(*) FROM customers WHERE {$where}", $params);
        
        // Today's count
        $today = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where} AND DATE(createdat) = CURDATE()",
            $params
        );
        
        // Week count
        $week = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM customers WHERE {$where} AND createdat >= (NOW() - INTERVAL 7 DAY)",
            $params
        );
        
        // Status counts
        $statusCounts = Database::fetchAll(
            "SELECT status, COUNT(*) as count FROM customers WHERE {$where} GROUP BY status",
            $params
        );
        
        return [
            'total' => $total,
            'today' => $today,
            'week' => $week,
            'by_status' => array_column($statusCounts, 'count', 'status'),
        ];
    }
    
    /**
     * Get monthly statistics
     * @param int $months
     * @param array $userIds
     * @return array
     */
    public function getMonthlyStats(int $months = 12, array $userIds = []): array {
        $where = '1=1';
        $params = [$months];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "userid IN ($placeholders)";
            $params = array_merge($userIds, $params);
        }
        
        $sql = "
            SELECT 
                DATE_FORMAT(createdat, '%Y-%m') as month,
                COUNT(*) as count
            FROM customers
            WHERE {$where} AND createdat >= DATE_SUB(NOW(), INTERVAL ? MONTH)
            GROUP BY DATE_FORMAT(createdat, '%Y-%m')
            ORDER BY month ASC
        ";
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get daily statistics for last N days
     * @param int $days
     * @param array $userIds
     * @return array
     */
    public function getDailyStats(int $days = 30, array $userIds = []): array {
        $where = '1=1';
        $params = [$days];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "userid IN ($placeholders)";
            $params = array_merge($userIds, $params);
        }
        
        $sql = "
            SELECT 
                DATE(createdat) as date,
                COUNT(*) as count
            FROM customers
            WHERE {$where} AND createdat >= DATE_SUB(NOW(), INTERVAL ? DAY)
            GROUP BY DATE(createdat)
            ORDER BY date ASC
        ";
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Get partner statistics
     * @param int $limit
     * @param array $userIds
     * @return array
     */
    public function getPartnerStats(int $limit = 10, array $userIds = []): array {
        $where = '1=1';
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "c.userid IN ($placeholders)";
            $params = $userIds;
        }
        
        $sql = "
            SELECT 
                c.userid,
                COALESCE(NULLIF(u.displayname, ''), u.code, u.username) as partner_name,
                COUNT(*) as count
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE {$where}
            GROUP BY c.userid
            ORDER BY count DESC
            LIMIT ?
        ";
        $params[] = $limit;
        
        return Database::fetchAll($sql, $params);
    }
    
    /**
     * Search by AFM
     * @param string $afm
     * @return array
     */
    public function searchByAfm(string $afm): array {
        // AFM is encrypted, so we need to search differently
        // For now, return all and filter (not efficient but works for small datasets)
        $sql = "
            SELECT 
                c.*,
                COALESCE(NULLIF(u.displayname, ''), u.code) AS partner_name
            FROM customers c
            LEFT JOIN users u ON u.id = c.userid
            WHERE c.afm IS NOT NULL
            ORDER BY c.id DESC
            LIMIT 1000
        ";
        $apps = Database::fetchAll($sql);
        
        $results = [];
        foreach ($apps as $app) {
            $decryptedAfm = null;
            if (!empty($app['afm'])) {
                try {
                    $decryptedAfm = decrypt_data($app['afm']);
                } catch (Throwable $e) {}
            }
            
            if ($decryptedAfm === $afm) {
                $results[] = $this->normalizeApplication($app, true);
            }
        }
        
        return $results;
    }
    
    /**
     * Get month comparison (this month vs last month)
     * @param array $userIds
     * @return array
     */
    public function getMonthComparison(array $userIds = []): array {
        $where = '1=1';
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where = "userid IN ($placeholders)";
            $params = $userIds;
        }
        
        // This month
        $thisMonthSql = "
            SELECT COUNT(*) FROM customers
            WHERE {$where} AND YEAR(createdat) = YEAR(NOW()) AND MONTH(createdat) = MONTH(NOW())
        ";
        $thisMonth = (int)Database::fetchColumn($thisMonthSql, $params);
        
        // Last month
        $lastMonthSql = "
            SELECT COUNT(*) FROM customers
            WHERE {$where} AND YEAR(createdat) = YEAR(NOW() - INTERVAL 1 MONTH)
            AND MONTH(createdat) = MONTH(NOW() - INTERVAL 1 MONTH)
        ";
        $lastMonth = (int)Database::fetchColumn($lastMonthSql, $params);
        
        // Calculate change percentage
        $change = 0;
        if ($lastMonth > 0) {
            $change = round((($thisMonth - $lastMonth) / $lastMonth) * 100, 2);
        }
        
        return [
            'this_month' => $thisMonth,
            'last_month' => $lastMonth,
            'change' => $change,
        ];
    }
    
    /**
     * Get average activation time in hours
     * @param array $userIds
     * @return float|null
     */
    public function getAverageActivationTime(array $userIds = []): ?float {
        $where = "activatedat IS NOT NULL";
        $params = [];
        
        if (!empty($userIds)) {
            $placeholders = implode(',', array_fill(0, count($userIds), '?'));
            $where .= " AND userid IN ($placeholders)";
            $params = $userIds;
        }
        
        $sql = "
            SELECT AVG(TIMESTAMPDIFF(HOUR, createdat, activatedat)) as avg_hours
            FROM customers
            WHERE {$where}
        ";
        
        $result = Database::fetchColumn($sql, $params);
        return $result !== null ? (float)$result : null;
    }
    
    /**
     * Normalize application data
     * @param array $app
     * @param bool $decrypt
     * @return array
     */
    private function normalizeApplication(array $app, bool $decrypt = true): array {
        $result = [
            'id' => (int)$app['id'],
            'user_id' => (int)$app['userid'],
            'partner_code' => $app['partnercode'],
            'partner_name' => $app['partner_name'] ?? $app['partnercode'],
            'request_type' => $app['request_type'],
            'landline_program' => $app['landline_program'],
            'mobile_program' => $app['mobile_program'],
            'status' => $app['status'],
            'notes' => $app['notes'],
            'contact_date' => $app['contactdate'],
            'created_at' => $app['createdat'],
            'updated_at' => $app['updatedat'],
            'activated_at' => $app['activatedat'],
        ];
        
        if ($decrypt) {
            $encryptedFields = [
                'first_name' => $app['firstname'] ?? null,
                'last_name' => $app['lastname'] ?? null,
                'father_name' => $app['fathername'] ?? null,
                'afm' => $app['afm'] ?? null,
                'adt' => $app['adt'] ?? null,
                'dou' => $app['dou'] ?? null,
                'date_of_birth' => $app['dateofbirth'] ?? null,
                'company' => $app['company'] ?? null,
                'company_afm' => $app['companyafm'] ?? null,
                'landline_phone' => $app['landline_phone'] ?? null,
                'mobile_phone' => $app['mobile_phone'] ?? null,
                'application_number' => $app['application_number'] ?? null,
                'price' => $app['price'] ?? null,
                'install_address' => $app['install_address'] ?? null,
                'billing_address' => $app['billing_address'] ?? null,
                'email' => $app['email'] ?? null,
            ];
            
            foreach ($encryptedFields as $key => $value) {
                if (!empty($value)) {
                    try {
                        $result[$key] = decrypt_data($value);
                    } catch (Throwable $e) {
                        $result[$key] = null;
                    }
                } else {
                    $result[$key] = null;
                }
            }
        } else {
            $result['first_name'] = $app['firstname'] ?? null;
            $result['last_name'] = $app['lastname'] ?? null;
            $result['father_name'] = $app['fathername'] ?? null;
            $result['afm'] = $app['afm'] ?? null;
            $result['adt'] = $app['adt'] ?? null;
            $result['dou'] = $app['dou'] ?? null;
            $result['date_of_birth'] = $app['dateofbirth'] ?? null;
            $result['company'] = $app['company'] ?? null;
            $result['company_afm'] = $app['companyafm'] ?? null;
            $result['landline_phone'] = $app['landline_phone'] ?? null;
            $result['mobile_phone'] = $app['mobile_phone'] ?? null;
            $result['application_number'] = $app['application_number'] ?? null;
            $result['price'] = $app['price'] ?? null;
            $result['install_address'] = $app['install_address'] ?? null;
            $result['billing_address'] = $app['billing_address'] ?? null;
            $result['email'] = $app['email'] ?? null;
        }
        
        return $result;
    }
}
