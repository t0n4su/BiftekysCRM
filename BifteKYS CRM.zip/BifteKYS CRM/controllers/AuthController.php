<?php
/**
 * Auth Controller
 * Handles login, logout, and username setup
 */

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../helpers/validation.php';

class AuthController {
    private Auth $auth;
    
    public function __construct() {
        $this->auth = new Auth();
    }
    
    /**
     * Show login form
     */
    public function login(): void {
        // Check if already logged in
        if ($this->auth->isLoggedIn()) {
            // Check if needs username setup
            if ($this->auth->needsUsernameSetup()) {
                redirect('?page=set-username');
            }
            redirect('?page=dashboard');
        }
        
        $error = null;
        
        // Handle POST request
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            // Check CSRF
            if (!checkCsrf()) {
                $error = 'Μη έγκυρο αίτημα. Παρακαλώ δοκιμάστε ξανά.';
            } elseif (empty($username) || empty($password)) {
                $error = 'Συμπληρώστε username και κωδικό πρόσβασης.';
            } else {
                $user = $this->auth->authenticate($username, $password);
                
                if ($user) {
                    $this->auth->login($user);
                    
                    // Check if needs username setup
                    if ($this->auth->needsUsernameSetup()) {
                        redirect('?page=set-username');
                    }
                    
                    redirect('?page=dashboard');
                } else {
                    $error = 'Λάθος username ή κωδικός πρόσβασης.';
                }
            }
        }
        
        // Show login view
        include __DIR__ . '/../views/auth/login.php';
    }
    
    /**
     * Handle logout
     */
    public function logout(): void {
        $this->auth->logout();
        redirect('?page=login');
    }
    
    /**
     * Show username setup form
     */
    public function setUsername(): void {
        // Must be logged in
        if (!$this->auth->isLoggedIn()) {
            redirect('?page=login');
        }
        
        $user = $this->auth->getCurrentUser();
        $error = null;
        $success = null;
        
        // Handle POST request
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            
            // Check CSRF
            if (!checkCsrf()) {
                $error = 'Μη έγκυρο αίτημα. Παρακαλώ δοκιμάστε ξανά.';
            } else {
                $validation = validate_username($username);
                
                if (!$validation['valid']) {
                    $error = $validation['message'];
                } else {
                    $result = $this->auth->setUsername($user['id'], $username);
                    
                    if ($result['success']) {
                        $success = $result['message'];
                        // Redirect after short delay
                        header('Refresh: 1; URL=?page=dashboard');
                    } else {
                        $error = $result['message'];
                    }
                }
            }
        }
        
        // Show set username view
        include __DIR__ . '/../views/auth/set_username.php';
    }
    
    /**
     * API: Login
     */
    public function apiLogin(): void {
        header('Content-Type: application/json; charset=utf-8');
        
        $data = json_decode(file_get_contents('php://input'), true);
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            json_error('Συμπληρώστε username και κωδικό πρόσβασης.', 400);
        }
        
        $user = $this->auth->authenticate($username, $password);
        
        if (!$user) {
            json_error('Λάθος username ή κωδικός πρόσβασης.', 401);
        }
        
        $this->auth->login($user);
        
        json_success([
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role'],
                'display_name' => $user['display_name']
            ],
            'needs_username' => $this->auth->needsUsernameSetup()
        ]);
    }
    
    /**
     * API: Logout
     */
    public function apiLogout(): void {
        $this->auth->logout();
        json_success([], 'Αποσύνδεση επιτυχής');
    }
    
    /**
     * API: Set username
     */
    public function apiSetUsername(): void {
        if (!$this->auth->isLoggedIn()) {
            json_error('Unauthorized', 401);
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        $username = trim($data['username'] ?? '');
        
        $validation = validate_username($username);
        
        if (!$validation['valid']) {
            json_error($validation['message'], 400);
        }
        
        $user = $this->auth->getCurrentUser();
        $result = $this->auth->setUsername($user['id'], $username);
        
        if ($result['success']) {
            json_success([], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
}
