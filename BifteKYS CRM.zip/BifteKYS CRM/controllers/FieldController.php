<?php
/**
 * Field Controller
 * Handles custom fields management (superadmin only)
 */

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Database.php';

class FieldController {
    private Auth $auth;
    private PDO $db;
    
    public function __construct() {
        $this->auth = new Auth();
        $this->db = Database::getInstance();
    }
    
    /**
     * Show field manager
     */
    public function manager(): void {
        $this->requireSuperAdmin();
        
        $fields = $this->getFields();
        
        $error = null;
        $success = null;
        
        include __DIR__ . '/../views/fields/manager.php';
    }
    
    /**
     * API: Get fields
     */
    public function apiList(): void {
        $this->requireSuperAdmin();
        
        $fields = $this->getFields();
        
        json_success(['fields' => $fields]);
    }
    
    /**
     * API: Create field
     */
    public function apiCreate(): void {
        $this->requireSuperAdmin();
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $result = $this->createField($data);
        
        if ($result['success']) {
            json_success(['field_id' => $result['field_id']], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
    
    /**
     * API: Update field
     */
    public function apiUpdate(): void {
        $this->requireSuperAdmin();
        
        $data = json_decode(file_get_contents('php://input'), true);
        
        $result = $this->updateField($data);
        
        if ($result['success']) {
            json_success([], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
    
    /**
     * API: Toggle field active
     */
    public function apiToggle(): void {
        $this->requireSuperAdmin();
        
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? 0);
        $active = (bool)($data['active'] ?? false);
        $force = (bool)($data['force'] ?? false);
        
        if (!$id) {
            json_error('Invalid field ID', 400);
        }
        
        // Get field info
        $field = Database::fetchOne("SELECT * FROM custom_fields WHERE id = ?", [$id]);
        if (!$field) {
            json_error('Field not found', 404);
        }
        
        // If deactivating, check if field has data
        if (!$active && !$force) {
            $hasData = $this->fieldHasData($field['field_name']);
            if ($hasData) {
                json_error(
                    'Το πεδίο περιέχει δεδομένα σε υπάρχουσες αιτήσεις. Η απενεργοποίηση θα κρύψει το πεδίο αλλά τα δεδομένα θα διατηρηθούν. Θέλετε να συνεχίσετε;',
                    409,
                    ['has_data' => true, 'confirm_required' => true]
                );
            }
        }
        
        try {
            Database::update('custom_fields', ['is_active' => $active ? 1 : 0], 'id = ?', [$id]);
            json_success([], $active ? 'Το πεδίο ενεργοποιήθηκε' : 'Το πεδίο απενεργοποιήθηκε');
        } catch (Throwable $e) {
            json_error('Update failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Check if field has data in applications
     * @param string $fieldName
     * @return bool
     */
    private function fieldHasData(string $fieldName): bool {
        try {
            $quoted = Database::quoteIdentifier($fieldName);
            $result = Database::fetchColumn(
                "SELECT COUNT(*) FROM applications WHERE {$quoted} IS NOT NULL AND {$quoted} != '' LIMIT 1"
            );
            return (int)$result > 0;
        } catch (Throwable $e) {
            // If table doesn't exist or error, assume no data
            return false;
        }
    }
    
    /**
     * API: Delete field (soft delete - just deactivate)
     */
    public function apiDelete(): void {
        $this->requireSuperAdmin();
        
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? 0);
        
        if (!$id) {
            json_error('Invalid field ID', 400);
        }
        
        try {
            // Soft delete - just deactivate
            Database::update('custom_fields', ['is_active' => 0], 'id = ?', [$id]);
            json_success([], 'Το πεδίο απενεργοποιήθηκε');
        } catch (Throwable $e) {
            json_error('Delete failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * API: Save field (create or update)
     */
    public function apiSave(): void {
        $this->requireSuperAdmin();
        
        $data = json_decode(file_get_contents('php://input'), true);
        $id = (int)($data['id'] ?? 0);
        
        if ($id) {
            $result = $this->updateField($data);
        } else {
            $result = $this->createField($data);
        }
        
        if ($result['success']) {
            json_success(['field_id' => $result['field_id'] ?? $id], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
    
    /**
     * Get all fields
     * @return array
     */
    private function getFields(): array {
        try {
            return Database::fetchAll(
                "SELECT * FROM custom_fields ORDER BY display_order, id"
            );
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * Create field
     * @param array $data
     * @return array
     */
    private function createField(array $data): array {
        // Validate
        if (empty($data['field_label'])) {
            return ['success' => false, 'message' => 'Η ετικέτα πεδίου είναι υποχρεωτική'];
        }
        
        if (empty($data['field_name'])) {
            return ['success' => false, 'message' => 'Το όνομα πεδίου είναι υποχρεωτικό'];
        }
        
        // Validate field name
        if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $data['field_name'])) {
            return ['success' => false, 'message' => 'Μη έγκυρο όνομα πεδίου (μόνο γράμματα, αριθμοί, κάτω παύλες, ξεκινά με γράμμα)'];
        }
        
        // Check reserved words
        $reserved = ['id', 'select', 'insert', 'update', 'delete', 'from', 'where', 'order', 'group', 'having', 'limit'];
        if (in_array(strtolower($data['field_name']), $reserved, true)) {
            return ['success' => false, 'message' => 'Το όνομα πεδίου είναι δεσμευμένη λέξη'];
        }
        
        $validTypes = ['text', 'number', 'email', 'date', 'textarea', 'dropdown', 'checkbox', 'radio', 'file'];
        if (!in_array($data['field_type'], $validTypes, true)) {
            return ['success' => false, 'message' => 'Μη έγκυρος τύπος πεδίου'];
        }
        
        try {
            // Check if field already exists
            $existing = Database::fetchOne(
                "SELECT id FROM custom_fields WHERE field_name = ?",
                [$data['field_name']]
            );
            
            if ($existing) {
                return ['success' => false, 'message' => 'Υπάρχει ήδη πεδίο με αυτό το όνομα'];
            }
            
            // Add column to applications table
            $columnName = Database::quoteIdentifier($data['field_name']);
            $this->db->exec("ALTER TABLE applications ADD COLUMN {$columnName} TEXT NULL");
            
            // Insert metadata
            $fieldId = Database::insert('custom_fields', [
                'field_label' => $data['field_label'],
                'field_name' => $data['field_name'],
                'field_type' => $data['field_type'],
                'options_json' => !empty($data['options']) ? json_encode($data['options']) : null,
                'is_required' => !empty($data['is_required']) ? 1 : 0,
                'display_order' => (int)($data['display_order'] ?? 0),
                'is_active' => 1,
            ]);
            
            return ['success' => true, 'field_id' => $fieldId, 'message' => 'Το πεδίο δημιουργήθηκε επιτυχώς'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()];
        }
    }
    
    /**
     * Update field
     * @param array $data
     * @return array
     */
    private function updateField(array $data): array {
        $id = (int)($data['id'] ?? 0);
        
        if (!$id) {
            return ['success' => false, 'message' => 'Μη έγκυρο ID πεδίου'];
        }
        
        $field = Database::fetchOne("SELECT * FROM custom_fields WHERE id = ?", [$id]);
        if (!$field) {
            return ['success' => false, 'message' => 'Το πεδίο δεν βρέθηκε'];
        }
        
        try {
            $updateData = [
                'field_label' => $data['field_label'] ?? $field['field_label'],
                'field_type' => $data['field_type'] ?? $field['field_type'],
                'options_json' => !empty($data['options']) ? json_encode($data['options']) : $field['options_json'],
                'is_required' => !empty($data['is_required']) ? 1 : 0,
                'display_order' => (int)($data['display_order'] ?? $field['display_order']),
                'is_active' => !empty($data['is_active']) ? 1 : 0,
            ];
            
            Database::update('custom_fields', $updateData, 'id = ?', [$id]);
            
            return ['success' => true, 'message' => 'Το πεδίο ενημερώθηκε επιτυχώς'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()];
        }
    }
    
    /**
     * Require superadmin
     */
    private function requireSuperAdmin(): void {
        if (!$this->auth->isLoggedIn()) {
            redirect('?page=login');
        }
        
        if ($this->auth->needsUsernameSetup()) {
            redirect('?page=set-username');
        }
        
        if (!$this->auth->isSuperAdmin()) {
            redirect('?page=dashboard');
        }
    }
}
