<?php
/**
 * Application Controller
 * Handles application CRUD, drafts, and management
 */

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Application.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/validation.php';
require_once __DIR__ . '/../helpers/export_helper.php';

// Χρήση της βιβλιοθήκης PhpSpreadsheet για το Excel
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ApplicationController {
    private Auth $auth;
    private Application $appModel;
    private User $userModel;
    
    public function __construct() {
        $this->auth = new Auth();
        $this->appModel = new Application();
        $this->userModel = new User();
    }
    
    /**
     * List applications
     */
    public function list(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [$user['id']];
        
        // Admin/superadmin can see all
        if ($this->auth->isSuperAdmin()) {
            $userIds = []; // Empty = all
        } else {
            // Admin & Partner βλέπουν μόνο τον εαυτό τους + το downline τους
            $userIds = $this->userModel->getDownlineIds($user['id']);
            $userIds[] = $user['id']; // Προσθήκη και του εαυτού τους
        }
        
        // Get filter parameters
        $filters = [
            'user_ids' => $userIds,
            'status' => $_GET['status'] ?? null,
            'search' => $_GET['search'] ?? null,
        ];
        
        $applications = $this->appModel->getAll($filters, 5000);
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/list.php';
    }
    
    /**
     * Create new application form
     */
/**
     * Create new application form
     */
    public function create(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $errors = [];
        $data = [];
        $isEdit = false;
        $app = null;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Check CSRF
            if (!checkCsrf()) {
                $errors['general'] = 'Μη έγκυρο αίτημα.';
            } else {
                $data = $this->sanitizeInput($_POST);
                $validation = $this->validateApplication($data);
                
                if ($validation['valid']) {
                    try {
                        // 1. Αποθήκευση της αίτησης και λήψη του $appId
                        $appId = $this->appModel->create(array_merge($data, [
                            'user_id' => $user['id'],
                            'partner_code' => $user['code'],
                        ]));
                        
                        // 2. Ανέβασμα Δικαιολογητικών (Νέα ασφαλής λογική)
                        $this->handleFileUploads($appId);
                        
                        // 3. Αφού αποθηκευτούν όλα, κάνουμε ανακατεύθυνση!
                        redirect('?page=applications&success=created');
                        
                    } catch (Throwable $e) {
                        $errors['general'] = 'Σφάλμα κατά την αποθήκευση: ' . $e->getMessage();
                    }
                } else {
                    $errors = $validation['errors'];
                }
            }
        }
        
        // Load custom fields if any
        $customFields = $this->getCustomFields();
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/form.php';
    }
    
    /**
     * Edit application
     */
    public function edit(): void {
        $this->requireAuth();
        
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) {
            redirect('?page=applications');
        }
        
        $app = $this->appModel->getById($id);
        if (!$app) {
            redirect('?page=applications&error=not_found');
        }
        
        $user = $this->auth->getCurrentUser();
        
        // Check permissions
        if (!$this->canEdit($app, $user)) {
            redirect('?page=applications&error=forbidden');
        }
        
        $errors = [];
        $data = [];
        $isEdit = true;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!checkCsrf()) {
                $errors['general'] = 'Μη έγκυρο αίτημα.';
            } else {
                $data = $this->sanitizeInput($_POST);
                $validation = $this->validateApplication($data);
                
                if ($validation['valid']) {
                    try {
                        // 1. Ενημέρωση των στοιχείων της αίτησης
                        $this->appModel->update($id, $data);
                        
                        // 2. Ανέβασμα τυχόν ΝΕΩΝ Δικαιολογητικών (Νέα ασφαλής λογική)
                        $this->handleFileUploads($id);

                        // 3. Ανακατεύθυνση
                        redirect('?page=applications&success=updated');
                    } catch (Throwable $e) {
                        $errors['general'] = 'Σφάλμα κατά την ενημέρωση: ' . $e->getMessage();
                    }
                } else {
                    $errors = $validation['errors'];
                }
            }
        }
        
        // Load custom fields
        $customFields = $this->getCustomFields();
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/form.php';
    }

    /**
     * Βοηθητική μέθοδος (Helper) για την ασφαλή αποθήκευση αρχείων
     * Μπορεί να κληθεί και στην create() και στην edit()
     */
    private function handleFileUploads(int $appId): void {
        if (!empty($_FILES['attachments']['name'][0])) {
            $uploadDir = __DIR__ . '/../uploads/applications/' . $appId . '/';
            
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $totalFiles = count($_FILES['attachments']['name']);
            for ($i = 0; $i < $totalFiles; $i++) {
                // Ελέγχουμε αν το αρχείο ανέβηκε χωρίς σφάλματα
                if ($_FILES['attachments']['error'][$i] === UPLOAD_ERR_OK) {
                    
                    $originalName = basename($_FILES['attachments']['name'][$i]);
                    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    
                    // 1. Παραγωγή τυχαίου, ασφαλούς ονόματος για τον δίσκο (stored_name)
                    $storedName = bin2hex(random_bytes(16)) . '_' . time() . '.' . $extension;
                    $targetFilePath = $uploadDir . $storedName;
                    
                    $tmpName = $_FILES['attachments']['tmp_name'][$i];
                    
                    // 2. Εύρεση Mime Type και Μεγέθους
                    $mimeType = mime_content_type($tmpName);
                    if (!$mimeType) {
                        $mimeType = 'application/octet-stream';
                    }
                    $fileSize = (int)$_FILES['attachments']['size'][$i];
                    
                    // 3. Αποθήκευση στο δίσκο
                    if (move_uploaded_file($tmpName, $targetFilePath)) {
                        // 4. Αποθήκευση των πληροφοριών στη Βάση Δεδομένων!
                        $this->appModel->addFile($appId, $originalName, $storedName, $mimeType, $fileSize);
                    }
                }
            }
        }
    }
    /**
     * Update status
     */
    public function updateStatus(): void {
        $this->requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_error('Invalid method', 405);
        }
        
        if (!checkCsrf()) {
            json_error('Invalid CSRF token', 403);
        }
        
        $id = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? '';
        
        $app = $this->appModel->getById($id);
        if (!$app) {
            json_error('Application not found', 404);
        }
        
        $user = $this->auth->getCurrentUser();
        if (!$this->canEdit($app, $user)) {
            json_error('Forbidden', 403);
        }
        
        $validStatuses = ['ΝΕΟ', 'ΚΑΤΑΧΩΡΗΜΕΝΟ', 'ΕΚΚΡΕΜΟΤΗΤΑ', 'ΑΚΥΡΟ', 'ΕΝΕΡΓΟ'];
        if (!in_array($status, $validStatuses, true)) {
            json_error('Invalid status', 400);
        }
        
        try {
            $this->appModel->updateStatus($id, $status);
            json_success([], 'Η κατάσταση ενημερώθηκε');
        } catch (Throwable $e) {
            json_error('Update failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Update notes
     */
    public function updateNotes(): void {
        $this->requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_error('Invalid method', 405);
        }
        
        if (!checkCsrf()) {
            json_error('Invalid CSRF token', 403);
        }
        
        $id = (int)($_POST['id'] ?? 0);
        $notes = $_POST['notes'] ?? null;
        
        $app = $this->appModel->getById($id);
        if (!$app) {
            json_error('Application not found', 404);
        }
        
        $user = $this->auth->getCurrentUser();
        if (!$this->canEdit($app, $user)) {
            json_error('Forbidden', 403);
        }
        
        try {
            $this->appModel->updateNotes($id, $notes);
            json_success([], 'Οι σημειώσεις ενημερώθηκαν');
        } catch (Throwable $e) {
            json_error('Update failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Delete application
     */
    public function delete(): void {
        $this->requireAuth();
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            json_error('Invalid method', 405);
        }
        
        if (!checkCsrf()) {
            json_error('Invalid CSRF token', 403);
        }
        
        $id = (int)($_POST['id'] ?? 0);
        
        $app = $this->appModel->getById($id);
        if (!$app) {
            json_error('Application not found', 404);
        }
        
        $user = $this->auth->getCurrentUser();
        if (!$this->auth->isAdminOrSuper() && $app['user_id'] !== $user['id']) {
            json_error('Forbidden', 403);
        }
        
        try {
            $this->appModel->delete($id);
            json_success([], 'Η αίτηση διαγράφηκε');
        } catch (Throwable $e) {
            json_error('Delete failed: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Show statistics
     */
    public function stats(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [$user['id']];
        
        if ($this->auth->isAdminOrSuper()) {
            $userIds = [];
        } else {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        $stats = $this->appModel->getStats($userIds);
        $dailyStats = $this->appModel->getDailyStats(30, $userIds);
        $monthlyStats = $this->appModel->getMonthlyStats(12, $userIds);
        $partnerStats = $this->appModel->getPartnerStats(10, $userIds);
        $avgActivationTime = $this->appModel->getAverageActivationTime($userIds);
        $monthComparison = $this->appModel->getMonthComparison($userIds);
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/stats.php';
    }
    
    /**
     * API: Get application
     */
    public function apiGet(): void {
        $this->requireAuth();
        
        $id = (int)($_GET['id'] ?? 0);
        $app = $this->appModel->getById($id);
        
        if (!$app) {
            json_error('Application not found', 404);
        }
        
        $user = $this->auth->getCurrentUser();
        if (!$this->canView($app, $user)) {
            json_error('Forbidden', 403);
        }
        
        json_success(['application' => $app]);
    }
    
    /**
     * API: List applications
     */
    public function apiList(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [$user['id']];
        
        if ($this->auth->isAdminOrSuper()) {
            $userIds = [];
        } else {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        $filters = [
            'user_ids' => $userIds,
            'status' => $_GET['status'] ?? null,
            'search' => $_GET['search'] ?? null,
        ];
        
        $applications = $this->appModel->getAll($filters, 5000);
        
        json_success(['applications' => $applications]);
    }
    
    /**
     * Check if user can edit application
     */
    private function canEdit(array $app, array $user): bool {
        if ($this->auth->isAdminOrSuper()) {
            return true;
        }
        return $app['user_id'] === $user['id'];
    }
    
    /**
     * Export applications to CSV
     */
    public function export(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        
        if ($this->auth->isAdminOrSuper()) {
            $userIds = []; 
        } else {
            $userIds = $this->userModel->getDownlineIds($user['id']);
            $userIds[] = $user['id'];
        }
        
        $filters = [
            'user_ids' => $userIds,
            'status' => $_GET['status'] ?? null,
            'search' => $_GET['search'] ?? null,
        ];
        
        $applications = $this->appModel->getAll($filters, 10000);
        // Χρησιμοποιούμε .xlsx για εξαγωγή!
        $filename = 'export_applications_' . date('Y-m-d_H-i') . '.xlsx';
        
        $headers = [
            'last_name' => 'Επώνυμο',
            'first_name' => 'Όνομα',
            'father_name' => 'Όνομα Πατρός',
            'afm' => 'ΑΦΜ',
            'adt' => 'ΑΔΤ',
            'dou' => 'ΔΟΥ',
            'date_of_birth' => 'Ημ. Γέννησης (YYYY-MM-DD)',
            'company' => 'Εταιρεία',
            'company_afm' => 'ΑΦΜ Εταιρείας',
            'landline_phone' => 'Σταθερό',
            'mobile_phone' => 'Κινητό',
            'email' => 'Email',
            'install_address' => 'Διεύθυνση Εγκατάστασης',
            'billing_address' => 'Διεύθυνση Χρέωσης',
            'request_type' => 'Τύπος (ΣΤΑΘΕΡΟ/ΚΙΝΗΤΟ)',
            'landline_program' => 'Πρόγραμμα Σταθερού',
            'mobile_program' => 'Πρόγραμμα Κινητού',
            'price' => 'Τιμή',
            'partner_name' => 'Username Ιδιοκτήτη'
        ];

        require_once __DIR__ . '/../helpers/export_helper.php';
        export_to_xlsx($applications, $headers, $filename);
        exit;
    }

    /**
     * Check if user can view application
     */
    private function canView(array $app, array $user): bool {
        if ($this->auth->isAdminOrSuper()) {
            return true;
        }
        if ($app['user_id'] === $user['id']) {
            return true;
        }
        $downlineIds = $this->userModel->getDownlineIds($user['id']);
        return in_array($app['user_id'], $downlineIds, true);
    }
    
    /**
     * Validate application data
     */
    private function validateApplication(array $data): array {
        $rules = [
            'first_name' => ['required' => true, 'max' => 100],
            'last_name' => ['required' => true, 'max' => 100],
            'afm' => ['required' => true, 'afm' => true],
            'mobile_phone' => ['required' => true, 'phone' => true],
            'email' => ['email' => true],
        ];
        
        return validate($data, $rules);
    }
    
    /**
     * Sanitize input data
     */
    private function sanitizeInput(array $input): array {
        $data = [];
        $fields = [
            'first_name', 'last_name', 'father_name', 'afm', 'adt', 'dou',
            'date_of_birth', 'company', 'company_afm',
            'landline_phone', 'mobile_phone', 'email',
            'application_number', 'price',
            'install_address', 'billing_address',
            'request_type', 'landline_program', 'mobile_program',
            'contact_date', 'status', 'notes'
        ];
        
        foreach ($fields as $field) {
            if (isset($input[$field])) {
                $data[$field] = trim($input[$field]);
            }
        }
        
        return $data;
    }
    
    /**
     * Get custom fields
     */
    private function getCustomFields(): array {
        try {
            $sql = "SELECT * FROM custom_fields WHERE is_active = 1 ORDER BY display_order";
            return Database::fetchAll($sql);
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * List draft applications
     */
    public function drafts(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $drafts = $this->getUserDrafts($user['id']);
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/draft_list.php';
    }
    
    /**
     * Edit draft
     */
    public function editDraft(): void {
        $this->requireAuth();
        
        $draftId = (int)($_GET['id'] ?? 0);
        $user = $this->auth->getCurrentUser();
        
        $draft = $this->getDraft($draftId);
        if (!$draft || $draft['user_id'] != $user['id']) {
            redirect('?page=applications&action=drafts');
        }
        
        $data = json_decode($draft['data'], true);
        $errors = [];
        $customFields = $this->getCustomFields();
        $app = null;
        $isEdit = false;
        $auth = $this->auth;
        
        include __DIR__ . '/../views/applications/form.php';
    }
    /**
     * API: Save Draft (Αυτόματη Αποθήκευση)
     */
    public function apiSaveDraft(): void {
        $this->requireAuth();
        $user = $this->auth->getCurrentUser();
        
        // Διαβάζουμε τα δεδομένα JSON που στέλνει η Javascript
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            json_error('Μη έγκυρα δεδομένα', 400);
        }
        
        // Ψάχνουμε αν το draft έχει ήδη ID (δηλαδή αν κάνουμε συνέχεια επεξεργασίας)
        $draftId = 0;
        if (!empty($data['_draft_meta']['url'])) {
            $urlParts = parse_url($data['_draft_meta']['url']);
            if (isset($urlParts['query'])) {
                parse_str($urlParts['query'], $query);
                if (isset($query['id']) && ($query['action'] ?? '') === 'edit-draft') {
                    $draftId = (int)$query['id'];
                }
            }
        }
        
        try {
            if ($draftId) {
                // Ενημέρωση υπάρχοντος draft
                $draft = $this->getDraft($draftId);
                if ($draft && $draft['user_id'] == $user['id']) {
                    Database::query("UPDATE application_drafts SET data = ?, updated_at = NOW() WHERE id = ?", [json_encode($data), $draftId]);
                }
            } else {
                // Αν δεν υπάρχει ID, απλά δημιουργούμε ένα νέο
                Database::query("INSERT INTO application_drafts (user_id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())", [$user['id'], json_encode($data)]);
            }
            json_success(['message' => 'Draft saved to server']);
        } catch (Throwable $e) {
            json_error('Σφάλμα: ' . $e->getMessage(), 500);
        }
    }

    /**
     * API: Delete Draft
     */
    public function apiDeleteDraft(): void {
        $this->requireAuth();
        
        if (!checkCsrf()) {
            json_error('Μη έγκυρο αίτημα (CSRF)', 403);
        }
        
        $user = $this->auth->getCurrentUser();
        $draftId = (int)($_POST['id'] ?? 0);
        
        $draft = $this->getDraft($draftId);
        if (!$draft || $draft['user_id'] != $user['id']) {
            json_error('Δεν βρέθηκε το draft ή δεν έχετε δικαίωμα', 403);
        }
        
        try {
            Database::query("DELETE FROM application_drafts WHERE id = ?", [$draftId]);
            json_success([], 'Το draft διαγράφηκε επιτυχώς');
        } catch (Throwable $e) {
            json_error('Σφάλμα: ' . $e->getMessage(), 500);
        }
    }

    /**
     * API: Submit Draft (Μετατροπή Draft σε Κανονική Αίτηση)
     */
    public function apiSubmitDraft(): void {
        $this->requireAuth();
        
        if (!checkCsrf()) {
            json_error('Μη έγκυρο αίτημα (CSRF)', 403);
        }
        
        $user = $this->auth->getCurrentUser();
        $draftId = (int)($_POST['id'] ?? 0);
        
        $draft = $this->getDraft($draftId);
        if (!$draft || $draft['user_id'] != $user['id']) {
            json_error('Δεν βρέθηκε το draft', 403);
        }
        
        $data = json_decode($draft['data'], true);
        
        // Βασικός έλεγχος ότι υπάρχουν τα απαραίτητα
        if (empty($data['first_name']) && empty($data['last_name'])) {
            json_error('Απαιτείται όνομα ή επώνυμο μέσα στο Draft για να υποβληθεί', 400);
        }
        
        try {
            // Μετατροπή των δεδομένων σε πραγματική αίτηση (εφαρμόζουμε το ίδιο format με τη φόρμα)
            $appData = array_merge($this->sanitizeInput($data), [
                'user_id' => $user['id'],
                'partner_code' => $user['code'],
                'status' => 'ΝΕΟ' // Κατάσταση νέας αίτησης
            ]);
            
            // Δημιουργία της αίτησης
            $this->appModel->create($appData);
            
            // Διαγραφή του draft εφόσον έγινε κανονική αίτηση!
            Database::query("DELETE FROM application_drafts WHERE id = ?", [$draftId]);
            
            json_success([], 'Η αίτηση υποβλήθηκε επιτυχώς!');
        } catch (Throwable $e) {
            json_error('Σφάλμα υποβολής: ' . $e->getMessage(), 500);
        }
    }
    /**
     * Import applications
     */
    public function import(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            redirect('?page=applications');
        }
        
        $step = (int)($_POST['step'] ?? $_GET['step'] ?? 1);
        $preview = [];
        $validationSummary = ['total' => 0, 'valid' => 0, 'errors' => 0];
        $tempFile = '';
        $importResult = [];
        $errors = [];
        $auth = $this->auth;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            switch ($step) {
                case 1:
                    $result = $this->handleImportUpload();
                    if ($result['success']) {
                        $tempFile = $result['temp_file'];
                        $preview = $result['preview'];
                        $validationSummary = $result['summary'];
                        $step = 2;
                    } else {
                        $errors['general'] = $result['message'];
                    }
                    break;
                    
                case 3:
                    $tempFile = $_POST['temp_file'] ?? '';
                    $importResult = $this->processImport($tempFile);
                    $step = 3;
                    break;
            }
        }
        
        include __DIR__ . '/../views/applications/import.php';
    }

    public function downloadTemplate(): void {
        $this->requireAuth();
        
        // 1. ΔΥΝΑΜΙΚΗ ΦΟΡΤΩΣΗ ΤΗΣ ΒΙΒΛΙΟΘΗΚΗΣ
        $autoloadPaths = [
            __DIR__ . '/../vendor/autoload.php',
            __DIR__ . '/../VENDOR/autoload.php',
            __DIR__ . '/../../vendor/autoload.php',
            __DIR__ . '/../../VENDOR/autoload.php'
        ];
        
        $loaded = false;
        foreach ($autoloadPaths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $loaded = true;
                break;
            }
        }
        
        if (!$loaded) {
            die('Σφάλμα: Δεν βρέθηκε το αρχείο vendor/autoload.php.');
        }

        // 2. Δεδομένα του Προτύπου
        $headers = [
            'Επώνυμο', 'Όνομα', 'Όνομα Πατρός', 'ΑΦΜ', 'ΑΔΤ', 'ΔΟΥ',
            'Ημ. Γέννησης (YYYY-MM-DD)', 'Εταιρεία', 'ΑΦΜ Εταιρείας',
            'Σταθερό', 'Κινητό', 'Email', 'Διεύθυνση Εγκατάστασης',
            'Διεύθυνση Χρέωσης', 'Τύπος (ΣΤΑΘΕΡΟ/ΚΙΝΗΤΟ)',
            'Πρόγραμμα Σταθερού', 'Πρόγραμμα Κινητού', 'Τιμή', 'Username Ιδιοκτήτη'
        ];
        
        $sample = [
            'Παπαδόπουλος', 'Γιώργος', 'Νικόλαος', '123456789', 'ΑΒ123456', 'Αθηνών',
            '1985-03-15', '', '', '2101234567', '6912345678', 'email@example.com',
            'Οδός Παραδείγματος 1', 'Οδός Παραδείγματος 1', 'ΣΤΑΘΕΡΟ', 'DP GR+300 - ADSL 24', '', '29.90', 'partner1'
        ];
        
        // 3. Καθαρισμός buffer για να μην μπει σκουπίδι στο αρχείο
        if (ob_get_length()) {
            ob_clean();
        }

        // 4. Δημιουργία αρχείου Excel
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        
        // FIX ΓΙΑ PHP 8.3+: Χρησιμοποιούμε αριθμούς για τις στήλες (1, 2, 3...)
        $colIndex = 1;
        foreach ($headers as $headerTitle) {
            // Το Coordinate::stringFromColumnIndex μετατρέπει το 1 σε 'A', το 2 σε 'B' κ.ο.κ.
            $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colIndex);
            
            $sheet->setCellValue($colLetter . '1', $headerTitle);
            $sheet->getStyle($colLetter . '1')->getFont()->setBold(true);
            $sheet->getColumnDimension($colLetter)->setAutoSize(true);
            
            $colIndex++; // Εδώ πλέον αυξάνουμε αριθμό, όχι string, οπότε τέλος τα warnings!
        }
        
        // Δείγμα εγγραφής (Γραμμή 2)
        $colIndex = 1;
        foreach ($sample as $value) {
            $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colIndex);
            $sheet->setCellValue($colLetter . '2', $value);
            $colIndex++;
        }
        
        $filename = 'import_template_' . date('Y-m-d') . '.xlsx';
        
        // 5. Αποστολή Headers
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        
        // 6. Παραγωγή αρχείου
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    /**
     * Dashboard
     */
    public function dashboard(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [$user['id']];
        
        if ($this->auth->isAdminOrSuper()) {
            $userIds = [];
        } else {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        $stats = $this->appModel->getStats($userIds);
        $monthComparison = $this->appModel->getMonthComparison($userIds);
        $recentApps = $this->appModel->getAll(['user_ids' => $userIds], 10);
        $auth = $this->auth;
        
        include __DIR__ . '/../views/dashboard/index.php';
    }
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού (Έκδοση Διάγνωσης Σφαλμάτων)
     */
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού από τη Βάση Δεδομένων
     */
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού από τη Βάση Δεδομένων
     */
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού από τη Βάση Δεδομένων
     */
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού από τη Βάση Δεδομένων
     */
    /**
     * Λήψη ενός αρχείου/δικαιολογητικού από τη Βάση Δεδομένων
     */
    public function download(): void {
        $this->requireAuth();

        $fileId = isset($_GET['file_id']) ? (int)$_GET['file_id'] : 0;
        
        if ($fileId > 0) {
            // Ψάχνουμε το αρχείο απευθείας στη βάση μέσω της κλάσης Database
            $fileRecord = \Database::fetchOne("SELECT * FROM application_files WHERE id = ?", [$fileId]);
            
            if ($fileRecord) {
                $appId = $fileRecord['application_id'];
                $storedName = $fileRecord['stored_name'];
                $originalName = $fileRecord['original_name'];
                $mimeType = $fileRecord['mime_type'] ?: 'application/octet-stream';
                
                // Φτιάχνουμε το σωστό path για το που βρίσκεται αποθηκευμένο στο δίσκο
                $filepath = __DIR__ . '/../uploads/applications/' . $appId . '/' . $storedName; 
                
                if (file_exists($filepath)) {
                    
                    // 1. Καθαρίζουμε ΟΛΑ τα buffers για να μην υπάρχουν κενά που χαλάνε το αρχείο
                    while (ob_get_level()) { ob_end_clean(); }
                    
                    // 2. Αφαιρούμε τυχόν global Content-Type (π.χ. application/json) που χαλάει το download
                    header_remove('Content-Type');
                    
                    // 3. Στέλνουμε τα σωστά headers λήψης με το αυθεντικό όνομα του αρχείου
                    header('Content-Type: ' . $mimeType);
                    header('Content-Disposition: attachment; filename="' . basename($originalName) . '"');
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');
                    header('Content-Length: ' . filesize($filepath));
                    
                    // 4. Διαβάζουμε και κατεβάζουμε το αρχείο
                    readfile($filepath);
                    exit;
                    
                } else {
                    die("Το αρχείο υπάρχει στη βάση, αλλά έχει διαγραφεί από τον φάκελο του server.");
                }
            } else {
                die("Το αρχείο δεν βρέθηκε στη βάση δεδομένων.");
            }
        } else {
            die("Λείπει η παράμετρος file_id.");
        }
    }


    /**
     * Διαγραφή ενός δικαιολογητικού
     */
    /**
     * Διαγραφή ενός δικαιολογητικού (ΝΕΑ ΛΟΓΙΚΗ)
     */
    public function delete_attachment(): void {
        $this->requireAuth();
        
        $fileId = isset($_GET['file_id']) ? intval($_GET['file_id']) : 0;
        
        if ($fileId > 0) {
            $fileRecord = $this->appModel->getFile($fileId);
            
            if ($fileRecord) {
                $appId = $fileRecord['application_id'];
                $storedName = $fileRecord['stored_name'];
                
                $filepath = __DIR__ . '/../uploads/applications/' . $appId . '/' . $storedName;

                // 1. Διαγραφή από τον δίσκο (αν υπάρχει)
                if (file_exists($filepath)) {
                    unlink($filepath);
                }

                // 2. Διαγραφή από τη Βάση
                $this->appModel->deleteFile($fileId);

                redirect('?page=applications&action=edit&id=' . $appId . '&success=file_deleted');
            } else {
                die('Το αρχείο δεν βρέθηκε στη βάση δεδομένων.');
            }
        } else {
            die('Μη έγκυρο File ID.');
        }
    }
    /**
     * Get user drafts
     */
    private function getUserDrafts(int $userId): array {
        try {
            return Database::fetchAll(
                "SELECT * FROM application_drafts WHERE user_id = ? ORDER BY updated_at DESC",
                [$userId]
            );
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * Get single draft
     */
    private function getDraft(int $draftId): ?array {
        try {
            return Database::fetchOne(
                "SELECT * FROM application_drafts WHERE id = ?",
                [$draftId]
            );
        } catch (Throwable $e) {
            return null;
        }
    }
    
    private function mapImportRow(array $rawRow): array {
        $headerMap = [
            'Επώνυμο' => 'last_name',
            'Όνομα' => 'first_name',
            'Όνομα Πατρός' => 'father_name',
            'ΑΦΜ' => 'afm',
            'ΑΔΤ' => 'adt',
            'ΔΟΥ' => 'dou',
            'Ημ. Γέννησης (YYYY-MM-DD)' => 'date_of_birth',
            'Εταιρεία' => 'company',
            'ΑΦΜ Εταιρείας' => 'company_afm',
            'Σταθερό' => 'landline_phone',
            'Κινητό' => 'mobile_phone',
            'Email' => 'email',
            'Διεύθυνση Εγκατάστασης' => 'install_address',
            'Διεύθυνση Χρέωσης' => 'billing_address',
            'Τύπος (ΣΤΑΘΕΡΟ/ΚΙΝΗΤΟ)' => 'request_type',
            'Πρόγραμμα Σταθερού' => 'landline_program',
            'Πρόγραμμα Κινητού' => 'mobile_program',
            'Τιμή' => 'price',
            'Username Ιδιοκτήτη' => 'owner'
        ];

        $mapped = [];
        foreach ($rawRow as $key => $value) {
            $trimKey = trim((string)$key);
            $trimKey = preg_replace('/^[\xEF\xBB\xBF]+/', '', $trimKey);
            
            $val = trim((string)$value);
            
            if (isset($headerMap[$trimKey])) {
                $englishKey = $headerMap[$trimKey];
                
                // Διόρθωση ΑΦΜ: Αν το Excel έφαγε το αρχικό 0 και το έκανε 8-ψήφιο, το ξαναβάζουμε
                if (($englishKey === 'afm' || $englishKey === 'company_afm') && strlen($val) === 8 && is_numeric($val)) {
                    $val = '0' . $val;
                }
                
                $mapped[$englishKey] = $val;
            } else {
                $mapped[$trimKey] = $val;
            }
        }
        return $mapped;
    }

    /**
     * Handle import upload
     */
    private function handleImportUpload(): array {
        if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Σφάλμα ανεβάσματος αρχείου'];
        }
        
        $file = $_FILES['import_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, ['csv', 'xlsx'])) {
            return ['success' => false, 'message' => 'Μη έγκυρη μορφή αρχείου. Υποστηρίζονται μόνο CSV και XLSX.'];
        }
        
        $tempFile = tempnam(sys_get_temp_dir(), 'import_');
        move_uploaded_file($file['tmp_name'], $tempFile);
        
        // Parse file
        if ($ext === 'csv') {
            $data = parse_csv($tempFile);
        } else {
            try {
                $data = parse_xlsx($tempFile);
            } catch (Exception $e) {
                unlink($tempFile);
                return ['success' => false, 'message' => 'Σφάλμα ανάγνωσης XLSX: ' . $e->getMessage()];
            }
        }
        
        // Validate rows
        $preview = [];
        $summary = ['total' => 0, 'valid' => 0, 'errors' => 0];
        $rowNum = 1; // Ξεκινάμε από τη γραμμή 1 (headers) αλλά τα δεδομένα είναι στη 2
        
        foreach ($data as $rawRow) {
            $rowNum++; // Η πρώτη γραμμή δεδομένων στο Excel είναι ουσιαστικά το Row 2
            $row = $this->mapImportRow($rawRow); // <--- Μετάφραση στηλών!
            
            $errors = [];
            
            if (empty($row['first_name']) && empty($row['last_name'])) {
                $errors[] = 'Απαιτείται όνομα ή επώνυμο';
            }
            if (empty($row['afm'])) {
                $errors[] = 'Απαιτείται ΑΦΜ';
            } elseif (!validate_afm($row['afm'])) {
                $errors[] = 'Μη έγκυρο ΑΦΜ';
            }
            if (empty($row['mobile_phone'])) {
                $errors[] = 'Απαιτείται κινητό τηλέφωνο';
            }
            
            if (!empty($row['owner'])) {
                $owner = $this->userModel->getByUsername($row['owner']);
                if (!$owner) {
                    $owner = $this->userModel->getByCode($row['owner']);
                }
                if (!$owner) {
                    $errors[] = 'Ο ιδιοκτήτης δεν βρέθηκε: ' . $row['owner'];
                }
            }
            
            $isValid = empty($errors);
            $preview[] = [
                'row' => $rowNum,
                'data' => $row, // Αποθηκεύουμε τα "μεταφρασμένα" δεδομένα
                'valid' => $isValid,
                'errors' => $errors,
            ];
            
            $summary['total']++;
            if ($isValid) {
                $summary['valid']++;
            } else {
                $summary['errors']++;
            }
        }
        
        return [
            'success' => true,
            'temp_file' => basename($tempFile),
            'preview' => $preview,
            'summary' => $summary,
        ];
    }
    
    /**
     * Process import
     */
    private function processImport(string $tempFile): array {
        $fullPath = sys_get_temp_dir() . '/' . $tempFile;
        
        if (!file_exists($fullPath)) {
            return ['success' => 0, 'errors' => 0, 'error_details' => [['row' => 0, 'message' => 'Το αρχείο δεν βρέθηκε']]];
        }
        
        $ext = pathinfo($tempFile, PATHINFO_EXTENSION);
        
        if ($ext === 'csv' || strpos($tempFile, 'csv') !== false) {
            $data = parse_csv($fullPath);
        } else {
            $data = parse_xlsx($fullPath);
        }
        
        $success = 0;
        $errors = 0;
        $errorDetails = [];
        $rowNum = 1;
        
        foreach ($data as $rawRow) {
            $rowNum++;
            $row = $this->mapImportRow($rawRow); // <--- Μετάφραση στηλών!
            
            if (empty($row['first_name']) && empty($row['last_name'])) {
                continue;
            }
            if (empty($row['afm']) || !validate_afm($row['afm'])) {
                continue;
            }
            if (empty($row['mobile_phone'])) {
                continue;
            }
            
            $ownerId = null;
            $partnerCode = '';
            if (!empty($row['owner'])) {
                $owner = $this->userModel->getByUsername($row['owner']);
                if (!$owner) {
                    $owner = $this->userModel->getByCode($row['owner']);
                }
                if ($owner) {
                    $ownerId = $owner['id'];
                    $partnerCode = $owner['code'];
                }
            }
            
            if (!$ownerId) {
                $errorDetails[] = ['row' => $rowNum, 'message' => 'Ιδιοκτήτης δεν βρέθηκε: ' . ($row['owner'] ?? 'N/A')];
                $errors++;
                continue;
            }
            
            try {
                $this->appModel->create([
                    'user_id' => $ownerId,
                    'partner_code' => $partnerCode,
                    'first_name' => $row['first_name'] ?? '',
                    'last_name' => $row['last_name'] ?? '',
                    'father_name' => $row['father_name'] ?? '',
                    'afm' => $row['afm'] ?? '',
                    'adt' => $row['adt'] ?? '',
                    'dou' => $row['dou'] ?? '',
                    'date_of_birth' => $row['date_of_birth'] ?? '',
                    'company' => $row['company'] ?? '',
                    'company_afm' => $row['company_afm'] ?? '',
                    'landline_phone' => $row['landline_phone'] ?? '',
                    'mobile_phone' => $row['mobile_phone'] ?? '',
                    'email' => $row['email'] ?? '',
                    'install_address' => $row['install_address'] ?? '',
                    'billing_address' => $row['billing_address'] ?? '',
                    'request_type' => $row['request_type'] ?? 'ΣΤΑΘΕΡΟ',
                    'landline_program' => $row['landline_program'] ?? '',
                    'mobile_program' => $row['mobile_program'] ?? '',
                    'price' => $row['price'] ?? '',
                    'status' => 'ΝΕΟ',
                ]);
                $success++;
            } catch (Throwable $e) {
                $errorDetails[] = ['row' => $rowNum, 'message' => $e->getMessage()];
                $errors++;
            }
        }
        
        unlink($fullPath);
        
        return [
            'success' => $success,
            'errors' => $errors,
            'error_details' => $errorDetails,
        ];
    }
    /**
     * Require authentication
     */
    private function requireAuth(): void {
        if (!$this->auth->isLoggedIn()) {
            redirect('?page=login');
        }
        
        if ($this->auth->needsUsernameSetup()) {
            redirect('?page=set-username');
        }
    }
}