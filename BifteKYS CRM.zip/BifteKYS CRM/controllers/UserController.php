<?php
/**
 * User Controller
 * Handles user management and tree view
 */

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../helpers/validation.php';

class UserController {
    private Auth $auth;
    private User $userModel;
    
    public function __construct() {
        $this->auth = new Auth();
        $this->userModel = new User();
    }
    
    /**
     * Show user tree
     */
    public function tree(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        
        // Ο SuperAdmin βλέπει όλο το δέντρο, οι άλλοι βλέπουν μόνο από αυτούς και κάτω
        if ($this->auth->isSuperAdmin()) {
            $tree = $this->userModel->buildTree();
        } else {
            $tree = $this->userModel->buildTreeForUser($user['id']);
        }
        
        include __DIR__ . '/../views/users/tree.php';
    }

public function manage(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            redirect('?page=dashboard');
        }
        
        $user = $this->auth->getCurrentUser();
        
        // Ο Admin βλέπει μόνο το downline του, όχι τους άλλους Admin
        if ($this->auth->isSuperAdmin()) {
            $users = $this->userModel->getAll();
        } else {
            $users = $this->userModel->getDownline($user['id']);
        }
        
        // ΑΡΧΙΚΟΠΟΙΗΣΗ ΜΕΤΑΒΛΗΤΩΝ ΕΔΩ
        $error = null;
        $success = null;
        
        // Handle form submissions
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!checkCsrf()) {
                $error = 'Μη έγκυρο αίτημα.';
            } else {
                $action = $_POST['action'] ?? '';
                
                switch ($action) {
                    case 'create':
                        $result = $this->handleCreate();
                        if ($result['success']) {
                            $success = 'Ο χρήστης δημιουργήθηκε επιτυχώς.';
                            $users = $this->userModel->getAll();
                        } else {
                            $error = $result['message'];
                        }
                        break;
                        
                    case 'update':
                        $result = $this->handleUpdate();
                        if ($result['success']) {
                            $success = 'Ο χρήστης ενημερώθηκε επιτυχώς.';
                            $users = $this->userModel->getAll();
                        } else {
                            $error = $result['message'];
                        }
                        break;
                        
                    case 'toggle':
                        $result = $this->handleToggle();
                        if ($result['success']) {
                            $success = 'Η κατάσταση του χρήστη ενημερώθηκε.';
                            $users = $this->userModel->getAll();
                        } else {
                            $error = $result['message'];
                        }
                        break;
                }
            }
        }
        
        include __DIR__ . '/../views/users/manage.php';
    }
    
    /**
     * API: Get user tree
     */
    public function apiTree(): void {
        $this->requireAuth();
        
        $tree = $this->userModel->buildTree();
        
        // Remove sensitive data
        $sanitize = function($nodes) use (&$sanitize) {
            $result = [];
            foreach ($nodes as $node) {
                $clean = [
                    'id' => $node['id'],
                    'username' => $node['username'],
                    'role' => $node['role'],
                    'display_name' => $node['display_name'],
                    'is_active' => $node['is_active'],
                    'children' => $sanitize($node['children'])
                ];
                $result[] = $clean;
            }
            return $result;
        };
        
        json_success(['tree' => $sanitize($tree)]);
    }
    
    /**
     * API: Get users list
     */
    public function apiList(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            json_error('Forbidden', 403);
        }
        
        $users = $this->userModel->getAll();
        
        // Remove sensitive data
        $cleanUsers = array_map(function($u) {
            return [
                'id' => $u['id'],
                'username' => $u['username'],
                'code' => $u['code'],
                'role' => $u['role'],
                'display_name' => $u['display_name'],
                'is_active' => $u['is_active'],
                'parent_user_id' => $u['parent_user_id'],
            ];
        }, $users);
        
        json_success(['users' => $cleanUsers]);
    }
    
    /**
     * API: Create user
     */
    public function apiCreate(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            json_error('Forbidden', 403);
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        $result = $this->createUser($data);
        
        if ($result['success']) {
            json_success(['user_id' => $result['user_id']], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
    
    /**
     * API: Update user
     */
    public function apiUpdate(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            json_error('Forbidden', 403);
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        $result = $this->updateUser($data);
        
        if ($result['success']) {
            json_success([], $result['message']);
        } else {
            json_error($result['message'], 400);
        }
    }
    
    /**
     * Handle create user
     * @return array
     */
    private function handleCreate(): array {
        // Λήψη του ID του συνδεδεμένου χρήστη
        $currentUser = $this->auth->getCurrentUser();
        $currentUserId = $currentUser ? $currentUser['id'] : null;

        // ΑΥΤΟΜΑΤΗ ΔΗΜΙΟΥΡΓΙΑ ΚΩΔΙΚΟΥ: π.χ. USR-65A2B9C
        $autoGeneratedCode = 'USR-' . strtoupper(substr(uniqid(), -6));

        $data = [
            // Βάζουμε τον αυτόματο κωδικό αντί για το $_POST['code']
            'code' => $autoGeneratedCode, 
            'username' => trim($_POST['username'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'role' => $_POST['role'] ?? 'partner',
            'displayname' => trim($_POST['displayname'] ?? ''),
            'parentuserid' => !empty($_POST['parentuserid']) ? (int)$_POST['parentuserid'] : $currentUserId,
        ];
        
        return $this->createUser($data);
    }
    
    /**
     * Create user
     * @param array $data
     * @return array
     */
    private function createUser(array $data): array {
        // Validate
        if (empty($data['code'])) {
            return ['success' => false, 'message' => 'Ο κωδικός χρήστη είναι υποχρεωτικός'];
        }
        
        if ($this->userModel->codeExists($data['code'])) {
            return ['success' => false, 'message' => 'Αυτός ο κωδικός χρήστη χρησιμοποιείται ήδη'];
        }
        
        if (!empty($data['username']) && $this->userModel->usernameExists($data['username'])) {
            return ['success' => false, 'message' => 'Αυτό το username χρησιμοποιείται ήδη'];
        }
        
        $validRoles = ['partner', 'admin', 'superadmin'];
        if (!in_array($data['role'], $validRoles, true)) {
            return ['success' => false, 'message' => 'Μη έγκυρος ρόλος'];
        }
        // Έλεγχος δικαιωμάτων: Ο admin δεν μπορεί να φτιάξει superadmin (ή άλλους ρόλους)
        $currentUser = $this->auth->getCurrentUser();
        if ($currentUser['role'] !== 'superadmin' && $data['role'] !== 'partner') {
            return [
                'success' => false, 
                'message' => 'Δεν έχετε δικαίωμα δημιουργίας αυτού του ρόλου. Μπορείτε να δημιουργήσετε μόνο Partners.'
            ];
        }
        try {
            $userId = $this->userModel->create($data);
            return ['success' => true, 'user_id' => $userId, 'message' => 'Ο χρήστης δημιουργήθηκε επιτυχώς'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()];
        }
    }
    
    /**
     * Handle update user
     * @return array
     */
    private function handleUpdate(): array {
        $id = (int)($_POST['id'] ?? 0);
        
        $data = [
            'displayname' => trim($_POST['displayname'] ?? ''),
            'role' => $_POST['role'] ?? null,
            'parentuserid' => !empty($_POST['parentuserid']) ? (int)$_POST['parentuserid'] : null,
        ];
        
        return $this->updateUser(array_merge($data, ['id' => $id]));
    }
    
    /**
     * Update user
     * @param array $data
     * @return array
     */
    private function updateUser(array $data): array {
        $id = (int)($data['id'] ?? 0);
        
        if (!$id) {
            return ['success' => false, 'message' => 'Μη έγκυρο ID χρήστη'];
        }
        
        $user = $this->userModel->getById($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Ο χρήστης δεν βρέθηκε'];
        }
        
        $updateData = [];
        
        if (isset($data['displayname'])) {
            $updateData['displayname'] = $data['displayname'];
        }
        
        if (isset($data['role'])) {
            $validRoles = ['partner', 'admin', 'superadmin'];
            if (in_array($data['role'], $validRoles, true)) {
                
                $currentUser = $this->auth->getCurrentUser();
                // Μπλοκάρουμε τον Admin αν πάει να δώσει ρόλο διαφορετικό του partner
                if ($currentUser['role'] !== 'superadmin' && $data['role'] !== 'partner') {
                    return ['success' => false, 'message' => 'Μπορείτε να αναθέσετε μόνο το ρόλο του Partner.'];
                }

                $updateData['role'] = $data['role'];
            }
        }
        
        if (isset($data['parentuserid'])) {
            $updateData['parentuserid'] = $data['parentuserid'];
        }
        
        if (empty($updateData)) {
            return ['success' => false, 'message' => 'Δεν υπάρχουν δεδομένα για ενημέρωση'];
        }
        
        try {
            $this->userModel->update($id, $updateData);
            return ['success' => true, 'message' => 'Ο χρήστης ενημερώθηκε επιτυχώς'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()];
        }
    }
    
    /**
     * Handle toggle active
     * @return array
     */
    private function handleToggle(): array {
        $id = (int)($_POST['id'] ?? 0);
        $active = (int)($_POST['active'] ?? 0);
        
        if (!$id) {
            return ['success' => false, 'message' => 'Μη έγκυρο ID χρήστη'];
        }
        
        $user = $this->userModel->getById($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Ο χρήστης δεν βρέθηκε'];
        }
        
        try {
            $this->userModel->setActive($id, (bool)$active);
            return ['success' => true, 'message' => 'Η κατάσταση ενημερώθηκε'];
        } catch (Throwable $e) {
            return ['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()];
        }
    }
    
    /**
     * Require authentication
     */
    private function requireAuth(): void {
        if (!$this->auth->isLoggedIn()) {
            redirect('?page=login');
        }
        
        if ($this->auth->needsUsernameSetup()) {
            redirect('?page=set-username');
        }
    }
    /**
     * User Profile / Settings
     */
    public function profile(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $error = null;
        $success = null;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!checkCsrf()) {
                $error = 'Μη έγκυρο αίτημα.';
            } else {
                $newPassword = $_POST['new_password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';
                
                if (strlen($newPassword) < 6) {
                    $error = 'Ο κωδικός πρέπει να έχει τουλάχιστον 6 χαρακτήρες.';
                } elseif ($newPassword !== $confirmPassword) {
                    $error = 'Οι κωδικοί δεν ταιριάζουν.';
                } else {
                    $this->userModel->setPassword($user['id'], $newPassword);
                    $success = 'Ο κωδικός πρόσβασης ενημερώθηκε επιτυχώς! Παρακαλούμε χρησιμοποιήστε τον νέο κωδικό στην επόμενη σύνδεση.';
                }
            }
        }
        
        include __DIR__ . '/../views/users/profile.php';
    }
}
