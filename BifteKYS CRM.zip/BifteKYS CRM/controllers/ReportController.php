<?php
/**
 * Report Controller
 * Handles reports and statistics
 */

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../models/Application.php';
require_once __DIR__ . '/../models/User.php';

class ReportController {
    private Auth $auth;
    private Application $appModel;
    private User $userModel;
    
    public function __construct() {
        $this->auth = new Auth();
        $this->appModel = new Application();
        $this->userModel = new User();
    }
    
    /**
     * Show reports page
     */
    public function index(): void {
        $this->requireAuth();
        
        // Only admin/superadmin can access full reports
        // Partners can only view read-only summary
        
        $user = $this->auth->getCurrentUser();
        $userIds = [];
        
        if (!$this->auth->isAdminOrSuper()) {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        // Get filter parameters
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $filterBy = $_GET['filter_by'] ?? 'created_at'; // 'created_at' or 'activated_at'
        $status = $_GET['status'] ?? '';
        $owner = $_GET['owner'] ?? '';
        
        // Build filters
        $filters = [
            'user_ids' => $userIds,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
        ];
        
        if ($status) {
            $filters['status'] = $status;
        }
        
        if ($owner) {
            $filters['user_ids'] = [(int)$owner];
        }
        
        // Get applications
        $applications = $this->appModel->getAll($filters, 5000);
        
        // Calculate summary
        $summary = [
            'total' => count($applications),
            'by_status' => [],
            'by_owner' => [],
        ];
        
        foreach ($applications as $app) {
            // By status
            $status = $app['status'];
            $summary['by_status'][$status] = ($summary['by_status'][$status] ?? 0) + 1;
            
            // By owner
            $ownerId = $app['user_id'];
            $ownerName = $app['partner_name'];
            if (!isset($summary['by_owner'][$ownerId])) {
                $summary['by_owner'][$ownerId] = [
                    'name' => $ownerName,
                    'count' => 0,
                ];
            }
            $summary['by_owner'][$ownerId]['count']++;
        }
        
        // Sort by owner count
        uasort($summary['by_owner'], fn($a, $b) => $b['count'] <=> $a['count']);
        $summary['by_owner'] = array_slice($summary['by_owner'], 0, 10, true);
        
        // Get users for filter dropdown
        $users = $this->auth->isAdminOrSuper() ? $this->userModel->getAll() : [];
        
        include __DIR__ . '/../views/reports/index.php';
    }
    
    /**
     * Export report
     */
    public function export(): void {
        $this->requireAuth();
        
        if (!$this->auth->isAdminOrSuper()) {
            redirect('?page=reports');
        }
        
        $user = $this->auth->getCurrentUser();
        
        // Get filter parameters
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $status = $_GET['status'] ?? '';
        $owner = $_GET['owner'] ?? '';
        $format = $_GET['format'] ?? 'csv'; // csv or xlsx
        
        $filters = [
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
        ];
        
        if ($status) {
            $filters['status'] = $status;
        }
        
        if ($owner) {
            $filters['user_ids'] = [(int)$owner];
        }
        
        $applications = $this->appModel->getAll($filters, 5000);
        
        // Generate filename
        $filename = 'applications_export_' . date('Y-m-d') . '.' . $format;
        
        if ($format === 'csv') {
            $this->exportCsv($applications, $filename);
        } else {
            // XLSX export would require PhpSpreadsheet
            // For now, fallback to CSV
            $this->exportCsv($applications, str_replace('.xlsx', '.csv', $filename));
        }
    }
    
    /**
     * API: Get report data
     */
    public function apiData(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [];
        
        if (!$this->auth->isAdminOrSuper()) {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $filters = [
            'user_ids' => $userIds,
            'date_from' => $dateFrom,
            'date_to' => $dateTo,
        ];
        
        $applications = $this->appModel->getAll($filters, 5000);
        
        // Calculate summary
        $summary = [
            'total' => count($applications),
            'by_status' => [],
            'by_owner' => [],
        ];
        
        foreach ($applications as $app) {
            $status = $app['status'];
            $summary['by_status'][$status] = ($summary['by_status'][$status] ?? 0) + 1;
            
            $ownerId = $app['user_id'];
            if (!isset($summary['by_owner'][$ownerId])) {
                $summary['by_owner'][$ownerId] = [
                    'name' => $app['partner_name'],
                    'count' => 0,
                ];
            }
            $summary['by_owner'][$ownerId]['count']++;
        }
        
        json_success([
            'applications' => $applications,
            'summary' => $summary,
        ]);
    }
    
    /**
     * API: Get statistics
     */
    public function apiStats(): void {
        $this->requireAuth();
        
        $user = $this->auth->getCurrentUser();
        $userIds = [$user['id']];
        
        if ($this->auth->isAdminOrSuper()) {
            $userIds = [];
        } else {
            $userIds = $this->userModel->getDownlineIds($user['id']);
        }
        
        $stats = $this->appModel->getStats($userIds);
        $dailyStats = $this->appModel->getDailyStats(30, $userIds);
        $monthlyStats = $this->appModel->getMonthlyStats(12, $userIds);
        $partnerStats = $this->appModel->getPartnerStats(10, $userIds);
        
        json_success([
            'stats' => $stats,
            'daily' => $dailyStats,
            'monthly' => $monthlyStats,
            'by_partner' => $partnerStats,
        ]);
    }
    
    /**
     * Export to CSV
     * @param array $applications
     * @param string $filename
     */
    private function exportCsv(array $applications, string $filename): void {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $output = fopen('php://output', 'w');
        
        // BOM for UTF-8
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
        
        // Get custom fields
        $customFields = $this->getCustomFields();
        
        // Headers
        $headers = [
            'ID', 'Ημερομηνία', 'Ιδιοκτήτης', 'ID Ιδιοκτήτη', 'Τύπος Αίτησης',
            'Επώνυμο', 'Όνομα', 'Όνομα Πατρός', 'ΑΦΜ', 'ΑΔΤ', 'ΔΟΥ', 'Ημ. Γέννησης',
            'Εταιρεία', 'ΑΦΜ Εταιρείας',
            'Σταθερό', 'Κινητό', 'Email',
            'Διεύθυνση Εγκατάστασης', 'Διεύθυνση Χρέωσης',
            'Πρόγραμμα Σταθερού', 'Πρόγραμμα Κινητού', 'Τιμή',
            'Κατάσταση', 'Ημ. Ενεργοποίησης', 'Σημειώσεις'
        ];
        
        // Add custom field headers
        foreach ($customFields as $field) {
            $headers[] = $field['field_label'];
        }
        
        fputcsv($output, $headers);
        
        // Data
        foreach ($applications as $app) {
            $row = [
                $app['id'],
                $app['created_at'],
                $app['partner_name'],
                $app['user_id'],
                $app['request_type'],
                $app['last_name'],
                $app['first_name'],
                $app['father_name'],
                $app['afm'],
                $app['adt'],
                $app['dou'],
                $app['date_of_birth'],
                $app['company'],
                $app['company_afm'],
                $app['landline_phone'],
                $app['mobile_phone'],
                $app['email'],
                $app['install_address'],
                $app['billing_address'],
                $app['landline_program'],
                $app['mobile_program'],
                $app['price'],
                $app['status'],
                $app['activated_at'],
                $app['notes'],
            ];
            
            // Add custom field values
            foreach ($customFields as $field) {
                $row[] = $app[$field['field_name']] ?? '';
            }
            
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Get active custom fields
     * @return array
     */
    private function getCustomFields(): array {
        try {
            return Database::fetchAll(
                "SELECT field_name, field_label FROM custom_fields WHERE is_active = 1 ORDER BY display_order"
            );
        } catch (Throwable $e) {
            return [];
        }
    }
    
    /**
     * Require authentication
     */
    private function requireAuth(): void {
        if (!$this->auth->isLoggedIn()) {
            redirect('?page=login');
        }
        
        if ($this->auth->needsUsernameSetup()) {
            redirect('?page=set-username');
        }
    }
}
