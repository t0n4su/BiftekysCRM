/**
 * Charts initialization for statistics
 */

(function() {
    'use strict';

    // Default chart options
    Chart.defaults.font.family = "'Segoe UI', 'Helvetica Neue', Arial, sans-serif";
    Chart.defaults.color = '#666';
    Chart.defaults.scale.grid.color = '#e9ecef';

    /**
     * Initialize a doughnut chart
     * @param {string} canvasId
     * @param {Object} data
     * @param {Array} colors
     */
    window.initDoughnutChart = function(canvasId, data, colors) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        return new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(data),
                datasets: [{
                    data: Object.values(data),
                    backgroundColor: colors || [
                        '#3498db', '#2ecc71', '#f39c12', '#e74c3c', '#9b59b6', '#1abc9c'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    };

    /**
     * Initialize a line chart
     * @param {string} canvasId
     * @param {Array} labels
     * @param {Array} data
     * @param {string} label
     * @param {string} color
     */
    window.initLineChart = function(canvasId, labels, data, label, color) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        return new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: label || 'Αιτήσεις',
                    data: data,
                    borderColor: color || '#3498db',
                    backgroundColor: (color || '#3498db') + '20',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            precision: 0
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    };

    /**
     * Initialize a bar chart
     * @param {string} canvasId
     * @param {Array} labels
     * @param {Array} data
     * @param {string} label
     * @param {string} color
     */
    window.initBarChart = function(canvasId, labels, data, label, color) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        return new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: label || 'Αιτήσεις',
                    data: data,
                    backgroundColor: color || '#2ecc71',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            precision: 0
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    };

    /**
     * Initialize a horizontal bar chart
     * @param {string} canvasId
     * @param {Array} labels
     * @param {Array} data
     * @param {string} label
     * @param {string} color
     */
    window.initHorizontalBarChart = function(canvasId, labels, data, label, color) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        return new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: label || 'Αιτήσεις',
                    data: data,
                    backgroundColor: color || '#9b59b6',
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            precision: 0
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    };

    /**
     * Fetch and display stats
     * @param {string} endpoint
     * @param {Function} callback
     */
    window.fetchStats = function(endpoint, callback) {
        fetch(endpoint)
            .then(response => response.json())
            .then(data => {
                if (data.success && callback) {
                    callback(data);
                }
            })
            .catch(error => {
                console.error('Failed to fetch stats:', error);
            });
    };
})();
