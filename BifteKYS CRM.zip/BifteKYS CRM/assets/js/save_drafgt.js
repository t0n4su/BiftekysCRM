/**
 * Autosave Draft functionality
 * Automatically saves form data every 60 seconds
 */
(function() {
    'use strict';

    const form = document.getElementById('application-form');
    const indicator = document.getElementById('draft-indicator');
    const AUTOSAVE_INTERVAL = 60000; // 60 seconds
    const DRAFT_KEY = 'application_draft';

    if (!form) return;

    let autosaveTimer = null;
    let lastSaved = null;

    // Start autosave on page load
    initAutosave();

    function initAutosave() {
        // Load saved draft if exists
        loadDraft();

        // Start autosave timer
        startAutosave();

        // Save on form change (debounced)
        let changeTimer;
        form.addEventListener('change', function() {
            clearTimeout(changeTimer);
            changeTimer = setTimeout(() => saveDraft(true), 1000);
        });

        // Clear draft on successful submit
        form.addEventListener('submit', function() {
            clearDraft();
        });
    }

    function startAutosave() {
        if (autosaveTimer) {
            clearInterval(autosaveTimer);
        }
        autosaveTimer = setInterval(() => saveDraft(true), AUTOSAVE_INTERVAL);
    }

    window.saveDraft = function(silent = false) {
        const formData = new FormData(form);
        const data = {};

        // Convert FormData to object
        for (const [key, value] of formData.entries()) {
            // Skip CSRF token and empty values
            if (key === 'csrf_token') continue;
            if (value === '') continue;

            // Handle multi-value fields
            if (data[key]) {
                if (!Array.isArray(data[key])) {
                    data[key] = [data[key]];
                }
                data[key].push(value);
            } else {
                data[key] = value;
            }
        }

        // Add metadata
        data._draft_meta = {
            saved_at: new Date().toISOString(),
            url: window.location.href
        };

        // Save to localStorage
        try {
            localStorage.setItem(DRAFT_KEY, JSON.stringify(data));
            lastSaved = new Date();

            if (!silent) {
                showIndicator('Draft αποθηκεύτηκε');
            }

            // Also try to save to server if we have an API endpoint
            saveToServer(data);

            return true;
        } catch (e) {
            console.error('Failed to save draft:', e);
            if (!silent) {
                showIndicator('Σφάλμα αποθήκευσης', 'error');
            }
            return false;
        }
    }; 

    function saveToServer(data) {
        // Διορθωμένο URL για το API
        fetch('?api=applications/save-draft', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('input[name="csrf_token"]')?.value || ''
            },
            body: JSON.stringify(data)
        }).catch(err => {
            console.log('Server draft save failed:', err);
        });
    }

    function loadDraft() {
        try {
            const saved = localStorage.getItem(DRAFT_KEY);
            if (!saved) return;

            const data = JSON.parse(saved);

            // Check if draft is for current page
            if (data._draft_meta && data._draft_meta.url) {
                const draftUrl = new URL(data._draft_meta.url);
                const currentUrl = new URL(window.location.href);

                // Only load if same page type (create or edit)
                if (draftUrl.searchParams.get('page') !== currentUrl.searchParams.get('page') ||
                    draftUrl.searchParams.get('action') !== currentUrl.searchParams.get('action')) {
                    return;
                }
            }

            // Ask user if they want to restore
            const savedDate = data._draft_meta ? new Date(data._draft_meta.saved_at) : null;
            const savedTime = savedDate ? savedDate.toLocaleString('el-GR') : 'προηγουμένως';

            if (confirm(`Υπάρχει αποθηκευμένο draft (${savedTime}). Θέλετε να το φορτώσετε;\n\n(Αν πατήσετε 'Ακύρωση', το draft θα διαγραφεί οριστικά.)`)) {
                restoreDraft(data);
            } else {
                clearDraft();
                console.log("Το παλιό draft διαγράφηκε.");
            }
        } catch (e) {
            console.error('Failed to load draft:', e);
        }
    }

    function restoreDraft(data) {
        for (const [key, value] of Object.entries(data)) {
            if (key.startsWith('_')) continue; // Skip metadata

            const input = form.querySelector(`[name="${key}"]`);
            if (!input) continue;

            if (input.type === 'checkbox') {
                input.checked = Boolean(value);
            } else if (input.type === 'radio') {
                const radio = form.querySelector(`[name="${key}"][value="${value}"]`);
                if (radio) radio.checked = true;
            } else if (input.tagName === 'SELECT' && input.multiple && Array.isArray(value)) {
                Array.from(input.options).forEach(opt => {
                    opt.selected = value.includes(opt.value);
                });
            } else {
                input.value = value;
            }
        }

        showIndicator('Draft φορτώθηκε');
    }

    function clearDraft() {
        try {
            localStorage.removeItem(DRAFT_KEY);
        } catch (e) {
            console.error('Failed to clear draft:', e);
        }
    }

    function showIndicator(message, type = 'success') {
        if (!indicator) return;

        indicator.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle"></i> ${message}`;
        indicator.className = 'draft-indicator draft-' + type;
        indicator.style.display = 'block';

        setTimeout(() => {
            indicator.style.display = 'none';
        }, 3000);
    }

    // Expose clearDraft globally
    window.clearDraft = clearDraft;

})();