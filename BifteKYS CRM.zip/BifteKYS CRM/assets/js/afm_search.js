/**
 * AFM Search functionality
 * Searches for customers by AFM and auto-fills form fields
 */
(function () {
  'use strict';

  const afmSearchInput = document.getElementById('afm_search');
  const resultDiv = document.getElementById('afm-search-result');

  if (!afmSearchInput) return;

  afmSearchInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      window.searchByAfm();
    }
  });

  afmSearchInput.addEventListener('input', function () {
    this.value = this.value.replace(/[^0-9]/g, '');
  });

  window.searchByAfm = async function () {
    const afm = (afmSearchInput.value || '').trim();

    if (afm.length !== 9) return showResult('error', 'Το ΑΦΜ πρέπει να έχει ακριβώς 9 ψηφία');
    if (!validateAFM(afm)) return showResult('error', 'Μη έγκυρο ΑΦΜ');

    showResult('loading', 'Αναζήτηση...');

    // Router expects ?api=customers/search-afm (from index.php handleApiRequest)
    const url = new URL(window.location.href);
    url.searchParams.set('api', 'customers/search-afm');
    url.searchParams.set('afm', afm);

    try {
      const response = await fetch(url.toString(), {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });

      const contentType = response.headers.get('content-type') || '';

      if (!response.ok) {
        const text = await response.text().catch(() => '');
        throw new Error(`HTTP ${response.status} ${response.statusText} ${text ? ('- ' + text.slice(0, 200)) : ''}`);
      }

      if (!contentType.includes('application/json')) {
        const text = await response.text().catch(() => '');
        throw new Error(`Expected JSON, got ${contentType || 'unknown'} ${text ? ('- ' + text.slice(0, 200)) : ''}`);
      }

      const data = await response.json();

      if (data.success && data.found && data.customer) {
        // Fill form (IDs match API fields in your original map)
        fillForm(data.customer);

        // Also set the main AFM field (if empty)
        const mainAfm = document.getElementById('afm');
        if (mainAfm && !mainAfm.value) mainAfm.value = afm;

        showResult('success', 'Στοιχεία πελάτη φορτώθηκαν αυτόματα.');

        if ((data.application_count || 0) > 0) {
          showApplicationCount(data.application_count, afm);
        }
      } else {
        showResult('info', 'Δεν βρέθηκε πελάτης με αυτό το ΑΦΜ.');
      }
    } catch (err) {
      console.error('AFM search error:', err);
      showResult('error', 'Σφάλμα κατά την αναζήτηση (δες Console/Network)');
    }
  };

  function validateAFM(afm) {
    if (!/^\d{9}$/.test(afm)) return false;
    if (afm === '000000000') return false;

    let sum = 0;
    for (let i = 0; i < 8; i++) sum += parseInt(afm[i], 10) * Math.pow(2, 8 - i);
    let checksum = sum % 11;
    if (checksum === 10) checksum = 0;

    return checksum === parseInt(afm[8], 10);
  }

  function fillForm(customer) {
    const fieldMap = {
      last_name: 'last_name',
      first_name: 'first_name',
      father_name: 'father_name',
      afm: 'afm',
      adt: 'adt',
      dou: 'dou',
      date_of_birth: 'date_of_birth',
      company: 'company',
      company_afm: 'company_afm',
      landline_phone: 'landline_phone',
      mobile_phone: 'mobile_phone',
      email: 'email',
      install_address: 'install_address',
      billing_address: 'billing_address'
    };

    for (const [formId, apiField] of Object.entries(fieldMap)) {
      const el = document.getElementById(formId);
      const val = customer?.[apiField];
      if (el && val != null && val !== '') {
        el.value = val;
        el.classList.add('auto-filled');
        setTimeout(() => el.classList.remove('auto-filled'), 1500);
      }
    }
  }

  function showResult(type, message) {
    if (!resultDiv) return;

    const icons = {
      success: 'check-circle',
      error: 'exclamation-circle',
      info: 'info-circle',
      loading: 'spinner fa-spin'
    };

    resultDiv.innerHTML = `
      <div class="alert alert-${type}">
        <i class="fas fa-${icons[type] || 'info-circle'}"></i>
        ${message}
        ${type !== 'loading' ? '<button type="button" class="close" onclick="this.parentElement.remove()">&times;</button>' : ''}
      </div>
    `;
    resultDiv.style.display = 'block';
  }

  function showApplicationCount(count, afm) {
    if (!resultDiv) return;
    const div = document.createElement('div');
    div.className = 'alert alert-info';
    div.innerHTML = `
      <i class="fas fa-history"></i>
      Ο πελάτης έχει <strong>${count}</strong> προηγούμενες αιτήσεις.
      <a href="?page=applications&search=${encodeURIComponent(afm)}" class="alert-link">Προβολή αιτήσεων</a>
      <button type="button" class="close" onclick="this.parentElement.remove()">&times;</button>
    `;
    resultDiv.appendChild(div);
  }
})();