/**
 * Field Builder functionality
 * Dynamic field management for superadmin
 */

(function() {
    'use strict';

    const modal = document.getElementById('fieldModal');
    const form = document.getElementById('fieldForm');
    const optionsGroup = document.getElementById('optionsGroup');
    const optionsList = document.getElementById('optionsList');

    let currentFieldId = null;

    // Expose functions globally
    window.openModal = function(fieldId = null) {
        currentFieldId = fieldId;
        
        if (fieldId) {
            document.getElementById('modalTitle').textContent = 'Επεξεργασία Πεδίου';
            loadFieldData(fieldId);
        } else {
            document.getElementById('modalTitle').textContent = 'Νέο Πεδίο';
            form.reset();
            document.getElementById('field_id').value = '';
            optionsList.innerHTML = `
                <div class="option-row">
                    <input type="text" name="options[]" class="form-control" placeholder="Τιμή επιλογής">
                </div>
            `;
        }
        
        toggleOptions();
        modal.style.display = 'flex';
    };

    window.closeModal = function() {
        modal.style.display = 'none';
        currentFieldId = null;
    };

    window.toggleOptions = function() {
        const fieldType = document.getElementById('field_type').value;
        const needsOptions = ['dropdown', 'radio'].includes(fieldType);
        optionsGroup.style.display = needsOptions ? 'block' : 'none';
    };

    window.addOption = function() {
        const row = document.createElement('div');
        row.className = 'option-row';
        row.innerHTML = `
            <div class="input-group">
                <input type="text" name="options[]" class="form-control" placeholder="Τιμή επιλογής">
                <button type="button" class="btn btn-danger" onclick="this.closest('.option-row').remove()">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        optionsList.appendChild(row);
    };

    window.saveField = function(event) {
        event.preventDefault();

        const formData = new FormData(form);
        const data = {
            id: currentFieldId,
            field_label: formData.get('field_label'),
            field_name: formData.get('field_name'),
            field_type: formData.get('field_type'),
            display_order: parseInt(formData.get('display_order')) || 0,
            is_required: formData.has('is_required'),
            options: []
        };

        // Collect options
        const optionInputs = form.querySelectorAll('input[name="options[]"]');
        optionInputs.forEach(input => {
            if (input.value.trim()) {
                data.options.push(input.value.trim());
            }
        });

        // Validate
        if (!data.field_label || !data.field_name) {
            alert('Συμπληρώστε όλα τα υποχρεωτικά πεδία');
            return;
        }

        // Validate field name format
        if (!/^[a-zA-Z][a-zA-Z0-9_]*$/.test(data.field_name)) {
            alert('Μη έγκυρο όνομα στήλης');
            return;
        }

        // Send to API
        fetch('api/fields/save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('input[name="csrf_token"]')?.value || ''
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                closeModal();
                location.reload();
            } else {
                alert(result.message || 'Σφάλμα αποθήκευσης');
            }
        })
        .catch(error => {
            console.error('Save field error:', error);
            alert('Σφάλμα επικοινωνίας με τον server');
        });
    };

    window.editField = function(fieldId) {
        openModal(fieldId);
    };

    window.toggleField = function(fieldId, active, force = false) {
        const action = active ? 'ενεργοποίηση' : 'απενεργοποίηση';
        
        if (!force && !confirm(`Είστε σίγουροι ότι θέλετε να ${action}τε αυτό το πεδίο;`)) {
            return;
        }

        fetch('api/fields/toggle', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': document.querySelector('input[name="csrf_token"]')?.value || ''
            },
            body: JSON.stringify({ id: fieldId, active: active, force: force })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                location.reload();
            } else if (result.confirm_required) {
                // Field has data, ask for confirmation
                if (confirm(result.message + '\n\nΘέλετε να συνεχίσετε;')) {
                    toggleField(fieldId, active, true);
                }
            } else {
                alert(result.message || 'Σφάλμα');
            }
        })
        .catch(error => {
            console.error('Toggle field error:', error);
            alert('Σφάλμα επικοινωνίας');
        });
    };

    function loadFieldData(fieldId) {
        // Get field data from table row
        const row = document.querySelector(`tr[data-field-id="${fieldId}"]`);
        if (!row) return;

        const cells = row.querySelectorAll('td');
        
        document.getElementById('field_id').value = fieldId;
        document.getElementById('field_label').value = cells[1].textContent.trim();
        document.getElementById('field_name').value = cells[2].textContent.trim();
        document.getElementById('field_type').value = getFieldTypeFromLabel(cells[3].textContent.trim());
        document.getElementById('display_order').value = cells[0].textContent.trim();
        document.getElementById('is_required').checked = cells[4].textContent.includes('Ναι');

        // Load options if dropdown/radio
        toggleOptions();
    }

    function getFieldTypeFromLabel(label) {
        const typeMap = {
            'Text': 'text',
            'Number': 'number',
            'Email': 'email',
            'Date': 'date',
            'Textarea': 'textarea',
            'Dropdown': 'dropdown',
            'Checkbox': 'checkbox',
            'Radio': 'radio',
            'File': 'file'
        };
        return typeMap[label] || 'text';
    }

    // Close modal on outside click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Auto-generate field name from label
    document.getElementById('field_label').addEventListener('blur', function() {
        const fieldNameInput = document.getElementById('field_name');
        if (!fieldNameInput.value && this.value) {
            fieldNameInput.value = this.value
                .toLowerCase()
                .replace(/[^a-z0-9\s]/g, '')
                .replace(/\s+/g, '_')
                .replace(/^_+|_+$/g, '');
        }
    });
})();
