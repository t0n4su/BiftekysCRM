/**
 * Main JavaScript file
 * Common functionality for all pages
 */

(function() {
    'use strict';

    // Initialize on DOM ready
    document.addEventListener('DOMContentLoaded', function() {
        initNavigation();
        initAlerts();
        initConfirmations();
    });

    /**
     * Initialize navigation
     */
    function initNavigation() {
        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const sidebar = document.querySelector('.sidebar');

        if (menuToggle && sidebar) {
            menuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
            });
        }

        // Close sidebar on outside click (mobile)
        document.addEventListener('click', function(e) {
            if (sidebar && sidebar.classList.contains('open')) {
                if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
                    sidebar.classList.remove('open');
                }
            }
        });
    }

    /**
     * Initialize alert dismissals
     */
    function initAlerts() {
        const alerts = document.querySelectorAll('.alert');

        alerts.forEach(function(alert) {
            // Auto-dismiss after 5 seconds
            if (!alert.classList.contains('alert-persistent')) {
                setTimeout(function() {
                    fadeOut(alert);
                }, 5000);
            }

            // Close button
            const closeBtn = alert.querySelector('.close');
            if (closeBtn) {
                closeBtn.addEventListener('click', function() {
                    fadeOut(alert);
                });
            }
        });
    }

    /**
     * Initialize confirmation dialogs
     */
    function initConfirmations() {
        document.querySelectorAll('[data-confirm]').forEach(function(el) {
            el.addEventListener('click', function(e) {
                const message = this.getAttribute('data-confirm');
                if (!confirm(message)) {
                    e.preventDefault();
                    return false;
                }
            });
        });
    }

    /**
     * Fade out element
     * @param {HTMLElement} element
     */
    function fadeOut(element) {
        element.style.opacity = '1';
        element.style.transition = 'opacity 0.3s ease';
        element.style.opacity = '0';

        setTimeout(function() {
            element.style.display = 'none';
        }, 300);
    }

    /**
     * Show loading spinner
     * @param {HTMLElement} element
     */
    window.showLoading = function(element) {
        if (!element) return;

        const originalContent = element.innerHTML;
        element.setAttribute('data-original-content', originalContent);
        element.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Φόρτωση...';
        element.disabled = true;
    };

    /**
     * Hide loading spinner
     * @param {HTMLElement} element
     */
    window.hideLoading = function(element) {
        if (!element) return;

        const originalContent = element.getAttribute('data-original-content');
        if (originalContent) {
            element.innerHTML = originalContent;
        }
        element.disabled = false;
    };

    /**
     * Format number with Greek locale
     * @param {number} num
     * @returns {string}
     */
    window.formatNumber = function(num) {
        return new Intl.NumberFormat('el-GR').format(num);
    };

    /**
     * Format date with Greek locale
     * @param {string} dateStr
     * @returns {string}
     */
    window.formatDate = function(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('el-GR');
    };

    /**
     * Format datetime with Greek locale
     * @param {string} dateStr
     * @returns {string}
     */
    window.formatDateTime = function(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleString('el-GR');
    };

    /**
     * Debounce function
     * @param {Function} func
     * @param {number} wait
     * @returns {Function}
     */
    window.debounce = function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    };

    /**
     * Throttle function
     * @param {Function} func
     * @param {number} limit
     * @returns {Function}
     */
    window.throttle = function(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    };

    /**
     * Copy text to clipboard
     * @param {string} text
     * @returns {Promise<boolean>}
     */
    window.copyToClipboard = async function(text) {
        try {
            await navigator.clipboard.writeText(text);
            return true;
        } catch (err) {
            console.error('Failed to copy:', err);
            return false;
        }
    };

    /**
     * Show toast notification
     * @param {string} message
     * @param {string} type
     * @param {number} duration
     */
    window.showToast = function(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;

        document.body.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });

        // Remove after duration
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    };
})();
