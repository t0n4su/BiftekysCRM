<?php
$title = 'Σύνδεση - BiftekysCRM';
?>
<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <i class="fas fa-network-wired"></i>
                <h1>BiftekysCRM</h1>
                <p>Σύστημα Διαχείρισης Μπιφτεκιών</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= e($error) ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" action="?page=login" class="login-form">
                <?= csrfField() ?>
                
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username
                    </label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           class="form-control" 
                           placeholder="Εισάγετε username"
                           required
                           autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Κωδικός Πρόσβασης
                    </label>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           class="form-control" 
                           placeholder="Εισάγετε κωδικό"
                           required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-sign-in-alt"></i> Σύνδεση
                </button>
            </form>
            
            <div class="login-footer">
                <p>&copy; <?= date('Y') ?> Ιωαννίδης Μενέλαος</p>
            </div>
        </div>
    </div>
</body>
</html>
