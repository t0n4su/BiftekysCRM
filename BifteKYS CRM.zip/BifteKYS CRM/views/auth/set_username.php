<?php
/**
 * Set Username View
 */

$title = 'Ορισμός Username - CleverPartnersCRM';
?>
<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <i class="fas fa-user-plus"></i>
                <h1>Ορισμός Username</h1>
                <p>Παρακαλώ ορίστε ένα username για τον λογαριασμό σας</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= e($error) ?>
            </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= e($success) ?>
                <p>Ανακατεύθυνση στο dashboard...</p>
            </div>
            <?php else: ?>
            <form method="POST" action="?page=set-username" class="login-form">
                <?= csrfField() ?>
                
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username
                    </label>
                    <input type="text" 
                           id="username" 
                           name="username" 
                           class="form-control" 
                           placeholder="Επιλέξτε username (3-60 χαρακτήρες)"
                           minlength="3"
                           maxlength="60"
                           pattern="[a-zA-Z0-9_]+"
                           required
                           autofocus>
                    <small class="form-text">
                        <i class="fas fa-info-circle"></i>
                        Μόνο γράμματα, αριθμοί και κάτω παύλες (_)
                    </small>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fas fa-save"></i> Αποθήκευση
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
