<?php
/**
 * Application Form View (Create/Edit)
 */

$isEdit = isset($app);
$title = ($isEdit ? 'Επεξεργασία' : 'Νέα') . ' Αίτηση - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';

// Load constants
require_once __DIR__ . '/../../config/constants.php';
global $REQUEST_TYPES, $LANDLINE_PROGRAMS, $MOBILE_PROGRAMS;
?>

<div class="page-header">
    <h1>
        <i class="fas fa-<?= $isEdit ? 'edit' : 'plus-circle' ?>"></i>
        <?= $isEdit ? 'Επεξεργασία Αίτησης #' . $app['id'] : 'Νέα Αίτηση' ?>
    </h1>
    <div class="page-actions">
        <a href="?page=applications" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Επιστροφή
        </a>
    </div>
</div>

<?php if (!empty($errors['general'])): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i>
    <?= e($errors['general']) ?>
</div>
<?php endif; ?>

<!-- AFM Search Bar -->
<div class="afm-search-bar">
    <div class="form-group">
        <label for="afm_search">
            <i class="fas fa-search"></i> Αναζήτηση με ΑΦΜ
        </label>
        <div class="input-group">
            <input type="text" 
                   id="afm_search" 
                   class="form-control" 
                   placeholder="Εισάγετε 9-ψήφιο ΑΦΜ"
                   maxlength="9"
                   pattern="[0-9]{9}">
            <button type="button" class="btn btn-primary" onclick="searchByAfm()">
                <i class="fas fa-search"></i> Αναζήτηση
            </button>
        </div>
        <small class="form-text text-muted">
            Αναζητήστε υπάρχοντα πελάτη για αυτόματη συμπλήρωση στοιχείων
        </small>
    </div>
    <div id="afm-search-result"></div>
</div>

<form method="POST" action="" class="application-form" id="application-form" enctype="multipart/form-data">
    <?= csrfField() ?>
    
    <div class="form-sections">
        <!-- Personal Information -->
        <div class="form-section">
            <h3><i class="fas fa-user"></i> Προσωπικά Στοιχεία</h3>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="last_name">Επώνυμο *</label>
                    <input type="text" 
                           id="last_name" 
                           name="last_name" 
                           class="form-control <?= isset($errors['last_name']) ? 'is-invalid' : '' ?>"
                           value="<?= e($data['last_name'] ?? $app['last_name'] ?? '') ?>"
                           required>
                    <?php if (isset($errors['last_name'])): ?>
                    <div class="invalid-feedback"><?= e($errors['last_name'][0]) ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group col-6">
                    <label for="first_name">Όνομα *</label>
                    <input type="text" 
                           id="first_name" 
                           name="first_name" 
                           class="form-control <?= isset($errors['first_name']) ? 'is-invalid' : '' ?>"
                           value="<?= e($data['first_name'] ?? $app['first_name'] ?? '') ?>"
                           required>
                    <?php if (isset($errors['first_name'])): ?>
                    <div class="invalid-feedback"><?= e($errors['first_name'][0]) ?></div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="father_name">Όνομα Πατρός</label>
                    <input type="text" 
                           id="father_name" 
                           name="father_name" 
                           class="form-control"
                           value="<?= e($data['father_name'] ?? $app['father_name'] ?? '') ?>">
                </div>
                
                <div class="form-group col-6">
                    <label for="date_of_birth">Ημερομηνία Γέννησης</label>
                    <input type="date" 
                           id="date_of_birth" 
                           name="date_of_birth" 
                           class="form-control"
                           value="<?= e($data['date_of_birth'] ?? $app['date_of_birth'] ?? '') ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-4">
                    <label for="afm">ΑΦΜ *</label>
                    <input type="text" 
                           id="afm" 
                           name="afm" 
                           class="form-control <?= isset($errors['afm']) ? 'is-invalid' : '' ?>"
                           value="<?= e($data['afm'] ?? $app['afm'] ?? '') ?>"
                           maxlength="9"
                           pattern="[0-9]{9}"
                           required>
                    <?php if (isset($errors['afm'])): ?>
                    <div class="invalid-feedback"><?= e($errors['afm'][0]) ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group col-4">
                    <label for="adt">Αριθμός Ταυτότητας</label>
                    <input type="text" 
                           id="adt" 
                           name="adt" 
                           class="form-control"
                           value="<?= e($data['adt'] ?? $app['adt'] ?? '') ?>">
                </div>
                
                <div class="form-group col-4">
                    <label for="dou">ΔΟΥ</label>
                    <input type="text" 
                           id="dou" 
                           name="dou" 
                           class="form-control"
                           value="<?= e($data['dou'] ?? $app['dou'] ?? '') ?>">
                </div>
            </div>
        </div>
        
        <!-- Company Information -->
        <div class="form-section">
            <h3><i class="fas fa-building"></i> Στοιχεία Εταιρείας</h3>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="company">Επωνυμία Εταιρείας</label>
                    <input type="text" 
                           id="company" 
                           name="company" 
                           class="form-control"
                           value="<?= e($data['company'] ?? $app['company'] ?? '') ?>">
                </div>
                
                <div class="form-group col-6">
                    <label for="company_afm">ΑΦΜ Εταιρείας</label>
                    <input type="text" 
                           id="company_afm" 
                           name="company_afm" 
                           class="form-control"
                           value="<?= e($data['company_afm'] ?? $app['company_afm'] ?? '') ?>">
                </div>
            </div>
        </div>
        
        <!-- Contact Information -->
        <div class="form-section">
            <h3><i class="fas fa-phone"></i> Στοιχεία Επικοινωνίας</h3>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="landline_phone">Σταθερό Τηλέφωνο</label>
                    <input type="tel" 
                           id="landline_phone" 
                           name="landline_phone" 
                           class="form-control"
                           value="<?= e($data['landline_phone'] ?? $app['landline_phone'] ?? '') ?>">
                </div>
                
                <div class="form-group col-6">
                    <label for="mobile_phone">Κινητό Τηλέφωνο *</label>
                    <input type="tel" 
                           id="mobile_phone" 
                           name="mobile_phone" 
                           class="form-control <?= isset($errors['mobile_phone']) ? 'is-invalid' : '' ?>"
                           value="<?= e($data['mobile_phone'] ?? $app['mobile_phone'] ?? '') ?>"
                           required>
                    <?php if (isset($errors['mobile_phone'])): ?>
                    <div class="invalid-feedback"><?= e($errors['mobile_phone'][0]) ?></div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="email">Email</label>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>"
                           value="<?= e($data['email'] ?? $app['email'] ?? '') ?>">
                    <?php if (isset($errors['email'])): ?>
                    <div class="invalid-feedback"><?= e($errors['email'][0]) ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group col-6">
                    <label for="contact_date">Ημερομηνία Επικοινωνίας</label>
                    <input type="date" 
                           id="contact_date" 
                           name="contact_date" 
                           class="form-control"
                           value="<?= e($data['contact_date'] ?? $app['contact_date'] ?? date('Y-m-d')) ?>">
                </div>
            </div>
            
            <div class="form-group">
                <label for="install_address">Διεύθυνση Εγκατάστασης</label>
                <textarea id="install_address" 
                          name="install_address" 
                          class="form-control"
                          rows="2"><?= e($data['install_address'] ?? $app['install_address'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="billing_address">Διεύθυνση Χρέωσης</label>
                <textarea id="billing_address" 
                          name="billing_address" 
                          class="form-control"
                          rows="2"><?= e($data['billing_address'] ?? $app['billing_address'] ?? '') ?></textarea>
            </div>
        </div>
        
        <!-- Service Information -->
        <div class="form-section">
            <h3><i class="fas fa-network-wired"></i> Στοιχεία Υπηρεσίας</h3>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="request_type">Τύπος Αίτησης</label>
                    <select id="request_type" name="request_type" class="form-control">
                        <?php foreach ($REQUEST_TYPES as $key => $label): ?>
                        <option value="<?= e($key) ?>" 
                                <?= ($data['request_type'] ?? $app['request_type'] ?? '') === $key ? 'selected' : '' ?>>
                            <?= e($label) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group col-6">
                    <label for="application_number">Αριθμός Αίτησης</label>
                    <input type="text" 
                           id="application_number" 
                           name="application_number" 
                           class="form-control"
                           value="<?= e($data['application_number'] ?? $app['application_number'] ?? '') ?>">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="landline_program">Πρόγραμμα Σταθερού</label>
                    <select id="landline_program" name="landline_program" class="form-control">
                        <option value="">-- Επιλέξτε --</option>
                        <?php foreach ($LANDLINE_PROGRAMS as $key => $label): ?>
                        <option value="<?= e($key) ?>" 
                                <?= ($data['landline_program'] ?? $app['landline_program'] ?? '') === $key ? 'selected' : '' ?>>
                            <?= e($label) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group col-6">
                    <label for="mobile_program">Πρόγραμμα Κινητού</label>
                    <select id="mobile_program" name="mobile_program" class="form-control">
                        <option value="">-- Επιλέξτε --</option>
                        <?php foreach ($MOBILE_PROGRAMS as $key => $label): ?>
                        <option value="<?= e($key) ?>" 
                                <?= ($data['mobile_program'] ?? $app['mobile_program'] ?? '') === $key ? 'selected' : '' ?>>
                            <?= e($label) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="price">Τιμή</label>
                <input type="text" 
                       id="price" 
                       name="price" 
                       class="form-control"
                       value="<?= e($data['price'] ?? $app['price'] ?? '') ?>">
            </div>
        </div>
        
        <!-- Status & Notes -->
        <?php if ($isEdit): ?>
        <div class="form-section">
            <h3><i class="fas fa-info-circle"></i> Κατάσταση & Σημειώσεις</h3>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="status">Κατάσταση</label>
                    <select id="status" name="status" class="form-control">
                        <?php global $APPLICATION_STATUSES; foreach ($APPLICATION_STATUSES as $key => $info): ?>
                        <option value="<?= e($key) ?>" 
                                <?= ($app['status'] ?? '') === $key ? 'selected' : '' ?>>
                            <?= e($info['label']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>            
            <div class="form-group">
                <label for="notes">Σημειώσεις</label>
                <textarea id="notes" 
                          name="notes" 
                          class="form-control"
                          rows="4"><?= e($data['notes'] ?? $app['notes'] ?? '') ?></textarea>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="form-section">
            <h3><i class="fas fa-paperclip"></i> Δικαιολογητικά</h3>
            <div class="form-group">
                <label>Επισύναψη Αρχείων (Drag & Drop)</label>
                
                <div id="drop-zone" class="drop-zone">
                    <span class="drop-zone__prompt">
                        <i class="fas fa-cloud-upload-alt fa-2x"></i><br>
                        Σύρετε τα αρχεία σας εδώ ή πατήστε για επιλογή
                    </span>
                    <input type="file" name="attachments[]" id="file-input" multiple class="drop-zone__input">
                </div>

                <div id="file-preview-list" class="file-preview-list"></div>
                <?php if ($isEdit): ?>
                    <?php
                    // ΝΕΑ ΛΟΓΙΚΗ: Παίρνουμε τα αρχεία από τη Βάση Δεδομένων μέσω του Model
                    $savedFiles = $this->appModel->getApplicationFiles($app['id']);
                    if (!empty($savedFiles)):
                    ?>
                    <div class="saved-attachments mt-4">
                        <h4 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">Ανεβασμένα Δικαιολογητικά</h4>
                        <ul class="list-group" style="padding-left: 0;">
                            <?php foreach ($savedFiles as $file): ?>
                                <li class="list-group-item" style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border: 1px solid #ddd; margin-bottom: 5px; border-radius: 4px;">
                                    <span>
                                        <i class="fas fa-file-alt text-primary"></i> 
                                        <?= e($file['original_name']) ?>
                                        <small class="text-muted">(<?= number_format($file['file_size'] / 1024 / 1024, 2) ?> MB)</small>
                                    </span>
                                    
                                        <div class="btn-group">
                                            <a href="?page=applications&action=download&id=<?= $app['id'] ?>&file_id=<?= $file['id'] ?>" class="btn btn-sm btn-primary" style="margin-right: 5px;" target="_blank">
                                                <i class="fas fa-download"></i> Λήψη
                                            </a>

                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteDbAttachment(<?= $app['id'] ?>, <?= $file['id'] ?>)">
                                                <i class="fas fa-trash"></i> Διαγραφή
                                            </button>
                                        </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        
        <!-- Custom Fields -->
        <?php if (!empty($customFields)): ?>
        <div class="form-section">
            <h3><i class="fas fa-cogs"></i> Επιπλέον Πεδία</h3>
            <?php foreach ($customFields as $field): 
                $fieldValue = $data[$field['field_name']] ?? $app[$field['field_name']] ?? '';
            ?>
            <div class="form-group">
                <label for="<?= e($field['field_name']) ?>">
                    <?= e($field['field_label']) ?>
                    <?php if ($field['is_required']): ?><span class="required">*</span><?php endif; ?>
                </label>
                <?php if ($field['field_type'] === 'textarea'): ?>
                <textarea id="<?= e($field['field_name']) ?>" 
                          name="<?= e($field['field_name']) ?>" 
                          class="form-control"
                          <?= $field['is_required'] ? 'required' : '' ?>><?= e($fieldValue) ?></textarea>
                <?php elseif ($field['field_type'] === 'dropdown'): ?>
                <select id="<?= e($field['field_name']) ?>" 
                        name="<?= e($field['field_name']) ?>" 
                        class="form-control"
                        <?= $field['is_required'] ? 'required' : '' ?>>
                    <option value="">-- Επιλέξτε --</option>
                    <?php foreach ($field['options'] ?? [] as $opt): ?>
                    <option value="<?= e($opt) ?>" <?= $fieldValue === $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php else: ?>
                <input type="<?= e($field['field_type']) ?>" 
                       id="<?= e($field['field_name']) ?>" 
                       name="<?= e($field['field_name']) ?>" 
                       class="form-control"
                       value="<?= e($fieldValue) ?>"
                       <?= $field['is_required'] ? 'required' : '' ?>>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="form-actions">
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="fas fa-save"></i> 
            <?= $isEdit ? 'Αποθήκευση Αλλαγών' : 'Υποβολή Αίτησης' ?>
        </button>
        
        <button type="button" class="btn btn-secondary" onclick="saveDraft()">
            <i class="fas fa-save"></i> Αποθήκευση Draft
        </button>
        
        <a href="?page=applications" class="btn btn-link">Ακύρωση</a>
    </div>
</form>

<!-- Draft saved indicator -->
<div id="draft-indicator" class="draft-indicator" style="display: none;">
    <i class="fas fa-check-circle"></i> Draft αποθηκεύτηκε
</div>

<script src="assets/js/afm_search.js"></script>
<script src="assets/js/autosave.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const dropZoneElement = document.querySelector(".drop-zone");
    const inputElement = document.querySelector("#file-input");
    const filePreviewList = document.querySelector("#file-preview-list");
    
    // Χρησιμοποιούμε το DataTransfer για να κρατάμε τα αρχεία που θέλει ο χρήστης
    let dataTransfer = new DataTransfer();

    // Visual feedback όταν σέρνεις αρχεία από πάνω
    ['dragover', 'dragleave', 'dragend'].forEach(type => {
        dropZoneElement.addEventListener(type, e => {
            e.preventDefault();
            dropZoneElement.classList.toggle("drop-zone--over", type === "dragover");
        });
    });

    // Όταν αφήνει ο χρήστης τα αρχεία (Drop)
    dropZoneElement.addEventListener("drop", e => {
        e.preventDefault();
        dropZoneElement.classList.remove("drop-zone--over");

        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    // Όταν επιλέγει αρχεία πατώντας το πλαίσιο (Mobile & Desktop)
    inputElement.addEventListener("change", e => {
        if (inputElement.files.length) {
            handleFiles(inputElement.files);
        }
    });

    // Συνάρτηση διαχείρισης των αρχείων
    function handleFiles(files) {
        Array.from(files).forEach(file => {
            // Μπορείς να βάλεις έλεγχο μεγέθους εδώ (π.χ. file.size < 5000000 για 5MB)
            dataTransfer.items.add(file);
        });
        
        // Ανανέωση του κρυφού input με τα νέα αρχεία
        inputElement.files = dataTransfer.files;
        updateFilePreview();
    }

    // Συνάρτηση εμφάνισης των επιλεγμένων αρχείων
    function updateFilePreview() {
        filePreviewList.innerHTML = "";
        
        Array.from(dataTransfer.files).forEach((file, index) => {
            const fileItem = document.createElement("div");
            fileItem.classList.add("file-preview-item");
            
            fileItem.innerHTML = `
                <div>
                    <i class="fas fa-file"></i> 
                    <span class="file-name">${file.name}</span> 
                    <small class="text-muted">(${(file.size / 1024 / 1024).toFixed(2)} MB)</small>
                </div>
                <button type="button" class="remove-file-btn" data-index="${index}">
                    <i class="fas fa-times"></i>
                </button>
            `;
            
            filePreviewList.appendChild(fileItem);
        });

        // Προσθήκη λειτουργίας διαγραφής
        document.querySelectorAll(".remove-file-btn").forEach(btn => {
            btn.addEventListener("click", function() {
                const indexToRemove = parseInt(this.getAttribute("data-index"));
                removeFile(indexToRemove);
            });
        });
    }

    // Αφαίρεση αρχείου αν ο χρήστης αλλάξει γνώμη
    function removeFile(index) {
        const newDataTransfer = new DataTransfer();
        
        Array.from(dataTransfer.files).forEach((file, i) => {
            if (i !== index) {
                newDataTransfer.items.add(file);
            }
        });
        
        dataTransfer = newDataTransfer;
        inputElement.files = dataTransfer.files; // Ενημέρωση του input
        updateFilePreview(); // Ανανέωση λίστας
    }
});
</script>
<script>
function deleteDbAttachment(appId, fileId) {
    if (confirm('Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το δικαιολογητικό; (Η ενέργεια είναι μη αναστρέψιμη)')) {
        window.location.href = `?page=applications&action=delete_attachment&id=${appId}&file_id=${fileId}`;
    }
}
</script>

<?php 
$extraScripts = ['assets/js/afm_search.js', 'assets/js/autosave.js'];
include __DIR__ . '/../layout/footer.php'; 
?>
