<?php
/**
 * Draft Applications List View
 */

$title = 'Draft Αιτήσεων - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-file-alt"></i> Draft Αιτήσεων</h1>
    <div class="page-actions">
        <a href="?page=applications&action=create" class="btn btn-primary">
            <i class="fas fa-plus"></i> Νέα Αίτηση
        </a>
        <a href="?page=applications" class="btn btn-secondary">
            <i class="fas fa-list"></i> Όλες οι Αιτήσεις
        </a>
    </div>
</div>

<div class="drafts-container">
    <?php if (empty($drafts)): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        Δεν έχετε αποθηκευμένα drafts. 
        <a href="?page=applications&action=create">Δημιουργήστε μια νέα αίτηση</a> 
        και χρησιμοποιήστε το κουμπί "Αποθήκευση Draft" για να αποθηκεύσετε προσωρινά.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ημερομηνία Δημιουργίας</th>
                    <th>Τελευταία Ενημέρωση</th>
                    <th>Στοιχεία</th>
                    <th>Ενέργειες</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($drafts as $draft): 
                    $data = json_decode($draft['data'], true);
                    $displayName = '';
                    if (!empty($data['last_name']) || !empty($data['first_name'])) {
                        $displayName = trim(($data['last_name'] ?? '') . ' ' . ($data['first_name'] ?? ''));
                    } elseif (!empty($data['company'])) {
                        $displayName = $data['company'];
                    } else {
                        $displayName = 'Ανώνυμο Draft #' . $draft['id'];
                    }
                ?>
                <tr>
                    <td><?= $draft['id'] ?></td>
                    <td><?= format_datetime($draft['created_at']) ?></td>
                    <td><?= format_datetime($draft['updated_at']) ?></td>
                    <td>
                        <strong><?= e($displayName) ?></strong>
                        <?php if (!empty($data['afm'])): ?>
                        <br><small class="text-muted">ΑΦΜ: <?= e($data['afm']) ?></small>
                        <?php endif; ?>
                        <?php if (!empty($data['request_type'])): ?>
                        <br><small class="text-muted">Τύπος: <?= e($data['request_type']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <a href="?page=applications&action=edit-draft&id=<?= $draft['id'] ?>" 
                               class="btn btn-sm btn-primary" 
                               title="Συνέχεια Επεξεργασίας">
                                <i class="fas fa-edit"></i> Συνέχεια
                            </a>
                            <button type="button" 
                                    class="btn btn-sm btn-success" 
                                    onclick="submitDraft(<?= $draft['id'] ?>)"
                                    title="Οριστική Υποβολή">
                                <i class="fas fa-check"></i> Υποβολή
                            </button>
                            <button type="button" 
                                    class="btn btn-sm btn-danger" 
                                    onclick="deleteDraft(<?= $draft['id'] ?>)"
                                    title="Διαγραφή">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
function submitDraft(id) {
    if (!confirm('Είστε σίγουροι ότι θέλετε να υποβάλετε αυτό το draft ως οριστική αίτηση;')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('id', id);
    formData.append('csrf_token', document.querySelector('input[name="csrf_token"]')?.value || '');
    
    fetch('?api=applications/submit-draft', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message || 'Σφάλμα υποβολής');
        }
    })
    .catch(e => alert('Σφάλμα: ' + e.message));
}

function deleteDraft(id) {
    if (!confirm('Είστε σίγουροι ότι θέλετε να διαγράψετε αυτό το draft;')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('id', id);
    formData.append('csrf_token', document.querySelector('input[name="csrf_token"]')?.value || '');
    
    fetch('?api=applications/delete-draft', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message || 'Σφάλμα διαγραφής');
        }
    })
    .catch(e => alert('Σφάλμα: ' + e.message));
}
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
