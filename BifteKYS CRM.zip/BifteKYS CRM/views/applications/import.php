<?php
/**
 * Import Applications View
 */

$title = 'Εισαγωγή Αιτήσεων - BiftekysCRM';

include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-file-import"></i> Εισαγωγή Αιτήσεων</h1>
    <div class="page-actions">
        <a href="?page=applications" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Επιστροφή
        </a>
    </div>
</div>

<!-- Step 1: Upload -->
<?php if ($step === 1): ?>
<div class="form-section">
    <h3><i class="fas fa-upload"></i> Βήμα 1: Ανέβασμα Αρχείου</h3>
    
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        <strong>Οδηγίες:</strong>
        <ul>
            <li>Υποστηριζόμενες μορφές: CSV, XLSX</li>
            <li>Πρώτη γραμμή πρέπει να περιέχει τα ονόματα των στηλών</li>
            <li>Υποχρεωτικά πεδία: first_name, last_name, afm, mobile_phone</li>
            <li>Η στήλη "owner" πρέπει να περιέχει το username του συνεργάτη</li>
        </ul>
        <a href="?page=applications&action=download-template" class="btn btn-sm btn-outline-primary">
            <i class="fas fa-download"></i> Λήψη Προτύπου
        </a>
    </div>
    
    <form method="POST" action="?page=applications&action=import" enctype="multipart/form-data">
        <?= csrfField() ?>
        <input type="hidden" name="step" value="1">
        
        <div class="form-group">
            <label for="import_file">Επιλέξτε Αρχείο *</label>
            <input type="file" 
                   id="import_file" 
                   name="import_file" 
                   class="form-control"
                   accept=".csv,.xlsx"
                   required>
        </div>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-upload"></i> Ανέβασμα & Προεπισκόπηση
        </button>
    </form>
</div>
<?php endif; ?>

<!-- Step 2: Preview -->
<?php if ($step === 2 && !empty($preview)): ?>
<div class="form-section">
    <h3><i class="fas fa-eye"></i> Βήμα 2: Προεπισκόπηση & Επικύρωση</h3>
    
    <div class="alert alert-<?= $validationSummary['errors'] > 0 ? 'warning' : 'success' ?>">
        <i class="fas fa-<?= $validationSummary['errors'] > 0 ? 'exclamation-triangle' : 'check-circle' ?>"></i>
        <strong>Σύνοψη:</strong>
        Σύνολο: <?= $validationSummary['total'] ?> | 
        Έγκυρα: <?= $validationSummary['valid'] ?> | 
        Σφάλματα: <?= $validationSummary['errors'] ?>
    </div>
    
    <form method="POST" action="?page=applications&action=import">
        <?= csrfField() ?>
        <input type="hidden" name="step" value="3">
        <input type="hidden" name="temp_file" value="<?= e($tempFile) ?>">
        
        <div class="table-responsive">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Γραμμή</th>
                        <th>Κατάσταση</th>
                        <th>Επώνυμο</th>
                        <th>Όνομα</th>
                        <th>ΑΦΜ</th>
                        <th>Κινητό</th>
                        <th>Ιδιοκτήτης</th>
                        <th>Σφάλματα</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($preview as $row): ?>
                    <tr class="<?= $row['valid'] ? 'table-success' : 'table-danger' ?>">
                        <td><?= $row['row'] ?></td>
                        <td>
                            <?php if ($row['valid']): ?>
                            <span class="badge badge-success"><i class="fas fa-check"></i></span>
                            <?php else: ?>
                            <span class="badge badge-danger"><i class="fas fa-times"></i></span>
                            <?php endif; ?>
                        </td>
                        <td><?= e($row['data']['last_name'] ?? '') ?></td>
                        <td><?= e($row['data']['first_name'] ?? '') ?></td>
                        <td><?= e($row['data']['afm'] ?? '') ?></td>
                        <td><?= e($row['data']['mobile_phone'] ?? '') ?></td>
                        <td><?= e($row['data']['owner'] ?? '') ?></td>
                        <td>
                            <?php if (!empty($row['errors'])): ?>
                            <ul class="list-unstyled mb-0 text-danger">
                                <?php foreach ($row['errors'] as $error): ?>
                                <li><small><?= e($error) ?></small></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="form-actions">
            <?php if ($validationSummary['valid'] > 0): ?>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-check"></i> 
                Εισαγωγή <?= $validationSummary['valid'] ?> Εγκύρων Εγγραφών
            </button>
            <?php endif; ?>
            <a href="?page=applications&action=import" class="btn btn-secondary">
                <i class="fas fa-redo"></i> Ξεκίνημα από την Αρχή
            </a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Step 3: Results -->
<?php if ($step === 3 && !empty($importResult)): ?>
<div class="form-section">
    <h3><i class="fas fa-flag-checkered"></i> Βήμα 3: Αποτελέσματα Εισαγωγής</h3>
    
    <div class="alert alert-<?= $importResult['errors'] > 0 ? 'warning' : 'success' ?>">
        <i class="fas fa-<?= $importResult['errors'] > 0 ? 'check-double' : 'check-circle' ?>"></i>
        <strong>Η εισαγωγή ολοκληρώθηκε!</strong>
        <ul class="mb-0 mt-2">
            <li>Επιτυχής εισαγωγή: <?= $importResult['success'] ?> εγγραφές</li>
            <li>Σφάλματα: <?= $importResult['errors'] ?> εγγραφές</li>
        </ul>
    </div>
    
    <?php if (!empty($importResult['error_details'])): ?>
    <div class="alert alert-danger">
        <h5>Λεπτομέρειες Σφαλμάτων:</h5>
        <ul>
            <?php foreach ($importResult['error_details'] as $error): ?>
            <li>Γραμμή <?= $error['row'] ?>: <?= e($error['message']) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <div class="form-actions">
        <a href="?page=applications" class="btn btn-primary">
            <i class="fas fa-list"></i> Προβολή Αιτήσεων
        </a>
        <a href="?page=applications&action=import" class="btn btn-secondary">
            <i class="fas fa-plus"></i> Νέα Εισαγωγή
        </a>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../layout/footer.php'; ?>
