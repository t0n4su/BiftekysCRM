<?php
/**
 * Application Statistics View
 */

$title = 'Στατιστικά Αιτήσεων - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-chart-bar"></i> Στατιστικά Αιτήσεων</h1>
    <div class="page-actions">
        <a href="?page=applications" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Επιστροφή
        </a>
    </div>
</div>

<!-- Summary Cards -->
<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value" id="stat-total"><?= number_format($stats['total']) ?></div>
            <div class="stat-label">Σύνολο Αιτήσεων</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value" id="stat-today"><?= number_format($stats['today']) ?></div>
            <div class="stat-label">Σήμερα</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-calendar-week"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value" id="stat-week"><?= number_format($stats['week']) ?></div>
            <div class="stat-label">Τελευταία 7 Ημέρες</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #2e7d32;">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value">
                <?= $avgActivationTime !== null ? round($avgActivationTime, 1) . 'h' : 'N/A' ?>
            </div>
            <div class="stat-label">Μέσος Χρόνος Ενεργοποίησης</div>
        </div>
    </div>
</div>

<!-- Monthly Comparison -->
<div class="stats-section">
    <h3><i class="fas fa-calendar-alt"></i> Σύγκριση Μηνών</h3>
    <div class="row">
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($monthComparison['this_month']) ?></div>
                    <div class="stat-label">Τρέχων Μήνας</div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($monthComparison['last_month']) ?></div>
                    <div class="stat-label">Προηγούμενος Μήνας</div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value" style="color: <?= $monthComparison['change'] >= 0 ? '#2ecc71' : '#e74c3c' ?>">
                        <?= $monthComparison['change'] >= 0 ? '+' : '' ?><?= number_format($monthComparison['change'], 1) ?>%
                    </div>
                    <div class="stat-label">Μεταβολή</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Status Chart -->
<div class="stats-section">
    <h3><i class="fas fa-chart-pie"></i> Αιτήσεις ανά Κατάσταση</h3>
    <div class="chart-container">
        <canvas id="statusChart"></canvas>
    </div>
</div>

<!-- Daily Trend Chart -->
<div class="stats-section">
    <h3><i class="fas fa-chart-line"></i> Τάση Αιτήσεων (Τελευταίες 30 Ημέρες)</h3>
    <div class="chart-container">
        <canvas id="dailyChart"></canvas>
    </div>
</div>

<!-- Partner Stats -->
<div class="stats-section">
    <h3><i class="fas fa-users"></i> Αιτήσεις ανά Συνεργάτη (Top 10)</h3>
    <div class="chart-container">
        <canvas id="partnerChart"></canvas>
    </div>
</div>

<script>
// Status Chart
const statusData = <?= json_encode($stats['by_status']) ?>;
const statusLabels = Object.keys(statusData);
const statusValues = Object.values(statusData);

new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: statusLabels,
        datasets: [{
            data: statusValues,
            backgroundColor: [
                '#3498db',
                '#2ecc71',
                '#f39c12',
                '#e74c3c',
                '#9b59b6'
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Daily Chart
const dailyData = <?= json_encode($dailyStats) ?>;
const dailyLabels = dailyData.map(d => {
    const date = new Date(d.date);
    return date.toLocaleDateString('el-GR', { day: '2-digit', month: '2-digit' });
});
const dailyValues = dailyData.map(d => d.count);

new Chart(document.getElementById('dailyChart'), {
    type: 'line',
    data: {
        labels: dailyLabels,
        datasets: [{
            label: 'Αιτήσεις',
            data: dailyValues,
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

// Partner Chart
const partnerData = <?= json_encode($partnerStats) ?>;
const partnerLabels = partnerData.map(p => p.partner_name);
const partnerValues = partnerData.map(p => p.count);

new Chart(document.getElementById('partnerChart'), {
    type: 'bar',
    data: {
        labels: partnerLabels,
        datasets: [{
            label: 'Αιτήσεις',
            data: partnerValues,
            backgroundColor: '#2ecc71'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
