<?php
/**
 * Applications List View
 */

$title = 'Λίστα Αιτήσεων - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';

$statuses = ['ΝΕΟ', 'ΚΑΤΑΧΩΡΗΜΕΝΟ', 'ΕΚΚΡΕΜΟΤΗΤΑ', 'ΑΚΥΡΟ', 'ΕΝΕΡΓΟ'];
$currentStatus = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
?>

<div class="page-header">
    <h1><i class="fas fa-file-alt"></i> Λίστα Αιτήσεων</h1>
    <div class="page-actions">
        <a href="?page=applications&action=create" class="btn btn-primary">
            <i class="fas fa-plus"></i> Νέα Αίτηση
        </a>
        <?php if ($auth->isAdminOrSuper()): ?>
        <a href="?page=applications&action=export" class="btn btn-success">
            <i class="fas fa-file-export"></i> Εξαγωγή CSV
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="filters-bar">
    <form method="GET" class="filters-form">
        <input type="hidden" name="page" value="applications">
        
        <div class="filter-group">
            <label for="status">Κατάσταση:</label>
            <select name="status" id="status" class="form-control" onchange="this.form.submit()">
                <option value="">Όλες</option>
                <?php foreach ($statuses as $status): ?>
                <option value="<?= e($status) ?>" <?= $currentStatus === $status ? 'selected' : '' ?>>
                    <?= e($status) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="filter-group">
            <label for="search">Αναζήτηση:</label>
            <input type="text" 
                   name="search" 
                   id="search" 
                   class="form-control" 
                   placeholder="Όνομα, ΑΦΜ, Τηλέφωνο..."
                   value="<?= e($search) ?>">
        </div>
        
        <button type="submit" class="btn btn-secondary">
            <i class="fas fa-search"></i> Αναζήτηση
        </button>
        
        <?php if ($currentStatus || $search): ?>
        <a href="?page=applications" class="btn btn-link">
            <i class="fas fa-times"></i> Καθαρισμός
        </a>
        <?php endif; ?>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ημερομηνία</th>
                <th>Συνεργάτης</th>
                <th>Τύπος</th>
                <th>Πελάτης / Εταιρεία</th>
                <th>ΑΦΜ</th>
                <th>Κινητό</th>
                <th>Κατάσταση</th>
                <th>Αρχεία</th> <th>Ενέργειες</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($applications)): ?>
            <tr>
                <td colspan="11" class="text-center text-muted"> <i class="fas fa-inbox"></i> Δεν βρέθηκαν αιτήσεις
                </td>
            </tr>
            <?php else: ?>
            <?php foreach ($applications as $app): ?>
            <tr>
                <td><?= $app['id'] ?></td>
                <td><?= format_date($app['created_at']) ?></td>
                <td><?= e($app['partner_name']) ?></td>
                <td><?= e($app['request_type']) ?></td>
                <td>
                    <?php if (!empty($app['company'])): ?>
                        <strong><i class="fas fa-building text-muted"></i> <?= e($app['company']) ?></strong>
                    <?php else: ?>
                        <i class="fas fa-user text-muted"></i> <?= e($app['last_name'] . ' ' . $app['first_name']) ?>
                    <?php endif; ?>
                </td>
                <td><?= e($app['afm']) ?></td>
                <td><?= e($app['mobile_phone']) ?></td>
                <td>
                    <span class="status-badge status-<?= get_status_class($app['status']) ?>">
                        <?= e($app['status']) ?>
                    </span>
                </td>
                
                <td>
                    <?php 
                    $uploadDirList = __DIR__ . '/../../uploads/applications/' . $app['id'] . '/';
                    $hasAttachments = is_dir($uploadDirList) && count(array_diff(scandir($uploadDirList), array('..', '.'))) > 0;
                    ?>
                    <?php if ($hasAttachments): ?>
                        <span class="badge" title="Έχει επισυναπτόμενα" style="background-color: #17a2b8; color: white; padding: 5px 8px; border-radius: 4px;">
                            <i class="fas fa-paperclip"></i>
                        </span>
                    <?php else: ?>
                        <span class="text-muted">-</span>
                    <?php endif; ?>
                </td>

                <td>
                    <div class="action-buttons">
                        <a href="?page=applications&action=edit&id=<?= $app['id'] ?>" 
                           class="btn btn-sm btn-primary" 
                           title="Επεξεργασία">
                            <i class="fas fa-edit"></i>
                        </a>
                        
                        <?php if ($auth->isAdminOrSuper() || $app['user_id'] === $auth->getCurrentUserId()): ?>
                        <button type="button" 
                                class="btn btn-sm btn-danger" 
                                onclick="deleteApplication(<?= $app['id'] ?>)"
                                title="Διαγραφή">
                            <i class="fas fa-trash"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?= csrfField() ?>
<script>
function deleteApplication(id) {
  if (!confirm('Διαγραφή αίτησης;')) return;

  const formData = new FormData();
  formData.append('id', id);
  formData.append('csrf_token', document.querySelector('input[name="csrf_token"]')?.value || '');

  fetch('?api=applications/delete', {
    method: 'POST',
    body: formData
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) location.reload();
    else alert(data.message || 'Απέτυχε η διαγραφή');
  })
  .catch(e => alert(e.message));
}
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
