<?php
/**
 * Custom Fields Manager View
 */

$title = 'Διαχείριση Πεδίων - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';

$fieldTypes = [
    'text' => 'Text',
    'number' => 'Number',
    'email' => 'Email',
    'date' => 'Date',
    'textarea' => 'Textarea',
    'dropdown' => 'Dropdown',
    'checkbox' => 'Checkbox',
    'radio' => 'Radio',
    'file' => 'File',
];
?>

<div class="page-header">
    <h1><i class="fas fa-cogs"></i> Διαχείριση Πεδίων</h1>
    <div class="page-actions">
        <button type="button" class="btn btn-primary" onclick="openModal()">
            <i class="fas fa-plus"></i> Νέο Πεδίο
        </button>
    </div>
</div>

<?php if ($error): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i>
    <?= e($error) ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i>
    <?= e($success) ?>
</div>
<?php endif; ?>

<!-- Fields Table -->
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Σειρά</th>
                <th>Ετικέτα</th>
                <th>Όνομα Στήλης</th>
                <th>Τύπος</th>
                <th>Υποχρεωτικό</th>
                <th>Κατάσταση</th>
                <th>Ενέργειες</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($fields)): ?>
            <tr>
                <td colspan="7" class="text-center text-muted">
                    <i class="fas fa-inbox"></i> Δεν υπάρχουν custom πεδία
                </td>
            </tr>
            <?php else: ?>
            <?php foreach ($fields as $field): ?>
            <tr data-field-id="<?= $field['id'] ?>">
                <td><?= $field['display_order'] ?></td>
                <td><?= e($field['field_label']) ?></td>
                <td><code><?= e($field['field_name']) ?></code></td>
                <td><?= e($fieldTypes[$field['field_type']] ?? $field['field_type']) ?></td>
                <td>
                    <?php if ($field['is_required']): ?>
                    <span class="badge badge-success">Ναι</span>
                    <?php else: ?>
                    <span class="badge badge-secondary">Όχι</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($field['is_active']): ?>
                    <span class="badge badge-success">Ενεργό</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Ανενεργό</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="action-buttons">
                        <button type="button" class="btn btn-sm btn-primary" onclick="editField(<?= $field['id'] ?>)">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" 
                                class="btn btn-sm btn-<?= $field['is_active'] ? 'warning' : 'success' ?>"
                                onclick="toggleField(<?= $field['id'] ?>, <?= $field['is_active'] ? 0 : 1 ?>)">
                            <i class="fas fa-<?= $field['is_active'] ? 'ban' : 'check' ?>"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="fieldModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Νέο Πεδίο</h3>
            <button type="button" class="btn-close" onclick="closeModal()">&times;</button>
        </div>
        <form id="fieldForm" onsubmit="saveField(event)">
            <input type="hidden" id="field_id" name="id">
            
            <div class="form-group">
                <label for="field_label">Ετικέτα Πεδίου *</label>
                <input type="text" id="field_label" name="field_label" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="field_name">Όνομα Στήλης (DB) *</label>
                <input type="text" id="field_name" name="field_name" class="form-control" 
                       pattern="[a-zA-Z][a-zA-Z0-9_]*" required>
                <small class="form-text">Μόνο γράμματα, αριθμοί, κάτω παύλες. Ξεκινά με γράμμα.</small>
            </div>
            
            <div class="form-group">
                <label for="field_type">Τύπος Πεδίου *</label>
                <select id="field_type" name="field_type" class="form-control" required onchange="toggleOptions()">
                    <?php foreach ($fieldTypes as $key => $label): ?>
                    <option value="<?= e($key) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" id="optionsGroup" style="display: none;">
                <label>Επιλογές (για dropdown/radio)</label>
                <div id="optionsList">
                    <div class="option-row">
                        <input type="text" name="options[]" class="form-control" placeholder="Τιμή επιλογής">
                    </div>
                </div>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addOption()">
                    <i class="fas fa-plus"></i> Προσθήκη Επιλογής
                </button>
            </div>
            
            <div class="form-row">
                <div class="form-group col-6">
                    <label for="display_order">Σειρά Εμφάνισης</label>
                    <input type="number" id="display_order" name="display_order" class="form-control" value="0">
                </div>
                
                <div class="form-group col-6">
                    <label class="checkbox-label">
                        <input type="checkbox" id="is_required" name="is_required" value="1">
                        Υποχρεωτικό
                    </label>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Ακύρωση</button>
                <button type="submit" class="btn btn-primary">Αποθήκευση</button>
            </div>
        </form>
    </div>
</div>

<script src="assets/js/field_builder.js"></script>

<style>
.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.modal-content {
    background: #fff;
    border-radius: 8px;
    width: 90%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    margin: 0;
}

.btn-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
}

#fieldForm {
    padding: 20px;
}

.modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.option-row {
    margin-bottom: 10px;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
}
</style>

<?php 
$extraScripts = ['assets/js/field_builder.js'];
include __DIR__ . '/../layout/footer.php'; 
?>
