<?php

$auth = new Auth();
?>

<?php if ($auth->isLoggedIn()): ?>
    </main>
</div>
<?php endif; ?>

<script src="assets/js/main.js"></script>
<?php if (isset($extraScripts)): ?>
    <?php foreach ($extraScripts as $script): ?>
    <script src="<?= e($script) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
