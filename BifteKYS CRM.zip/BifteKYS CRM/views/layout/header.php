<?php

require_once __DIR__ . '/../../config/session.php';
require_once __DIR__ . '/../../core/Auth.php';

$auth = new Auth();
$currentUser = $auth->getCurrentUser();
$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'BiftekysCRM') ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php if ($auth->isLoggedIn()): ?>
<nav class="navbar">
    <div class="nav-brand">
        <button class="menu-toggle" aria-label="Άνοιγμα Μενού">
            <i class="fas fa-bars"></i>
        </button>
        <i class="fas fa-network-wired"></i>
        <span>BiftekysCRM</span>
    </div>
    <div class="nav-links">
        <a href="?page=dashboard" class="nav-link <?= $page === 'dashboard' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <a href="?page=applications" class="nav-link <?= $page === 'applications' && empty($_GET['action']) ? 'active' : '' ?>">
            <i class="fas fa-file-alt"></i> Αιτήσεις
        </a>
        <a href="?page=applications&action=drafts" class="nav-link <?= ($_GET['action'] ?? '') === 'drafts' ? 'active' : '' ?>">
            <i class="fas fa-save"></i> Drafts
        </a>
        <a href="?page=applications&action=stats" class="nav-link <?= ($_GET['action'] ?? '') === 'stats' ? 'active' : '' ?>">
            <i class="fas fa-chart-bar"></i> Στατιστικά
        </a>
        <?php if ($auth->isAdminOrSuper()): ?>
        <a href="?page=applications&action=import" class="nav-link <?= ($_GET['action'] ?? '') === 'import' ? 'active' : '' ?>">
            <i class="fas fa-file-import"></i> Εισαγωγή
        </a>
        <a href="?page=reports" class="nav-link <?= $page === 'reports' ? 'active' : '' ?>">
            <i class="fas fa-file-invoice"></i> Αναφορές
        </a>
        <a href="?page=users" class="nav-link <?= $page === 'users' ? 'active' : '' ?>">
            <i class="fas fa-users"></i> Χρήστες
        </a>
        <?php endif; ?>
        <?php if ($auth->isSuperAdmin()): ?>
        <a href="?page=fields" class="nav-link <?= $page === 'fields' ? 'active' : '' ?>">
            <i class="fas fa-cog"></i> Πεδία
        </a>
        <?php endif; ?>
    </div>
    <div class="nav-user">
        <span class="user-name">
            <i class="fas fa-user"></i>
            <?= e($currentUser['display_name']) ?>
            <span class="user-role">(<?= e($currentUser['role']) ?>)</span>
        </span>
        <a href="?page=profile" class="btn btn-sm" style="color: #3498db; margin-right: 15px;">
            <i class="fas fa-cog"></i> Προφίλ
        </a>
        <a href="?page=logout" class="btn btn-logout">
            <i class="fas fa-sign-out-alt"></i> Αποσύνδεση
        </a>
    </div>
</nav>

<div class="main-container">
    <aside class="sidebar">
        <div class="sidebar-section">
            <h3>Γρήγορη Πρόσβαση</h3>
            <a href="?page=applications&action=create" class="sidebar-link">
                <i class="fas fa-plus-circle"></i> Νέα Αίτηση
            </a>
            <a href="?page=applications" class="sidebar-link">
                <i class="fas fa-list"></i> Λίστα Αιτήσεων
            </a>
            <a href="?page=applications&action=drafts" class="sidebar-link">
                <i class="fas fa-save"></i> Drafts
            </a>
        </div>
        
        <?php if ($auth->isAdminOrSuper()): ?>
        <div class="sidebar-section">
            <h3>Διαχείριση</h3>
            <a href="?page=applications&action=import" class="sidebar-link">
                <i class="fas fa-file-import"></i> Εισαγωγή
            </a>
            <a href="?page=reports" class="sidebar-link">
                <i class="fas fa-file-invoice"></i> Αναφορές
            </a>
            <a href="?page=users" class="sidebar-link">
                <i class="fas fa-user-cog"></i> Χρήστες
            </a>
            <a href="?page=users&action=tree" class="sidebar-link">
                <i class="fas fa-sitemap"></i> Δέντρο Χρηστών
            </a>
        </div>
        <?php endif; ?>
    </aside>
    
    <main class="main-content">
<?php endif; ?>
