<?php
/**
 * Reports View
 */

$title = 'Αναφορές - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';

$statuses = ['ΝΕΟ', 'ΚΑΤΑΧΩΡΗΜΕΝΟ', 'ΕΚΚΡΕΜΟΤΗΤΑ', 'ΑΚΥΡΟ', 'ΕΝΕΡΓΟ'];
?>

<div class="page-header">
    <h1><i class="fas fa-file-invoice"></i> Αναφορές</h1>
</div>

<div class="filters-bar">
    <form method="GET" class="filters-form">
        <input type="hidden" name="page" value="reports">
        
        <div class="filter-group">
            <label for="date_from">Από:</label>
            <input type="date" name="date_from" id="date_from" class="form-control" 
                   value="<?= e($dateFrom) ?>">
        </div>
        
        <div class="filter-group">
            <label for="date_to">Έως:</label>
            <input type="date" name="date_to" id="date_to" class="form-control" 
                   value="<?= e($dateTo) ?>">
        </div>
        
        <div class="filter-group">
            <label for="filter_by">Φίλτρο κατά:</label>
            <select name="filter_by" id="filter_by" class="form-control">
                <option value="created_at" <?= $filterBy === 'created_at' ? 'selected' : '' ?>>Ημ. Δημιουργίας</option>
                <option value="activated_at" <?= $filterBy === 'activated_at' ? 'selected' : '' ?>>Ημ. Ενεργοποίησης</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label for="status">Κατάσταση:</label>
            <select name="status" id="status" class="form-control">
                <option value="">Όλες</option>
                <?php foreach ($statuses as $s): ?>
                <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <?php if ($auth->isAdminOrSuper()): ?>
        <div class="filter-group">
            <label for="owner">Ιδιοκτήτης:</label>
            <select name="owner" id="owner" class="form-control">
                <option value="">Όλοι</option>
                <?php foreach ($users as $u): ?>
                <option value="<?= $u['id'] ?>" <?= $owner == $u['id'] ? 'selected' : '' ?>>
                    <?= e($u['display_name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-filter"></i> Φίλτρο
        </button>
        
        <?php if ($auth->isAdminOrSuper()): ?>
        <?php endif; ?>
    </form>
</div>

<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($summary['total']) ?></div>
            <div class="stat-label">Σύνολο Αιτήσεων</div>
        </div>
    </div>
    
    <?php foreach ($summary['by_status'] as $status => $count): ?>
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-circle status-<?= get_status_class($status) ?>"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($count) ?></div>
            <div class="stat-label"><?= e($status) ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php if (!empty($summary['by_owner'])): ?>
<div class="stats-section">
    <h3><i class="fas fa-users"></i> Top Συνεργάτες</h3>
    <div class="table-responsive">
        <table class="table table-sm">
            <thead>
                <tr>
                    <th>Συνεργάτης</th>
                    <th>Αριθμός Αιτήσεων</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($summary['by_owner'] as $ownerId => $ownerData): ?>
                <tr>
                    <td><?= e($ownerData['name']) ?></td>
                    <td><?= number_format($ownerData['count']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ημερομηνία</th>
                <th>Συνεργάτης</th>
                <th>Τύπος</th>
                <th>Πελάτης (Εταιρεία ή Ονοματεπώνυμο)</th>
                <th>ΑΦΜ</th>
                <th>Κατάσταση</th>
                <th class="text-center">Ενέργειες</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($applications)): ?>
            <tr>
                <td colspan="8" class="text-center text-muted">
                    <i class="fas fa-inbox"></i> Δεν βρέθηκαν αιτήσεις
                </td>
            </tr>
            <?php else: ?>
            <?php foreach ($applications as $app): ?>
            <tr>
                <td><?= $app['id'] ?></td>
                <td><?= format_date($app['created_at']) ?></td>
                <td><?= e($app['partner_name']) ?></td>
                <td><?= e($app['request_type']) ?></td>
                <td>
                    <?php if (!empty($app['company'])): ?>
                        <strong><i class="fas fa-building text-muted"></i> <?= e($app['company']) ?></strong>
                    <?php else: ?>
                        <i class="fas fa-user text-muted"></i> <?= e($app['last_name'] . ' ' . $app['first_name']) ?>
                    <?php endif; ?>
                </td>
                <td><?= e($app['afm']) ?></td>
                <td>
                    <span class="status-badge status-<?= get_status_class($app['status']) ?>">
                        <?= e($app['status']) ?>
                    </span>
                </td>
                
                <td class="text-center">
                    <a href="?page=applications&action=edit&id=<?= $app['id'] ?>" class="btn btn-sm btn-primary" title="Επεξεργασία Αίτησης">
                        <i class="fas fa-edit"></i> Επεξεργασία
                    </a>
                </td>
                
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>