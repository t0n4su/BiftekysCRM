<?php
$title = 'Το Προφίλ μου - BiftekysCRM';
include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-user-cog"></i> Το Προφίλ μου</h1>
</div>

<?php if (isset($error) && $error): ?>
<div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= e($error) ?></div>
<?php endif; ?>

<?php if (isset($success) && $success): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= e($success) ?></div>
<?php endif; ?>

<div class="form-section" style="max-width: 500px;">
    <h3>Αλλαγή Κωδικού Πρόσβασης</h3>
    <p class="text-muted">Για λόγους ασφαλείας (GDPR), προτείνεται να αλλάξετε τον αρχικό σας κωδικό.</p>
    
    <form method="POST">
        <?= csrfField() ?>
        
        <div class="form-group">
            <label for="new_password">Νέος Κωδικός</label>
            <input type="password" name="new_password" id="new_password" class="form-control" required minlength="6">
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Επιβεβαίωση Νέου Κωδικού</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required minlength="6">
        </div>
        
        <button type="submit" class="btn btn-primary mt-3">
            <i class="fas fa-save"></i> Αποθήκευση Κωδικού
        </button>
    </form>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>