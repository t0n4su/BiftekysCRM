<?php
/**
 * User Tree View
 */

$title = 'Δέντρο Χρηστών - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';

/**
 * Render tree recursively
 * @param array $nodes
 * @param int $level
 * @return void
 */
function renderTree(array $nodes, int $level = 0): void {
    if (empty($nodes)) return;
    
    echo '<ul class="tree-list' . ($level === 0 ? ' tree-root' : '') . '">';
    
    foreach ($nodes as $node) {
        $roleClass = match($node['role']) {
            'superadmin' => 'role-superadmin',
            'admin' => 'role-admin',
            default => 'role-partner',
        };
        
        $statusClass = $node['is_active'] ? 'status-active' : 'status-inactive';
        
        echo '<li class="tree-node">';
        echo '<div class="tree-item ' . $roleClass . ' ' . $statusClass . '">';
        echo '<span class="tree-icon"><i class="fas fa-user"></i></span>';
        echo '<span class="tree-username">' . e($node['display_name']) . '</span>';
        echo '<span class="tree-role">(' . e($node['role']) . ')</span>';
        
        if (!$node['is_active']) {
            echo '<span class="tree-status"><i class="fas fa-ban"></i> Ανενεργός</span>';
        }
        
        echo '</div>';
        
        if (!empty($node['children'])) {
            renderTree($node['children'], $level + 1);
        }
        
        echo '</li>';
    }
    
    echo '</ul>';
}
?>

<div class="page-header">
    <h1><i class="fas fa-sitemap"></i> Δέντρο Χρηστών</h1>
    <div class="page-actions">
        <?php if ($auth->isAdminOrSuper()): ?>
        <a href="?page=users&action=manage" class="btn btn-primary">
            <i class="fas fa-cog"></i> Διαχείριση
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="tree-legend">
    <span class="legend-item">
        <span class="legend-dot role-superadmin"></span> SuperAdmin
    </span>
    <span class="legend-item">
        <span class="legend-dot role-admin"></span> Admin
    </span>
    <span class="legend-item">
        <span class="legend-dot role-partner"></span> Partner
    </span>
</div>

<div class="tree-container">
    <?php renderTree($tree); ?>
</div>

<style>
.tree-container {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tree-list {
    list-style: none;
    padding-left: 30px;
    margin: 0;
}

.tree-root {
    padding-left: 0;
}

.tree-node {
    position: relative;
    margin: 5px 0;
}

.tree-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 15px;
    border-radius: 6px;
    background: #f8f9fa;
    border-left: 4px solid #ddd;
}

.tree-item.role-superadmin {
    border-left-color: #e74c3c;
    background: #fdf2f2;
}

.tree-item.role-admin {
    border-left-color: #f39c12;
    background: #fef9e7;
}

.tree-item.role-partner {
    border-left-color: #3498db;
    background: #ebf5fb;
}

.tree-item.status-inactive {
    opacity: 0.6;
}

.tree-username {
    font-weight: 600;
    color: #2c3e50;
}

.tree-role {
    font-size: 0.85em;
    color: #7f8c8d;
}

.tree-status {
    font-size: 0.8em;
    color: #e74c3c;
    margin-left: auto;
}

.tree-legend {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    padding: 15px;
    background: #fff;
    border-radius: 8px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9em;
}

.legend-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

.legend-dot.role-superadmin { background: #e74c3c; }
.legend-dot.role-admin { background: #f39c12; }
.legend-dot.role-partner { background: #3498db; }
</style>

<?php include __DIR__ . '/../layout/footer.php'; ?>
