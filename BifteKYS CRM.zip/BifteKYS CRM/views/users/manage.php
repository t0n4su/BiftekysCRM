<?php
/**
 * User Management View
 */

$title = 'Διαχείριση Χρηστών - BiftekysCRM';

include __DIR__ . '/../layout/header.php';

// Η μεταβλητή $user περνάει ήδη από τον Controller
if ($user['role'] === 'superadmin') {
    // Ο SuperAdmin τα βλέπει όλα
    $roles = ['partner' => 'Partner', 'admin' => 'Admin', 'superadmin' => 'SuperAdmin'];
} else {
    // Ο Admin βλέπει μόνο την επιλογή Partner
    $roles = ['partner' => 'Partner']; 
}
?>

<div class="page-header">
    <h1><i class="fas fa-users-cog"></i> Διαχείριση Χρηστών</h1>
    <div class="page-actions">
        <a href="?page=users&action=tree" class="btn btn-secondary">
            <i class="fas fa-sitemap"></i> Δέντρο
        </a>
    </div>
</div>

<?php if (isset($error) && $error): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i>
    <?= e($error) ?>
</div>
<?php endif; ?>

<?php if (isset($success) && $success): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i>
    <?= e($success) ?>
</div>
<?php endif; ?>
<!-- Add User Form -->
<div class="form-section">
    <h3><i class="fas fa-user-plus"></i> Προσθήκη Χρήστη</h3>
    <form method="POST" class="inline-form">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="create">
        
        <div class="form-row">
            
            <div class="form-group">
                <label for="new_username">Username</label>
                <input type="text" name="username" id="new_username" class="form-control">
            </div>
            
            <div class="form-group">
                <label for="new_password">Κωδικός Πρόσβασης</label>
                <input type="password" name="password" id="new_password" class="form-control">
            </div>
            
            <div class="form-group">
                <label for="new_role">Ρόλος</label>
                <select name="role" id="new_role" class="form-control">
                    <?php foreach ($roles as $key => $label): ?>
                    <option value="<?= e($key) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="new_displayname">Εμφανιζόμενο Όνομα</label>
                <input type="text" name="displayname" id="new_displayname" class="form-control">
            </div>
            
        <div class="form-group">
            <label for="new_parentuserid">Γονικός Χρήστης</label>
            <select name="parentuserid" id="new_parentuserid" class="form-control">
                <option value="">-- Ανάθεση σε εμένα --</option>
                <?php foreach ($users as $parentCandidate): ?>
                    <option value="<?= $parentCandidate['id'] ?>">
                        <?= e($parentCandidate['display_name']) ?> (<?= e($parentCandidate['role']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
            
            <div class="form-group">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Προσθήκη
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Users Table -->
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Κωδικός</th>
                <th>Ρόλος</th>
                <th>Εμφανιζόμενο Όνομα</th>
                <th>Parent</th>
                <th>Κατάσταση</th>
                <th>Ενέργειες</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= e($u['username'] ?: '-') ?></td>
                <td><?= e($u['code']) ?></td>
                <td>
                    <span class="badge badge-<?= e($u['role']) ?>">
                        <?= e($roles[$u['role']] ?? $u['role']) ?>
                    </span>
                </td>
                <td><?= e($u['display_name']) ?></td>
                <td><?= $u['parent_user_id'] ?: '-' ?></td>
                <td>
                    <?php if ($u['is_active']): ?>
                    <span class="badge badge-success">Ενεργός</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Ανενεργός</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="action-buttons">
                        <button type="button" 
                                class="btn btn-sm btn-<?= $u['is_active'] ? 'warning' : 'success' ?>"
                                onclick="toggleUser(<?= $u['id'] ?>, <?= $u['is_active'] ? 0 : 1 ?>)"
                                title="<?= $u['is_active'] ? 'Απενεργοποίηση' : 'Ενεργοποίηση' ?>">
                            <i class="fas fa-<?= $u['is_active'] ? 'ban' : 'check' ?>"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function toggleUser(id, active) {
    const action = active ? 'ενεργοποίηση' : 'απενεργοποίηση';
    if (!confirm(`Είστε σίγουροι ότι θέλετε να ${action}τε αυτόν τον χρήστη;`)) {
        return;
    }
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.innerHTML = `
        <input type="hidden" name="action" value="toggle">
        <input type="hidden" name="id" value="${id}">
        <input type="hidden" name="active" value="${active}">
        <?= csrfField() ?>
    `;
    document.body.appendChild(form);
    form.submit();
}
</script>

<style>
.badge-superadmin { background: #e74c3c; color: #fff; }
.badge-admin { background: #f39c12; color: #fff; }
.badge-partner { background: #3498db; color: #fff; }
.badge-success { background: #2ecc71; color: #fff; }
.badge-danger { background: #e74c3c; color: #fff; }

.inline-form .form-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: flex-end;
}

.inline-form .form-group {
    flex: 1;
    min-width: 150px;
}
</style>

<?php include __DIR__ . '/../layout/footer.php'; ?>
