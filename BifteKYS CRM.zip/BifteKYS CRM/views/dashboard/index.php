<?php
/**
 * Dashboard View
 */

$title = 'Dashboard - CleverPartnersCRM';

include __DIR__ . '/../layout/header.php';
?>

<div class="page-header">
    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
    <div class="page-actions">
        <a href="?page=applications&action=create" class="btn btn-primary">
            <i class="fas fa-plus"></i> Νέα Αίτηση
        </a>
    </div>
</div>

<!-- Quick Stats -->
<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-file-alt"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['total']) ?></div>
            <div class="stat-label">Σύνολο Αιτήσεων</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon" style="background: #d4edda; color: #155724;">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['today']) ?></div>
            <div class="stat-label">Σήμερα</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon" style="background: #fff3cd; color: #856404;">
            <i class="fas fa-calendar-week"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['week']) ?></div>
            <div class="stat-label">Τελευταία 7 Ημέρες</div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon" style="background: #d1ecf1; color: #0c5460;">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= number_format($stats['by_status']['ΕΝΕΡΓΟ'] ?? 0) ?></div>
            <div class="stat-label">Ενεργές</div>
        </div>
    </div>
</div>

<!-- Monthly Comparison -->
<div class="stats-section">
    <h3><i class="fas fa-chart-bar"></i> Σύγκριση Μηνών</h3>
    <div class="row">
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($monthComparison['this_month']) ?></div>
                    <div class="stat-label">Τρέχων Μήνας</div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($monthComparison['last_month']) ?></div>
                    <div class="stat-label">Προηγούμενος Μήνας</div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="stat-card">
                <div class="stat-content">
                    <div class="stat-value" style="color: <?= $monthComparison['change'] >= 0 ? '#2ecc71' : '#e74c3c' ?>">
                        <?= $monthComparison['change'] >= 0 ? '+' : '' ?><?= number_format($monthComparison['change'], 1) ?>%
                    </div>
                    <div class="stat-label">Μεταβολή</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Status Distribution -->
<div class="stats-section">
    <h3><i class="fas fa-chart-pie"></i> Κατανομή ανά Κατάσταση</h3>
    <div class="chart-container" style="height: 250px;">
        <canvas id="statusChart"></canvas>
    </div>
</div>

<!-- Recent Applications -->
<div class="stats-section">
    <h3><i class="fas fa-history"></i> Πρόσφατες Αιτήσεις</h3>
    <div class="table-responsive">
        <table class="table table-sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ημερομηνία</th>
                    <th>Επώνυμο</th>
                    <th>Όνομα</th>
                    <th>Κατάσταση</th>
                    <th>Ενέργειες</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentApps as $app): ?>
                <tr>
                    <td><?= $app['id'] ?></td>
                    <td><?= format_date($app['created_at']) ?></td>
                    <td><?= e($app['last_name']) ?></td>
                    <td><?= e($app['first_name']) ?></td>
                    <td>
                        <span class="status-badge status-<?= get_status_class($app['status']) ?>">
                            <?= e($app['status']) ?>
                        </span>
                    </td>
                    <td>
                        <a href="?page=applications&action=edit&id=<?= $app['id'] ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <a href="?page=applications" class="btn btn-outline-primary">
        <i class="fas fa-list"></i> Προβολή Όλων
    </a>
</div>

<script>
// Status Chart
const statusData = <?= json_encode($stats['by_status']) ?>;
new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: Object.keys(statusData),
        datasets: [{
            data: Object.values(statusData),
            backgroundColor: ['#3498db', '#2ecc71', '#f39c12', '#e74c3c', '#9b59b6']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'right' }
        }
    }
});
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
