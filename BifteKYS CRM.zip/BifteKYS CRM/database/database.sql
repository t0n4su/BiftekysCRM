
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+02:00";

-- --------------------------------------------------------

--
-- Δομή πίνακα `users`
--
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `code` varchar(50) NOT NULL COMMENT 'Μοναδικός κωδικός συνεργάτη',
  `parent_code` varchar(50) DEFAULT NULL COMMENT 'Κωδικός του ανωτέρου/manager',
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 3 COMMENT '1=SuperAdmin, 2=Admin, 3=Partner',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Εισαγωγή δεδομένων στον πίνακα `users`
-- Κωδικός και για τους δύο: demo123
-- Το Hash αντιστοιχεί στο "demo123"
--
INSERT INTO `users` (`id`, `username`, `password_hash`, `code`, `parent_code`, `first_name`, `last_name`, `email`, `role_id`, `status`) VALUES
(1, 'admin', '$2y$10$QxR.JcW.1lOq5/17N23JauM/V3R/1FIfK//sH5N6J1B.oXzL.6O1i', 'ADMIN001', NULL, 'Super', 'Admin', 'admin@cleverpartners.gr', 1, 1),
(2, 'demo_admin', '$2y$10$QxR.JcW.1lOq5/17N23JauM/V3R/1FIfK//sH5N6J1B.oXzL.6O1i', 'DEMO001', 'ADMIN001', 'Demo', 'Admin', 'demo@cleverpartners.gr', 2, 1);


-- --------------------------------------------------------

--
-- Δομή πίνακα `applications`
--
CREATE TABLE `applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'ID του χρήστη που καταχώρησε την αίτηση',
  `partner_code` varchar(50) NOT NULL COMMENT 'Ο κωδικός του συνεργάτη',
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `afm` varchar(9) NOT NULL,
  `adt` varchar(20) DEFAULT NULL,
  `dou` varchar(100) DEFAULT NULL,
  `company` varchar(150) DEFAULT NULL,
  `company_afm` varchar(9) DEFAULT NULL,
  `landline_phone` varchar(20) DEFAULT NULL,
  `mobile_phone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `contact_date` date DEFAULT NULL,
  `install_address` text DEFAULT NULL,
  `billing_address` text DEFAULT NULL,
  `request_type` varchar(50) DEFAULT NULL,
  `application_number` varchar(50) DEFAULT NULL,
  `landline_program` varchar(100) DEFAULT NULL,
  `mobile_program` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `afm` (`afm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα `application_files`
--
CREATE TABLE `application_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` int(11) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL COMMENT 'Μέγεθος σε bytes',
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `application_id` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα `application_drafts`
--
CREATE TABLE `application_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'JSON δεδομένα της φόρμας',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Δομή πίνακα `custom_fields`
--
CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_name` varchar(100) NOT NULL,
  `field_label` varchar(150) NOT NULL,
  `field_type` varchar(50) NOT NULL COMMENT 'text, textarea, dropdown, κλπ.',
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL COMMENT 'JSON array με επιλογές αν είναι dropdown',
  `display_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_name` (`field_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Περιορισμοί (Foreign Keys)
--
ALTER TABLE `applications`
  ADD CONSTRAINT `fk_app_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `application_files`
  ADD CONSTRAINT `fk_app_files_app` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE;

ALTER TABLE `application_drafts`
  ADD CONSTRAINT `fk_draft_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

COMMIT;